﻿[cmdletbinding(SupportsShouldProcess = $true)]

$Global:SyncHash = [hashtable]::Synchronized(@{})
$SyncHash.host = $Host
$RunningAsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$SyncHash.RunningAsAdmin = $RunningAsAdmin

$host.ui.RawUI.WindowTitle = "NPA - Main interface"

Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
Write-Log -Message "DataCollection module loaded" -Source "Main" -MessageType Info

Write-Log -Message "Initializing interface" -Source "Main" -MessageType Info
Add-Type –AssemblyName PresentationFramework
Add-Type –AssemblyName PresentationCore
Add-Type –AssemblyName WindowsBase
Add-Type –AssemblyName Microsoft.VisualBasic
Add-Type –AssemblyName System.Windows.Forms

[xml]$xaml = Get-Content "$env:NPAPath\scripts\LoadDialog.xml"
$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$SyncHash.Window = [Windows.Markup.XamlReader]::Load( $reader )

# Global items
$SyncHash.tabControl = $SyncHash.Window.FindName("TabControl")
$SyncHash.progressbar = $SyncHash.Window.FindName("ProgressBar")
$SyncHash.progressbartext = $SyncHash.Window.FindName("ProgressBarText")
$SyncHash.OutputWindow = $SyncHash.Window.FindName("txt_Main_Output")
$SyncHash.lbl_Main_VersionNumber = $SyncHash.Window.FindName("lbl_Main_VersionNumber")
$SyncHash.btn_Runlog = $SyncHash.Window.FindName("Btn_Main_Runlog")
$SyncHash.btn_Main_Close = $SyncHash.Window.FindName("Btn_Main_Close")

# Setting tab
$SyncHash.Sitename = $SyncHash.Window.FindName("txt_Sitename")
$SyncHash.Sitename_Example = $SyncHash.Window.FindName("lbl_Sitename_Example")
$SyncHash.Location = $SyncHash.Window.FindName("txt_Location")
$SyncHash.Location_Example = $SyncHash.Window.FindName("lbl_Location_Example")
$SyncHash.EgressIP = $SyncHash.Window.FindName("txt_Network_Egress")
$SyncHash.EgressIP_Example = $SyncHash.Window.FindName("lbl_Network_Egress_Example")
$SyncHash.TenantType = $SyncHash.Window.FindName("list_TenantType")
$SyncHash.CaptureTool = $SyncHash.Window.FindName("list_CaptureTool")
$SyncHash.CaptureScenario = $SyncHash.Window.FindName("list_CaptureScenario")
$SyncHash.grp_Setting_OneDrive = $SyncHash.Window.FindName("grp_Setting_OneDrive")
$SyncHash.OneDriveFQDN = $SyncHash.Window.FindName("txt_OneDriveFQDN")
$SyncHash.OneDriveFQDN_Example = $SyncHash.Window.FindName("lbl_OneDriveFQDN_Example")
$SyncHash.OneDriveURL = $SyncHash.Window.FindName("txt_OneDriveURL")
$SyncHash.OneDriveURL_Example = $SyncHash.Window.FindName("lbl_OneDriveURL_Example")
$SyncHash.OneDriveURL_Label = $SyncHash.Window.FindName("lbl_OneDriveURL")
$SyncHash.OneDriveClientID = $SyncHash.Window.FindName("txt_OneDriveClientID")
$SyncHash.OneDriveClientID_Example = $SyncHash.Window.FindName("lbl_OneDriveClientID_Example")
$SyncHash.OneDriveClientID_Label = $SyncHash.Window.FindName("lbl_OneDriveClientID")
$SyncHash.OneDriveClientSecret = $SyncHash.Window.FindName("pwd_Secret")
$SyncHash.OneDriveClientSecret_Label = $SyncHash.Window.FindName("lbl_OneDriveClientSecret")
$SyncHash.TenantID = $SyncHash.Window.FindName("txt_TenantID")
$SyncHash.TenantID_Example = $SyncHash.Window.FindName("lbl_TenantID_Example")
$SyncHash.TenantID_Label = $SyncHash.Window.FindName("lbl_TenantID")
$SyncHash.OutputPath = $SyncHash.Window.FindName("txt_OutputDirectory")
$SyncHash.btn_Browse = $SyncHash.Window.FindName("btn_OutputDirectory_Browse")
$SyncHash.btn_Settings_Save = $SyncHash.Window.FindName("Btn_Settings_Save")
$SyncHash.Btn_Diag_Logs = $SyncHash.Window.FindName("Btn_Settings_Diag_Logs")
$SyncHash.cb_DebugMode = $SyncHash.Window.FindName("cb_DebugMode")
$SyncHash.cb_AppRegistration = $SyncHash.Window.FindName("cb_AppRegistration")

# Individual collection tab
$SyncHash.cb_Network_RunAll = $SyncHash.Window.FindName("cb_Network_RunAll")
$SyncHash.lbl_Network_StatusLabel = $SyncHash.Window.FindName("lbl_Network_StatusLabel")
$SyncHash.lbl_Network_CheckResultLabel = $SyncHash.Window.FindName("lbl_Network_CheckResultLabel")
$SyncHash.cb_Network_IPConfig = $SyncHash.Window.FindName("cb_Network_IPConfig")
$SyncHash.lbl_Network_IPConfig_Status = $SyncHash.Window.FindName("lbl_Network_IPConfig_Status")
$SyncHash.lbl_Network_IPConfig_CheckResult = $SyncHash.Window.FindName("lbl_Network_IPConfig_CheckResult")
$SyncHash.cb_Network_Tracert = $SyncHash.Window.FindName("cb_Network_Tracert")
$SyncHash.lbl_Network_Tracert_Status = $SyncHash.Window.FindName("lbl_Network_Tracert_Status")
$SyncHash.lbl_Network_Tracert_CheckResult = $SyncHash.Window.FindName("lbl_Network_Tracert_CheckResult")
$SyncHash.cb_Network_DNSLookup = $SyncHash.Window.FindName("cb_Network_DNSLookup")
$SyncHash.lbl_Network_DNSLookup_Status = $SyncHash.Window.FindName("lbl_Network_DNSLookup_Status")
$SyncHash.lbl_Network_DNSLookup_CheckResult = $SyncHash.Window.FindName("lbl_Network_DNSLookup_CheckResult")
$SyncHash.cb_Network_EXO = $SyncHash.Window.FindName("cb_Network_EXO")
$SyncHash.lbl_Network_EXO_Status = $SyncHash.Window.FindName("lbl_Network_EXO_Status")
$SyncHash.lbl_Network_EXO_CheckResult = $SyncHash.Window.FindName("lbl_Network_EXO_CheckResult")
$SyncHash.cb_Network_Teams = $SyncHash.Window.FindName("cb_Network_Teams")
$SyncHash.lbl_Network_Teams_Status = $SyncHash.Window.FindName("lbl_Network_Teams_Status")
$SyncHash.lbl_Network_Teams_CheckResult = $SyncHash.Window.FindName("lbl_Network_Teams_CheckResult")
$SyncHash.cb_Network_SPO = $SyncHash.Window.FindName("cb_Network_SPO")
$SyncHash.lbl_Network_SPO_Status = $SyncHash.Window.FindName("lbl_Network_SPO_Status")
$SyncHash.lbl_Network_SPO_CheckResult = $SyncHash.Window.FindName("lbl_Network_SPO_CheckResult")
$SyncHash.cb_Network_Viva = $SyncHash.Window.FindName("cb_Network_Viva")
$SyncHash.lbl_Network_Viva_Status = $SyncHash.Window.FindName("lbl_Network_Viva_Status")
$SyncHash.lbl_Network_Viva_CheckResult = $SyncHash.Window.FindName("lbl_Network_Viva_CheckResult")
$SyncHash.cb_Network_Copilot = $SyncHash.Window.FindName("cb_Network_Copilot")
$SyncHash.lbl_Network_Copilot_Status = $SyncHash.Window.FindName("lbl_Network_Copilot_Status")
$SyncHash.lbl_Network_Copilot_CheckResult = $SyncHash.Window.FindName("lbl_Network_Copilot_CheckResult")
$SyncHash.cb_Network_MicrosoftDomain = $SyncHash.Window.FindName("cb_Network_MicrosoftDomain")
$SyncHash.lbl_Network_MicrosoftDomain_Status = $SyncHash.Window.FindName("lbl_Network_MicrosoftDomain_Status")
$SyncHash.lbl_Network_MicrosoftDomain_CheckResult = $SyncHash.Window.FindName("lbl_Network_MicrosoftDomain_CheckResult")
$SyncHash.cb_Network_FileTransfer = $SyncHash.Window.FindName("cb_Network_FileTransfer")
$SyncHash.lbl_Network_FileTransfer_Status = $SyncHash.Window.FindName("lbl_Network_FileTransfer_Status")
$SyncHash.lbl_Network_FileTransfer_CheckResult = $SyncHash.Window.FindName("lbl_Network_FileTransfer_CheckResult")
$SyncHash.cb_Network_TeamsMediaQuality = $SyncHash.Window.FindName("cb_Network_TeamsMediaQuality")
$SyncHash.lbl_Network_TeamsMediaQuality_Status = $SyncHash.Window.FindName("lbl_Network_TeamsMediaQuality_Status")
$SyncHash.lbl_Network_TeamsMediaQuality_CheckResult = $SyncHash.Window.FindName("lbl_Network_TeamsMediaQuality_CheckResult")
$SyncHash.btn_Open_Output = $SyncHash.Window.FindName("btn_Main_Open_Output")
$SyncHash.btn_Network_OutputCheck = $SyncHash.Window.FindName("btn_Network_OutputCheck")
$SyncHash.btn_Single_collect = $SyncHash.Window.FindName("btn_Network_Collect")

# 7-days collection tab
$SyncHash.cb_SkipTeamsNAT = $SyncHash.Window.FindName("cb_SkipTeamsNAT")
$SyncHash.btn_Schedule_7Day_Collection = $SyncHash.Window.FindName("btn_Schedule_7Day_Collection")
$SyncHash.btn_Unschedule_7Day_Collection = $SyncHash.Window.FindName("btn_Unschedule_7Day_Collection")
$SyncHash.btn_TaskScheduler = $SyncHash.Window.FindName("btn_TaskScheduler")
$SyncHash.lbl_TestsStatus = $SyncHash.Window.FindName("lbl_TestsStatus")
$SyncHash.lbl_1MinuteTaskStatus = $SyncHash.Window.FindName("lbl_1MinuteTaskStatus")
$SyncHash.lbl_15MinutesTaskStatus = $SyncHash.Window.FindName("lbl_15MinutesTaskStatus")

# Finish tab
$SyncHash.btn_finish_PackageUnlimited = $SyncHash.Window.FindName("btn_finish_PackageUnlimited")
$SyncHash.btn_finish_Package1GB = $SyncHash.Window.FindName("btn_finish_Package1GB")
$SyncHash.btn_finish_Package500MB = $SyncHash.Window.FindName("btn_finish_Package500MB")
$SyncHash.btn_finish_Package250MB = $SyncHash.Window.FindName("btn_finish_Package250MB")
$SyncHash.btn_finish_Package100MB = $SyncHash.Window.FindName("btn_finish_Package100MB")
$SyncHash.btn_finish_Package = $SyncHash.Window.FindName("btn_finish_Package")
$SyncHash.btn_finish_Cleanup = $SyncHash.Window.FindName("btn_finish_Cleanup")

Write-Log -Message "Interface initialized" -Source "Main" -MessageType Info

# Default Output Path
$SyncHash.OutputPath.text = "$env:NPAPath\Output"

if (Test-Path $env:NPAPath\Settings.json) {

    # importing Settings from file
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $SyncHash.Version = $CurrentSettings.Version
    $SyncHash.WiresharkPath = $CurrentSettings.WiresharkPath
    $SyncHash.NetmonPath = $CurrentSettings.NetmonPath
    $SyncHash.EgressIP.text = $CurrentSettings.EgressIP
    $SyncHash.Sitename.text = $CurrentSettings.SiteName
    $SyncHash.Location.text = $CurrentSettings.Location
    $SyncHash.TenantType.SelectedIndex = $CurrentSettings.TenantType[0]
    $SyncHash.CaptureTool.SelectedIndex = $CurrentSettings.CaptureTool[0]
    $SyncHash.CaptureScenario.SelectedIndex = $CurrentSettings.CaptureScenario[0]
    $SyncHash.OneDriveFQDN.text = $CurrentSettings.OneDriveFQDN
    $SyncHash.OneDriveURL.Text = $CurrentSettings.OneDriveURL
    $SyncHash.OneDriveClientID.Text = $CurrentSettings.OneDriveClientID
    if (Test-Path "$env:NPAPath\secret") { $SyncHash.OneDriveClientSecret.Password = Get-Secret -path "$env:NPAPath\secret" }
    $SyncHash.TenantID.Text = $CurrentSettings.Tenantid
    $SyncHash.cb_DebugMode.IsChecked = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
    $SyncHash.cb_AppRegistration.IsChecked = if ($CurrentSettings.AppRegistration -match "True") {$true} else {$false}
    $SyncHash.OutputPath.text = $CurrentSettings.OutputPath
    $IsFirstRun = if ($CurrentSettings.IsFirstRun -match "True") {$true} else {$false}
}

Write-Log -Message "Settings loaded" -Source "Main" -MessageType Info

Get-Settings

$SyncHash.OutputWindow.Dispatcher.invoke([action] {
    $SyncHash.OutputWindow.AppendText("##################################################################################################`n")
    $SyncHash.OutputWindow.AppendText("                                                                          NPA DataCollection tool v$($CurrentSettings.Version) start`n")
    $SyncHash.OutputWindow.AppendText("##################################################################################################`n")
    $SyncHash.OutputWindow.AppendText("`n")
    $SyncHash.OutputWindow.ScrollToEnd()
},
"Normal")

# Forcing GUI Flow
$SyncHash.lbl_Main_VersionNumber.Content = "Version: $($CurrentSettings.Version)"
# Start Tab
$SyncHash.TabControl.Items[0].IsEnabled = $true
# Settings Tab
$SyncHash.TabControl.Items[1].IsEnabled = $true
# 7-days collection Tab
$SyncHash.btn_Schedule_7Day_Collection.IsEnabled = $false
$SyncHash.btn_Unschedule_7Day_Collection.IsEnabled = $false
if ($SyncHash.CaptureScenario.SelectedValue.Content -eq "Zscaler - encrypted tunnel") {
    Write-Log -Message "Disabling 7-days scheduling tab for Zscaler (encrypted tunnel) scenario" -Source "Main" -MessageType Warning -DisplayInGui
    $SyncHash.TabControl.Items[3].IsEnabled = $false
}
# Cleanup tab
$SyncHash.TabControl.Items[4].IsEnabled = $true
# Set "Unlimited" as the default zip size
$SyncHash.btn_finish_PackageUnlimited.IsChecked = $true

<#
# Hide/show settings based on tenant type
if ($SyncHash.TenantType.SelectedIndex -eq 2) {
    Write-Log -Message "Forcing app registration for DOD tenants" -Source "Main" -MessageType Info
    $SyncHash.cb_AppRegistration.IsChecked = $true
    $SyncHash.cb_AppRegistration.IsEnabled = $false
} else {
    Write-Log -Message "Allowing app registration for worldwide/GCCH tenants" -Source "Main" -MessageType Info
    $SyncHash.cb_AppRegistration.IsChecked = $false
    $SyncHash.cb_AppRegistration.IsEnabled = $true
}
#>

Set-SettingsVisibility

# If the script is run for the first time (no previous Settings.json file saved)
if ($IsFirstRun -eq $true) {
    Write-Log -Message "First run of the tool, disabling collection tabs" -Source "Main" -MessageType Warning
    Write-Log -Message "Configure and save settings to enable collection tabs" -Source "Main" -MessageType Warning -DisplayInGui
    # One-time collection
    $SyncHash.TabControl.Items[2].IsEnabled = $false
    # 7-days collection
    $SyncHash.TabControl.Items[3].IsEnabled = $false
    # Check for known specific capture scenarios
    if ((Get-Service | Where-Object { $_.DisplayName -match "Netskope Client" }).Status -eq "Running" -and (Test-Path "C:\Program Files (x86)\netskope\stagent\nsdiag.exe")) {
        Write-Log -Message "Netskope client detected, defaulting to Netskope capture scenario" -Source "Main" -MessageType Info
        $SyncHash.CaptureScenario.SelectedIndex = 1
    }
    if (Get-NetAdapter | Where-Object { $_.InterfaceDescription -match "Zscaler" }) {
        Write-Log -Message "Zscaler interface detected, defaulting to Zscaler capture scenario" -Source "Main" -MessageType Info
        $SyncHash.CaptureScenario.SelectedIndex = 2
    }
} else {
    Write-Log -Message "Checking previous settings to enable tabs" -Source "Main" -MessageType Info
    # Always enable one-time collection if not first run
    $SyncHash.TabControl.Items[2].IsEnabled = $true
    Test-Settings -synchash $SyncHash
}

if ($SyncHash.WiresharkPath -like "") {
    if ($SyncHash.NetmonPath -like "" -and $SyncHash.CaptureTool.SelectedIndex -ne 2) {
        Write-Log -Message "Wireshark and Netmon are not installed, defaulting to Netsh trace" -Source "Main" -MessageType Warning -DisplayInGui
        $SyncHash.CaptureTool.SelectedIndex = 2
    } elseif ($SyncHash.CaptureTool.SelectedIndex -eq 0) {
        Write-Log -Message "Wireshark is not installed but Netmon is, defaulting to Netmon trace" -Source "Main" -MessageType Warning -DisplayInGui
        $SyncHash.CaptureTool.SelectedIndex = 1
    }
} elseif ($SyncHash.NetmonPath -like "" -and $SyncHash.CaptureTool.SelectedIndex -eq 1) {
    Write-Log -Message "Netmon is not installed, defaulting to Wireshark trace" -Source "Main" -MessageType Warning -DisplayInGui
    $SyncHash.CaptureTool.SelectedIndex = 0
}

if ($SyncHash.WiresharkPath -like "" -and $SyncHash.CaptureScenario.SelectedValue.Content -match "Netskope|Zscaler - encrypted tunnel") {
    Write-Log -Message "Wireshark is not installed, unable to use Netskope and Zscaler (encrypted tunnel) capture scenario" -Source "Main" -MessageType Warning -DisplayInGui
    $SyncHash.CaptureScenario.SelectedIndex = 0
}

$OutputCheckResultFile = Join-Path -Path $CurrentSettings.OutputPath -ChildPath "OutputCheckResult.csv"
if (Test-Path -Path $OutputCheckResultFile) {
    Write-Log -Message "Checking previous output validation results" -Source "Main" -MessageType Info
    $PreviousOutputCheckResults = Import-Csv -Path $OutputCheckResultFile -Delimiter "`t"

    foreach ($WorkloadOutputCheckResult in ($PreviousOutputCheckResults | Group-Object -Property Service)) {
        $Workload = $WorkloadOutputCheckResult.Name
        Write-Log -Message "Checking previous output validation results for '$Workload'" -Source "Main" -MessageType Info
        $LastOutputCheckResult = $WorkloadOutputCheckResult.Group | Sort-Object -Property Timestamp | Select-Object -Last 1
    
        if ($LastOutputCheckResult.Result -eq "Error") {
            Write-Log -Message "Test output for '$Workload' was previously flagged as 'error'" -Source "Main" -MessageType Info
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "Red"
            $CheckResult = "X"
        } elseif ($LastOutputCheckResult.Result -eq "Warning") {
            Write-Log -Message "Test output for '$Workload' was previously flagged as 'warning'" -Source "Main" -MessageType Info
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "DarkOrange"
            $CheckResult = "/!\"
        } elseif ($LastOutputCheckResult.Result -eq "Valid") {
            Write-Log -Message "Test output for '$Workload' was previously flagged as 'valid'" -Source "Main" -MessageType Info
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "DarkGreen"
            $CheckResult = "V"
        } else {
            Write-Log -Message "Test output for '$Workload' was previously flagged as 'unknown'" -Source "Main" -MessageType Info
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "DarkOrange"
            $CheckResult = "-?-"
        }
        Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property Content -Value $CheckResult
    }
} else {
    Write-Log -Message "No previous output validation results found" -Source "Main" -MessageType Info
}

Write-Log -Message "Initializing interface controls" -Source "Main" -MessageType Info

# Set maximum progress at 1 until tests are being run
Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Maximum -Value 1

# On tabs loading, refresh content if needed
$SyncHash.tabControl.add_SelectionChanged({
    if ($SyncHash.tabControl.SelectedIndex -ne $SyncHash.PreviousTab) {
        Write-Log -Message "Displaying '$($SyncHash.tabControl.SelectedItem.Header)' tab" -Source "Main" -MessageType Info

        # Settings tab
        if ($SyncHash.tabControl.SelectedIndex -eq 1) {
            if ($SyncHash.EgressIP.Text -like "") {
                $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
                if ($CurrentSettings.ProxyConfiguration -match 'Static=') {
                    Write-Log -Message "Setting proxy as the egress IP field in settings" -Source "Main" -MessageType Info
                    if ($CurrentSettings.ProxyConfiguration -match '.*Static=(.*?):\d+') {
                        $EgressIP = $CurrentSettings.ProxyConfiguration -replace '.*Static=(.*?):\d+','$1'
                    } else {
                        $EgressIP = $CurrentSettings.ProxyConfiguration -replace '.*Static=(.*?)','$1'
                    }
                    Update-Control -SyncHash $SyncHash -Control EgressIP -Property text -Value $EgressIP
                } else {
                    Update-Control -SyncHash $SyncHash -Control EgressIP -Property text -Value $CurrentSettings.EgressIP
                }
            }
        }

        # 7-days collection
        if ($SyncHash.tabControl.SelectedIndex -eq 3) {
            Start-AsyncTask -Workload ScheduledTasksStatus
            $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
            $TestsResultsPath = Join-Path -Path $CurrentSettings.OutputPath -ChildPath "TestsResults.csv"
            if (Test-Path $TestsResultsPath) {
                $TestsResultsContent = Get-Content -Path $TestsResultsPath
                if (($TestsResultsContent | Select-Object -First 1) -match ";") {
                    Write-Log -Message "Tests results file was previously generated using ';' delimiter, converting to tab delimiter" -Source "Main" -MessageType Info
                    $TestsResultsContent = $TestsResultsContent -replace ';',"`t"
                    $TestsResultsContent | Set-Content -Path $TestsResultsPath -Encoding UTF8
                }
                $TestsResults = $TestsResultsContent | ConvertFrom-Csv -Delimiter "`t"
                if ($TestsResults.count -gt 0) {
                    $LastTestResult = $TestsResults | Select-Object -Last 1
                    $LastRunTime = [datetime]::ParseExact($LastTestResult.EndTime,'yyyyMMdd HH:mm:ss',$null)
                    $SyncHash.lbl_TestsStatus.Content = "Last test ran at '$($LastRunTime.ToString("yyyy-MM-dd HH:mm:ss"))' ($($LastTestResult.Type) - $($LastTestResult.Result))"
                } else {
                    $SyncHash.lbl_TestsStatus.Content = "No test ran yet"
                }
            } else {
                $SyncHash.lbl_TestsStatus.Content = "No test ran yet"
            }
        }

        $SyncHash.PreviousTab = $SyncHash.tabControl.SelectedIndex
    }
})

# Close GUI
$SyncHash.btn_Main_Close.Add_Click({
    Write-Log -Message "User clicked the '$($SyncHash.btn_Main_Close.Content)' button" -Source "Main" -MessageType Info -DisplayInGui
    $SyncHash.Window.Close()
})

# Sitename on text changed
$SyncHash.Sitename.Add_TextChanged({
    Set-ExamplesVisibility
})
# Location on text changed
$SyncHash.Location.Add_TextChanged({
    Set-ExamplesVisibility
})
# Egress IP on text changed
$SyncHash.EgressIP.Add_TextChanged({
    Set-ExamplesVisibility
})
# Onedrive FQDN on text changed
$SyncHash.OneDriveFQDN.Add_TextChanged({
    Set-ExamplesVisibility
})
# Onedrive URL on text changed
$SyncHash.OneDriveURL.Add_TextChanged({
    Set-ExamplesVisibility
})
# Onedrive ClientID on text changed
$SyncHash.OneDriveClientID.Add_TextChanged({
    Set-ExamplesVisibility
})
# Onedrive TenantID on text changed
$SyncHash.TenantID.Add_TextChanged({
    Set-ExamplesVisibility
})

# Settings - Save
$SyncHash.Btn_Settings_Save.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_Settings_Save.Content)' button" -Source "Main" -MessageType Info

    if (Get-ScheduledTaskInfo -TaskName "NPA - Trace" -ErrorAction SilentlyContinue) {
        Write-Log -Message "7-days collection has already been scheduled, warning the user" -Source "Main" -MessageType Warning
        $WarningTitle = "7-days collection already scheduled"
        $WarningText = "7-days collection has already been scheduled, changing settings may interfere with the automated collection. Proceed anyway?"
        $UserAnswer = New-Popup -Title $WarningTitle -Message $WarningText -Buttons "YesNo" -Icon Exclamation -DefaultButton Second

        Switch ($UserAnswer) {
            "6" {
                Write-Log -Message "Warning acknowledged, trying to update settings anyway" -Source "Main" -MessageType Warning -DisplayInGui
                $ProceedWithSettingsUpdate = $true
            }
            "7" {
                Write-Log -Message "Settings update aborted" -Source "Main" -MessageType Info -DisplayInGui
                $ProceedWithSettingsUpdate = $false
            }
            default {
                Write-Log -Message "Unknown response ($UserAnswer), aborting" -Source "Main" -MessageType Error -DisplayInGui
                $ProceedWithSettingsUpdate = $false
            }
        }
    } else {
        $ProceedWithSettingsUpdate = $true
    }

    if ($ProceedWithSettingsUpdate -eq $true) {
        Test-Settings -synchash $SyncHash

        $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json

        # Building Settings
        $NewSettings = "" | Select-Object Version, IsFirstRun, EgressIP, OutputPath, OneDriveURL, OneDriveClientID, TenantType, SiteName, Location, OneDriveFQDN, Tenantid, WiresharkPath, NetmonPath, TeamsNATpath, TenantName, AppRegistration, ProxyConfiguration, CaptureTool, CaptureScenario, DebugMode
        $NewSettings.Version = $CurrentSettings.Version
        $NewSettings.IsFirstRun = "False"
        $NewSettings.EgressIP = $SyncHash.EgressIP.text
        $NewSettings.SiteName = $SyncHash.Sitename.text
        $NewSettings.Location = $SyncHash.Location.text
        $NewSettings.OutputPath = $SyncHash.OutputPath.text
        $NewSettings.OneDriveFQDN = $SyncHash.OneDriveFQDN.Text
        $NewSettings.OneDriveURL = $SyncHash.OneDriveURL.Text
        $NewSettings.OneDriveClientID = $SyncHash.OneDriveClientID.Text
        $NewSettings.TenantType = @($SyncHash.TenantType.SelectedIndex, $SyncHash.TenantType.SelectedValue.Content)
        $NewSettings.CaptureTool = @($SyncHash.CaptureTool.SelectedIndex, $SyncHash.CaptureTool.SelectedValue.Content)
        $NewSettings.CaptureScenario = @($SyncHash.CaptureScenario.SelectedIndex, $SyncHash.CaptureScenario.SelectedValue.Content)
        $NewSettings.Tenantid = $SyncHash.TenantID.Text
        $NewSettings.ProxyConfiguration = $CurrentSettings.ProxyConfiguration
        $NewSettings.WiresharkPath = $CurrentSettings.WiresharkPath
        $NewSettings.NetmonPath = $CurrentSettings.NetmonPath
        $NewSettings.TeamsNATpath = $CurrentSettings.TeamsNATpath
        $NewSettings.TenantName = if ($SyncHash.OneDriveFQDN.Text -match ".*-my\..*") { $SyncHash.OneDriveFQDN.Text -replace '(.*)-my\..*','$1' } else { $CurrentSettings.TenantName }
        $NewSettings.DebugMode = if ($SyncHash.cb_DebugMode.IsChecked) {"True"} else {"False"}
        $NewSettings.AppRegistration = if ($SyncHash.cb_AppRegistration.IsChecked) {"True"} else {"False"}

        # Always enable one-time collection tab when settings are saved
        $SyncHash.TabControl.Items[2].IsEnabled = $true

        # Exporting settings
        $NewSettings | ConvertTo-Json | Out-File -FilePath $env:NPAPath\Settings.json -Encoding UTF8 -Force
        Write-Log -Message "Settings saved" -Source "Main" -MessageType Info -DisplayInGui

        Get-Settings

        New-Balloontip -Title "Network Performance Assessment" -message "Settings saved" -ToolTipIcon Info
    }

})


# Settings - TenantType list
$SyncHash.TenantType.add_SelectionChanged({
    Write-Log -Message "Tenant type changed to '$($SyncHash.TenantType.SelectedValue.Content)'" -Source "Main" -MessageType Info
    <#
    if ($SyncHash.TenantType.SelectedIndex -eq 2) {
        Write-Log -Message "Forcing app registration for DOD tenants" -Source "Main" -MessageType Info
        $SyncHash.cb_AppRegistration.IsChecked = $true
        $SyncHash.cb_AppRegistration.IsEnabled = $false
    } else {
        if ($SyncHash.cb_AppRegistration.IsEnabled -eq $false) {
            Write-Log -Message "Allowing app registration for worldwide/GCCH tenants" -Source "Main" -MessageType Info
            $SyncHash.cb_AppRegistration.IsChecked = $false
            $SyncHash.cb_AppRegistration.IsEnabled = $true
        }
    }
    #>
    Set-SettingsVisibility
})

# Settings - CaptureTool list
$SyncHash.CaptureTool.add_SelectionChanged({
    Write-Log -Message "Capture tool changed to '$($SyncHash.CaptureTool.SelectedValue.Content)'" -Source "Main" -MessageType Info
    
    if ($SyncHash.CaptureTool.SelectedValue.Content -eq "Netsh" -and $SyncHash.RunningAsAdmin -eq $false) {
        Write-Log -Message "Unable to use Netsh as the capture tool (Netsh requires admin privileges)" -Source "Main" -MessageType Error -DisplayInGui
        New-Popup -Title "Invalid capture tool" -Message "Unable to use Netsh as the capture tool (Netsh requires admin privileges)" -Buttons OK -Icon Stop | Out-Null
        $SyncHash.CaptureTool.SelectedIndex = 0
    }
    if (($SyncHash.CaptureTool.SelectedValue.Content -eq "Wireshark" -and $SyncHash.WiresharkPath -like "") -or ($SyncHash.CaptureTool.SelectedValue.Content -eq "Netmon" -and $SyncHash.NetmonPath -like "")) {
        Write-Log -Message "Unable to use $($SyncHash.CaptureTool.SelectedValue.Content) as the capture tool ($($SyncHash.CaptureTool.SelectedValue.Content) not detected)" -Source "Main" -MessageType Error -DisplayInGui
        New-Popup -Title "Invalid capture tool" -Message "Unable to use $($SyncHash.CaptureTool.SelectedValue.Content) as the capture tool ($($SyncHash.CaptureTool.SelectedValue.Content) not detected)" -Buttons OK -Icon Stop | Out-Null
        if ($SyncHash.WiresharkPath -like "") {
            if ($SyncHash.NetmonPath -like "") {
                $SyncHash.CaptureTool.SelectedIndex = 2
            } else {
                $SyncHash.CaptureTool.SelectedIndex = 1
            }
        } else {
            $SyncHash.CaptureTool.SelectedIndex = 0
        }
    }
})

# Settings - CaptureScenario list
$SyncHash.CaptureScenario.add_SelectionChanged({
    Write-Log -Message "Capture scenario changed to '$($SyncHash.CaptureScenario.SelectedValue.Content)'" -Source "Main" -MessageType Info

    if ($SyncHash.CaptureScenario.SelectedValue.Content -ne "Default" -and $SyncHash.WiresharkPath -like "") {
        if ($SyncHash.CaptureScenario.SelectedValue.Content -match "Netskope|Zscaler - encrypted tunnel") {
            Write-Log -Message "Unable to use the Netskope and Zscaler (encrypted tunnel) scenarios (Wireshark is required but was not detected)" -Source "Main" -MessageType Error -DisplayInGui
            New-Popup -Title "Invalid capture scenario" -Message "Unable to use the Netskope and Zscaler (encrypted tunnel) scenarios (Wireshark is required but was not detected)" -Buttons OK -Icon Stop | Out-Null
            $SyncHash.CaptureScenario.SelectedIndex = 0
        } else {
            Write-Log -Message "The $($SyncHash.CaptureScenario.SelectedValue.Content) scenario requires a capture on all interfaces and will NOT be filtered (Wireshark not detected)" -Source "Main" -MessageType Warning -DisplayInGui
            New-Popup -Title "Traces will NOT be filtered" -Message "The $($SyncHash.CaptureScenario.SelectedValue.Content) scenario requires a capture on all interfaces and will NOT be filtered (Wireshark not detected)`r`nTrace files can be much larger than expected" -Buttons OK -Icon Exclamation | Out-Null
        }
    } else {
        if ($SyncHash.CaptureScenario.SelectedValue.Content -match "Netskope" -and ((-not (Test-Path "$($SyncHash.WiresharkPath)\editcap.exe")) -or (-not (Test-Path "$($SyncHash.WiresharkPath)\mergecap.exe")))) {
            Write-Log -Message "Unable to use the Netskope scenario (editcap.exe and mergecap.exe are required Wireshark components but were not detected)" -Source "Main" -MessageType Error -DisplayInGui
            New-Popup -Title "Invalid capture scenario" -Message "Unable to use the Netskope scenario (editcap.exe and mergecap.exe are required Wireshark components but were not detected)" -Buttons OK -Icon Stop | Out-Null
            $SyncHash.CaptureScenario.SelectedIndex = 0
        }
        if ($SyncHash.CaptureScenario.SelectedValue.Content -match "Zscaler - encrypted tunnel" -and (-not (Test-Path "$($SyncHash.WiresharkPath)\mergecap.exe"))) {
            Write-Log -Message "Unable to use the Zscaler (encrypted tunnel) scenario (mergecap.exe is a required Wireshark component but was not detected)" -Source "Main" -MessageType Error -DisplayInGui
            New-Popup -Title "Invalid capture scenario" -Message "Unable to use the Zscaler (encrypted tunnel) scenario (mergecap.exe is a required Wireshark component but was not detected)" -Buttons OK -Icon Stop | Out-Null
            $SyncHash.CaptureScenario.SelectedIndex = 0
        }
    }
    
    if ($SyncHash.CaptureScenario.SelectedValue.Content -eq "Netskope") {
        if ((Get-Service | Where-Object { $_.DisplayName -match "Netskope Client" }).Status -eq "Running") {
            Write-Log -Message "Netskope client is running" -Source "Main" -MessageType Info
            if (Test-Path "C:\Program Files (x86)\netskope\stagent\nsdiag.exe") {
                Write-Log -Message "Netskope capture tool is available" -Source "Main" -MessageType Info
            } else {
                Write-Log -Message "Unable to use the Netskope scenario (Netskope capture tool 'nsdiag.exe' was not found)" -Source "Main" -MessageType Error -DisplayInGui
                New-Popup -Title "Netskope capture tool not found" -Message "Unable to use the Netskope scenario (Netskope capture tool 'nsdiag.exe' was not found)" -Buttons OK -Icon Stop | Out-Null
                $SyncHash.CaptureScenario.SelectedIndex = 0
            }
        } elseif ((Get-Service | Where-Object { $_.DisplayName -match "Netskope Client" }).Status -eq "Stopped") {
            Write-Log -Message "Unable to use the Netskope scenario (Netskope Agent is not running)" -Source "Main" -MessageType Error -DisplayInGui
            New-Popup -Title "Netskope Agent not running" -Message "Unable to use the Netskope scenario (Netskope Agent is not running)" -Buttons OK -Icon Stop | Out-Null
            $SyncHash.CaptureScenario.SelectedIndex = 0
        } else {
            Write-Log -Message "Unable to use the Netskope scenario (Netskope Agent is not installed)" -Source "Main" -MessageType Error -DisplayInGui
            New-Popup -Title "Netskope Agent not installed" -Message "Unable to use the Netskope scenario (Netskope Agent is not installed)" -Buttons OK -Icon Stop | Out-Null
            $SyncHash.CaptureScenario.SelectedIndex = 0
        }
    }

    if ($SyncHash.CaptureScenario.SelectedValue.Content -eq "Zscaler - encrypted tunnel") {
        if ((Get-Service | Where-Object { $_.DisplayName -match "ZSATunnel" }).Status -eq "Running") {
            Write-Log -Message "Zscaler tunnel service is running" -Source "Main" -MessageType Info
            Write-Log -Message "Zscaler (encrypted tunnel) scenario is available" -Source "Main" -MessageType Info
        } elseif ((Get-Service | Where-Object { $_.DisplayName -match "ZSATunnel" }).Status -eq "Stopped") {
            Write-Log -Message "Unable to use the Zscaler (encrypted tunnel) scenario (Zscaler tunnel service is not running)" -Source "Main" -MessageType Error -DisplayInGui
            New-Popup -Title "Zscaler tunnel service not running" -Message "Unable to use the Zscaler (encrypted tunnel) scenario (Zscaler tunnel service is not running)" -Buttons OK -Icon Stop | Out-Null
            $SyncHash.CaptureScenario.SelectedIndex = 0
        } else {
            Write-Log -Message "Unable to use the Zscaler (encrypted tunnel) scenario (Zscaler tunnel service is not installed)" -Source "Main" -MessageType Error -DisplayInGui
            New-Popup -Title "Zscaler tunnel service not installed" -Message "Unable to use the Zscaler (encrypted tunnel) scenario (Zscaler tunnel service is not installed)" -Buttons OK -Icon Stop | Out-Null
            $SyncHash.CaptureScenario.SelectedIndex = 0
        }
    }
})

# Settings - Browse Output path
$SyncHash.btn_Browse.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_Browse.Content)' button" -Source "Main" -MessageType Info

    # Location dialog for selecting folder
    $FolderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $FolderDialog.RootFolder = "MyComputer"
    $FolderDialog.SelectedPath = $SyncHash.OutputPath.text
    $FolderDialog.ShowDialog() | Out-Null

    if ($FolderDialog.SelectedPath -ne $SyncHash.OutputPath.text) {
        $SyncHash.OutputPath.text = $FolderDialog.SelectedPath
        Write-Log -Message "Output folder set to $($SyncHash.OutputPath.text)" -Source "Main" -MessageType Info -DisplayInGui
    } else {
        Write-Log -Message "Folder unchanged" -Source "Main" -MessageType Info
    }

})

# Settings - App registration Checked
$SyncHash.cb_AppRegistration.Add_Checked({
    Write-Log -Message "App registration button checked" -Source "Main" -MessageType Info
    Set-SettingsVisibility
})

# Settings - App registration Unchecked
$SyncHash.cb_AppRegistration.Add_Unchecked({
    Write-Log -Message "App registration button unchecked" -Source "Main" -MessageType Info
    Set-SettingsVisibility
})

# Settings - Debug Mode Checked
$SyncHash.cb_DebugMode.Add_Checked({
    Write-Log -Message "Debug mode button checked" -Source "Main" -MessageType Info
})

# Settings - Debug Mode Unchecked
$SyncHash.cb_DebugMode.Add_Unchecked({
    Write-Log -Message "Debug mode button unchecked" -Source "Main" -MessageType Info
})

# Single Collection - Runall Checked
$SyncHash.cb_Network_RunAll.Add_Checked({
    $SyncHash.cb_Network_IPConfig.IsChecked = $true
    $SyncHash.cb_Network_Tracert.IsChecked = $true
    $SyncHash.cb_Network_DNSLookup.IsChecked = $true
    $SyncHash.cb_Network_EXO.IsChecked = $true
    $SyncHash.cb_Network_Teams.IsChecked = $true
    if ( $SyncHash.cb_Network_SPO.IsEnabled -eq $true ) { $SyncHash.cb_Network_SPO.IsChecked = $true }
    if ( $SyncHash.cb_Network_Viva.IsEnabled -eq $true ) { $SyncHash.cb_Network_Viva.IsChecked = $true }
    if ( $SyncHash.cb_Network_Copilot.IsEnabled -eq $true ) { $SyncHash.cb_Network_Copilot.IsChecked = $true }
    if ( $SyncHash.cb_Network_MicrosoftDomain.IsEnabled -eq $true ) { $SyncHash.cb_Network_MicrosoftDomain.IsChecked = $true }
    if ( $SyncHash.cb_Network_FileTransfer.IsEnabled -eq $true ) { $SyncHash.cb_Network_FileTransfer.IsChecked = $true }
    $SyncHash.cb_Network_TeamsMediaQuality.IsChecked = $true
})

# Single Collection - Runall Unchecked
$SyncHash.cb_Network_RunAll.Add_Unchecked({
    $SyncHash.cb_Network_IPConfig.IsChecked = $false
    $SyncHash.cb_Network_Tracert.IsChecked = $false
    $SyncHash.cb_Network_DNSLookup.IsChecked = $false
    $SyncHash.cb_Network_EXO.IsChecked = $false
    $SyncHash.cb_Network_Teams.IsChecked = $false
    $SyncHash.cb_Network_SPO.IsChecked = $false
    $SyncHash.cb_Network_Viva.IsChecked = $false
    $SyncHash.cb_Network_Copilot.IsChecked = $false
    $SyncHash.cb_Network_MicrosoftDomain.IsChecked = $false
    $SyncHash.cb_Network_FileTransfer.IsChecked = $false
    $SyncHash.cb_Network_TeamsMediaQuality.IsChecked = $false
})

# Single Collection - Output check
$SyncHash.btn_Network_OutputCheck.Add_Click({
    Write-Log -Message "User clicked the '$($SyncHash.btn_Network_OutputCheck.Content)' button" -Source "Main" -MessageType Info
    Start-AsyncTask -Workload OutputCheck
    
})

# Single Collection - Collection
$SyncHash.btn_Single_collect.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_Single_collect.Content)' button" -Source "Main" -MessageType Info

    # If collection was already started, use the button to stop tasks and set it back to "Collect"
    if ($SyncHash.CollectionInProgress -eq $true) {
        Write-Log -Message "Stopping running tasks" -Source "Main" -MessageType Info -DisplayInGui
        $SyncHash.CollectionInProgress = $false
        Write-Log -Message "Stopping running Teams test calls" -Source "Main" -MessageType Info
        Stop-RunningProcess -ProcessName "NetworkAssessmentTool"
        Write-Log -Message "Stopping Powershell processes for each running task" -Source "Main" -MessageType Info
        Stop-RunningProcess -ProcessID $SyncHash.TestsStates.PID
        $SyncHash.TestsStates | ForEach-Object {$_.State = "Idle"}

        Write-Log -Message "Updating tests status in interface" -Source "Main" -MessageType Info
        Update-TestsStatusLabel
        Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Value -Value 0
        Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Maximum -Value 1
    
    # If collection wasn't started yet, start it and change the button to "Stop"
    } else {

        # Setting Progress bar to 0
        Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Value -Value 0

        Write-Log -Message "Setting up one-time collection" -Source "Main" -MessageType Info

        # Setting up the tasks status
        $SyncHash.TestsStates = @()
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "IPConfig" ; NetworkTrace = $false ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_IPConfig_Status" ; Priority=1 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "Tracert" ; NetworkTrace = $false ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_Tracert_Status" ; Priority=2 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "DNSLookup" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_DNSLookup_Status" ; Priority=3 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "EXO" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_EXO_Status" ; Priority=4 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "Teams" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_Teams_Status" ; Priority=5 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "SPO" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_SPO_Status" ; Priority=6 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "Viva" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_Viva_Status" ; Priority=7 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "Copilot" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_Copilot_Status" ; Priority=8 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "MicrosoftDomain" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_MicrosoftDomain_Status" ; Priority=9 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "FileTransfer" ; NetworkTrace = $true ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_FileTransfer_Status" ; Priority=10 })
        $SyncHash.TestsStates += New-Object PSObject -Property ([ordered]@{ TestName = "TeamsMediaQuality" ; NetworkTrace = $false ; State = "Idle" ; PID = $null ; StatusLabelName = "lbl_Network_TeamsMediaQuality_Status" ; Priority=11 })

        # Counting how many tests have been selected, update tasks status and progress bar
        $TestsCount = 0
        if ($SyncHash.cb_Network_IPConfig.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "IPConfig"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_IPConfig_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_IPConfig_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_Tracert.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "Tracert"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Tracert_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Tracert_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_DNSLookup.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "DNSLookup"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_DNSLookup_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_DNSLookup_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_EXO.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "EXO"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_EXO_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_EXO_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_Teams.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "Teams"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Teams_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Teams_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_SPO.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "SPO"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_SPO_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_SPO_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_Viva.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "Viva"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Viva_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Viva_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_Copilot.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "Copilot"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Copilot_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_Copilot_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_MicrosoftDomain.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "MicrosoftDomain"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_MicrosoftDomain_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_MicrosoftDomain_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_FileTransfer.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "FileTransfer"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_FileTransfer_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_FileTransfer_CheckResult" -Property Content -Value "-"
        }
        if ($SyncHash.cb_Network_TeamsMediaQuality.IsChecked -eq $true) {
            $TestsCount++
            ($SyncHash.TestsStates | Where-Object {$_.TestName -eq "TeamsMediaQuality"}).State = "Starting"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_TeamsMediaQuality_CheckResult" -Property foreground -Value "Black"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_TeamsMediaQuality_CheckResult" -Property Content -Value "-"
        }

        if (Get-ScheduledTaskInfo -TaskName "NPA - Trace" -ErrorAction SilentlyContinue) {
            Write-Log -Message "7-days collection has already been scheduled, warning the user" -Source "Main" -MessageType Warning
            $WarningTitle = "7-days collection already scheduled"
            $WarningText = "7-days collection has already been scheduled, starting a new manual trace may interfere with the automated collection`r`n`r`nProceed anyway?"
            $UserAnswer = New-Popup -Title $WarningTitle -Message $WarningText -Buttons "YesNo" -Icon Exclamation -DefaultButton Second

            Switch ($UserAnswer) {
                "6" {
                    Write-Log -Message "Warning acknowledged, launching manual capture anyway" -Source "Main" -MessageType Warning -DisplayInGui
                    $ProceedWithManualCapture = $true
                }
                "7" {
                    Write-Log -Message "Manual capture aborted" -Source "Main" -MessageType Info -DisplayInGui
                    $ProceedWithManualCapture = $false
                }
                default {
                    Write-Log -Message "Unknown response ($UserAnswer), aborting" -Source "Main" -MessageType Error -DisplayInGui
                    $ProceedWithManualCapture = $false
                }
            }
        } elseif ($TestsCount -eq 0) {
            Write-Log -Message "No test have been selected" -Source "Main" -MessageType Info -DisplayInGui
            $ProceedWithManualCapture = $false
        } else {
            $ProceedWithManualCapture = $true
        }

        if ($ProceedWithManualCapture -eq $true) {
            Get-ProxyConfiguration -LogType "Main"
            Get-Settings

            $SyncHash.btn_Single_collect.Content = "Stop"
            $SyncHash.CollectionInProgress = $true
        
            Set-OutputFolders

            Copy-RunlogAndSettingsToOutputFolder

            Update-TestsStatusLabel

            if ($TestsCount -eq 1) {
                Write-Log -Message "Only 1 test have been selected to run" -Source "Main" -MessageType Info -DisplayInGui
            } else {
                Write-Log -Message "$TestsCount tests have been selected to run" -Source "Main" -MessageType Info -DisplayInGui
            }
            Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Maximum -Value $TestsCount

            if ($SyncHash.cb_Network_IPConfig.IsChecked -eq $true) {
                Start-AsyncTask -Workload IPConfig
            }            

            if ($SyncHash.cb_Network_Tracert.IsChecked -eq $true) {
                Start-AsyncTask -Workload Tracert
            }

            if ($SyncHash.cb_Network_DNSLookup.IsChecked -eq $true) {
                Start-AsyncTask -Workload DNSLookup
            }

            if ($SyncHash.cb_Network_EXO.IsChecked -eq $true) {
                Start-AsyncTask -Workload EXO
            }

            if ($SyncHash.cb_Network_Teams.IsChecked -eq $true) {
                Start-AsyncTask -Workload Teams
            }

            if ($SyncHash.cb_Network_SPO.IsChecked -eq $true) {
                Start-AsyncTask -Workload SPO
            }

            if ($SyncHash.cb_Network_Viva.IsChecked -eq $true) {
                Start-AsyncTask -Workload Viva
            }

            if ($SyncHash.cb_Network_Copilot.IsChecked -eq $true) {
                Start-AsyncTask -Workload Copilot
            }

            if ($SyncHash.cb_Network_MicrosoftDomain.IsChecked -eq $true) {
                Start-AsyncTask -Workload MicrosoftDomain
            }

            if ($SyncHash.cb_Network_FileTransfer.IsChecked -eq $true) {
                Start-AsyncTask -Workload FileTransfer
            }

            if ($SyncHash.cb_Network_TeamsMediaQuality.IsChecked  -eq $true) {

                Start-AsyncTask -Workload TeamsMediaQuality
            }                        

            Start-AsyncTask -Workload Status

        }
    }

})

# 7-Days Collection - Schedule
$SyncHash.btn_Schedule_7Day_Collection.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_Schedule_7Day_Collection.Content)' button" -Source "Main" -MessageType Info

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $Outputpath = $CurrentSettings.OutputPath

    $OutputFileCheckResults = Get-OutputFileCheckResult
    if (($OutputFileCheckResults | Where-Object {$_.CheckResult -eq "-"})) {
        Write-Log -Message "Some of the tests have not been validated ($( ($OutputFileCheckResults | Where-Object {$_.CheckResult -eq "-"}) -join "/" ))" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
        $WarningTitle = "Tests not validated"
        $WarningText = "Some of the test have not been validated`r`n`r`n"
        $WarningText += "Please use the 'Check output' button before proceeding"
        New-Popup -Title $WarningTitle -Message $WarningText -Buttons OK -Icon Stop | Out-Null
        Write-Log -Message "Moving user back to the one-time collection tab" -Source "Main - TaskScheduling" -MessageType Info
        $SyncHash.tabControl.SelectedIndex = 2
        return
    } elseif (($OutputFileCheckResults | Where-Object {$_.CheckResult -ne "V"})) {
        Write-Log -Message "Some of the tests failed automated validation ($( ($OutputFileCheckResults | Where-Object {$_.CheckResult -ne "V"}) -join "/" ))" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
        $WarningTitle = "Tests not valid"
        $WarningText = "Some of the tests failed automated validation:`r`n`r`n"
        $OutputFileCheckResults | Where-Object {$_.CheckResult -ne "V"} | ForEach-Object {
            switch ($_.CheckResult) {
                "X" { $ValidationReason = "Error" }
                "/!\" { $ValidationReason = "Warning" }
                "-?-" { $ValidationReason = "Unknown" }
            }
            $WarningText += "$($_.TestName) - $ValidationReason`r`n"
        }
        $WarningText += "`r`n"
        $WiresharkPath = $CurrentSettings.WiresharkPath
        if (-not (Test-Path "$WiresharkPath\tshark.exe")) {
            Write-Log -Message "Tshark (Wireshark) cannot be found, network traces could not be validated" -Source "Main - OutputCheck - $Workload" -MessageType Warning
            $WarningText += "Tshark (Wireshark) cannot be found, network traces could not be validated`r`n`r`n"
        }
        $WarningText += "Please check the logs for more details`r`n`r`n"
        $WarningText += "Do you confirm that you want to proceed anyway?"
        $UserAnswer = New-Popup -Title $WarningTitle -Message $WarningText -Buttons "YesNo" -Icon Exclamation -DefaultButton Second
        if ($UserAnswer -eq 6) {
            Write-Log -Message "User confirmed that tests were NOT valid" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
        } else {
            Write-Log -Message "User cancelled the 7-Days collection" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
            Write-Log -Message "Moving user back to the one-time collection tab" -Source "Main - TaskScheduling" -MessageType Info
            $SyncHash.tabControl.SelectedIndex = 2
            return
        }
    } elseif (-not ($OutputFileCheckResults | Where-Object {$_.CheckResult -notlike "V"})) {
        Write-Log -Message "All output files are valid" -Source "Main - TaskScheduling" -MessageType Info
    }

    if (-not (Test-Path $Outputpath)) {
        Write-Log -Message "Outputpath not found, creating" -Source "Main - TaskScheduling" -MessageType Info
        New-Item -Path $Outputpath -ItemType Directory | Out-Null
    }

    Write-Log -Message "Setting up the 7-Days collection" -Source "Main - TaskScheduling" -MessageType Info -DisplayInGui

    Start-AsyncTask -Workload ScheduleTasks

})

# 7-Days Collection - Unschedule
$SyncHash.btn_Unschedule_7Day_Collection.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_Unschedule_7Day_Collection.Content)' button" -Source "Main" -MessageType Info
    Write-Log -Message "Removing scheduled tasks" -Source "Main - TaskScheduling" -MessageType Info -DisplayInGui

    Unregister-ScheduledTask -TaskName "NPA - *" -Confirm:$false

    Start-AsyncTask -Workload ScheduledTasksStatus

})

# Task scheduler
$SyncHash.btn_TaskScheduler.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_TaskScheduler.Content)' button" -Source "Main" -MessageType Info
    Write-Log -Message "Opening Task Scheduler" -Source "Main" -MessageType Info -DisplayInGui
    taskschd.msc

})

$SyncHash.btn_finish_PackageUnlimited.Add_Checked({
    Write-Log -Message "User checked the 'Unlimited' zip size option" -Source "Main" -MessageType Info
    $SyncHash.PackageSizeMB = 0
})

$SyncHash.btn_finish_Package1GB.Add_Checked({
    Write-Log -Message "User checked the '1GB' zip size option" -Source "Main" -MessageType Info
    $SyncHash.PackageSizeMB = 1000
})

$SyncHash.btn_finish_Package500MB.Add_Checked({
    Write-Log -Message "User checked the '500MB' zip size option" -Source "Main" -MessageType Info
    $SyncHash.PackageSizeMB = 500
})

$SyncHash.btn_finish_Package250MB.Add_Checked({
    Write-Log -Message "User checked the '250MB' zip size option" -Source "Main" -MessageType Info
    $SyncHash.PackageSizeMB = 250
})

$SyncHash.btn_finish_Package100MB.Add_Checked({
    Write-Log -Message "User checked the '100MB' zip size option" -Source "Main" -MessageType Info
    $SyncHash.PackageSizeMB = 100
})

# Package files
$SyncHash.btn_finish_Package.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_finish_Package.Content)' button" -Source "Main" -MessageType Info
    if ($SyncHash.btn_finish_Package.Content -eq "Stop") {
        Write-Log -Message "Stopping packaging" -Source "Main - Packaging" -MessageType Warning -DisplayInGui
        $SyncHash.CurrentlyPackaging = $false
    } else {
        Write-Log -Message "Starting packaging" -Source "Main - Packaging" -MessageType Info -DisplayInGui
        $SyncHash.CurrentlyPackaging = $true
        Start-AsyncTask -Workload Package
    }
})

# Task cleanup
$SyncHash.btn_finish_Cleanup.Add_Click({

    Write-Log -Message "User clicked the '$($SyncHash.btn_finish_Cleanup.Content)' button" -Source "Main" -MessageType Info
    Write-Log -Message "Running cleanup" -Source "Main" -MessageType Info -DisplayInGui

    Write-Log -Message "Removing existing registered tasks" -Source "Main" -MessageType Info -DisplayInGui
    Unregister-ScheduledTask -TaskName "NPA - *" -Confirm:$false

    $TracemasterLockfile = "$env:NPAPath\tracemaster.lck"
    if (Test-Path $TracemasterLockfile) {
        Write-Log -Message "Stopping running 7-days capture" -Source "Main" -MessageType Info -DisplayInGui
        $ActiveProcesses = Get-Content -Path $TracemasterLockfile
        Stop-RunningProcess -ProcessID $ActiveProcesses
        Remove-Item -Path $TracemasterLockfile -Force -ErrorAction SilentlyContinue
    }

    Write-Log -Message "Stopping running Teams test calls" -Source "Main" -MessageType Info
    Stop-RunningProcess -ProcessName "NetworkAssessmentTool"
    Stop-AllNetworkTraces -LogType "Main"

    Write-Log -Message "Cleanup completed" -Source "Main" -MessageType Info -DisplayInGui

})

$SyncHash.btn_Runlog.Add_Click({
    Write-Log -Message "User clicked the '$($SyncHash.btn_Runlog.Content)' button" -Source "Main" -MessageType Info
    Write-Log -Message "Opening Runlog" -Source "Main" -MessageType Info -DisplayInGui
    Start-Process "$env:NPAPath\NPARunlog.log"
})

$SyncHash.btn_Open_Output.Add_Click({
    Write-Log -Message "User clicked the '$($SyncHash.btn_Open_Output.Content)' button" -Source "Main" -MessageType Info
    if (Test-Path $SyncHash.OutputPath.text) {
        Write-Log -Message "Opening output folder" -Source "Main" -MessageType Info -DisplayInGui
        explorer.exe $SyncHash.OutputPath.text
    } else {
        Write-Log -Message "Output folder doesn't exist yet, opening parent folder" -Source "Main" -MessageType Info -DisplayInGui
        explorer.exe (Split-Path $SyncHash.OutputPath.text)
    }
})

$SyncHash.Btn_Diag_Logs.Add_Click({
    Write-Log -Message "User clicked the '$($SyncHash.Btn_Diag_Logs.Content)' button" -Source "Main" -MessageType Info
    Write-DiagLogs
})

$SyncHash.Window.Add_Closed({
    Write-Log -Message "DataCollection interface is closing" -Source "Main" -MessageType Info -DisplayInGui

    if ($SyncHash.btn_finish_Package.content -eq "Stop") {
        Write-Log -Message "Stopping packaging on interface closure" -Source "Main" -MessageType Warning -DisplayInGui
        $SyncHash.CurrentlyPackaging = $false
        Start-Sleep -Seconds 2
    }

    if (Get-ScheduledTaskInfo -TaskName "NPA - Trace" -ErrorAction SilentlyContinue) {
        Write-Log -Message "Trace tasks have already been scheduled, not stopping running traces" -Source "Main" -MessageType Info
    } else {
        $SyncHash.CollectionInProgress = $false
        Write-Log -Message "Stopping running Teams test calls" -Source "Main" -MessageType Info
        Stop-RunningProcess -ProcessName "NetworkAssessmentTool"
        Stop-AllNetworkTraces -LogType "Main"
        Write-Log -Message "Stopping Powershell processes for each running task" -Source "Main" -MessageType Info
        Stop-RunningProcess -ProcessID $SyncHash.TestsStates.PID

        #clear lock file if present
        try { Remove-Item "$env:NPAPath\lock.lck" -ErrorAction SilentlyContinue }
        catch {}
    }

    Write-Log -Message "Closing DataCollection interface" -Source "Main" -MessageType Info -DisplayInGui

})

if ($SyncHash.CaptureTool.SelectedValue.Content -eq "Netsh" -and $SyncHash.RunningAsAdmin -eq $false) {
    Write-Log -Message "Unable to use Netsh as the capture tool (Netsh trace requires admin privileges)" -Source "Main" -MessageType Error -DisplayInGui
    if ($SyncHash.WiresharkPath -notlike "") {
        Write-Log -Message "Defaulting to Wireshark as the capture tool" -Source "Main" -MessageType Info
        $SyncHash.CaptureTool.SelectedIndex = 1
    } elseif ($SyncHash.NetmonPath -notlike "") {
        Write-Log -Message "Defaulting to Netmon as the capture tool" -Source "Main" -MessageType Info
        $SyncHash.CaptureTool.SelectedIndex = 2
    } else {
        Write-Log -Message "No capture tool available, please install Wireshark or Netmon, or run script as admin" -Source "Main" -MessageType Error -DisplayInGui
        New-Popup -Title "No capture tool available" -Message "Please install Wireshark or Netmon, or run script as admin" -Buttons OK -Icon Stop | Out-Null
        return
    }
}

if ($SyncHash.TabControl.Items[3].IsEnabled -eq $true) {
    # Switch to 7-days collection tab if the tasks have already been scheduled
    if (Get-ScheduledTaskInfo -TaskName "NPA - Trace" -ErrorAction SilentlyContinue) {
        Write-Log -Message "Switching to 7-days collection as tasks have already been scheduled" -Source "Main" -MessageType Info
        $SyncHash.tabControl.SelectedIndex = 3
    } else {
        Start-AsyncTask -Workload ScheduledTasksStatus
    }
}

#Start the GUI
Write-Log -Message "Displaying GUI" -Source "Main" -MessageType Info
Write-Log -Message "DataCollection tool is ready" -Source "Main" -MessageType Info -DisplayInGui
$SyncHash.Window.ShowDialog() | Out-Null