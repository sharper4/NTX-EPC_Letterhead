﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - Copilot"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "Copilot" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

	# Fetching settings
	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$OutputPath = $CurrentSettings.OutputPath
	$TenantType = $CurrentSettings.TenantType[1]
	$Endpoints = (Get-Content $env:NPAPath\scripts\endpoints.json | ConvertFrom-Json).$TenantType
	$CopilotWebFQDN = $Endpoints.CopilotWeb
	$CopilotWorkFQDN = $Endpoints.CopilotWork
	$CopilotOfficeFQDN = $Endpoints.CopilotOffice
	$ProxyConfiguration = $CurrentSettings.ProxyConfiguration
	Get-ProxyCredentials

	Set-OutputFolders

	Wait-LockFile -LockFile $Lockfile -Workload Copilot

	Write-Log -Message "Tests started" -Source "Copilot" -MessageType Info
	Set-Content -Value "Copilot" -Path $Lockfile -ErrorAction SilentlyContinue

	$OverallTestStartTime = Get-Date
	$OverallErrorDetails = @()

	$WebSocketCSVFileOutput = Join-Path -Path $OutputPath -ChildPath '\websocket.csv'

	$CopilotTypeList = @()
	$CopilotTypeList += "CopilotWeb"
	$CopilotTypeList += "CopilotWork"
	$CopilotTypeList += "CopilotOffice"

	foreach ($CopilotType in $CopilotTypeList) {
		
		$CopilotName = $CopilotType -replace '(Copilot)(.*)','$1 $2'
		$LogType = $CopilotType -replace '(Copilot)(.*)','$1 - $2'
		$CopilotFQDN, $CopilotURL = switch ($CopilotType) {
			"CopilotWeb" {$CopilotWebFQDN ; "https://$CopilotWebFQDN/"}
			"CopilotWork" {$CopilotWorkFQDN ; "https://$CopilotWorkFQDN/Chat"}
			"CopilotOffice" {$CopilotOfficeFQDN ; "wss://$CopilotOfficeFQDN/"}
		}

		Write-Log -Message "Starting $CopilotName connectivity check" -Source "$LogType" -MessageType Info

		$TestStartTime = Get-Date
		$ErrorDetails = @()

		# Setting up the destination
		Write-Log -Message "Tests will be carried with URL '$($CopilotURL -replace '((https|wss)://.*?)/.*','$1')'" -Source "$LogType" -MessageType Info

		# Testing which interface is used
		if ($ProxyConfiguration -match "PAC=") {
			$TargetInterface = $null
			Write-Log -Message "Proxy auto configuration (PAC) is used, unable to determine which interface will be used to send queries" -Source "$LogType" -MessageType Info
		} else {
			if ($ProxyConfiguration -match "Static=") {
				$Proxy = ($ProxyConfiguration -replace '.*Static=(.*)','$1')
				$TargetFqdn,$TargetPort = $Proxy -split ':'
				Write-Log -Message "Static proxy is used ($Proxy), checking which interface will be used to send queries" -Source "$LogType" -MessageType Info
			} else {
				$TargetFqdn,$TargetPort = $CopilotFQDN,"443"
				Write-Log -Message "No explicit proxy is used, checking which interface will be used to send queries" -Source "$LogType" -MessageType Info
			}
			$ConnectionTest = Test-NetConnection $TargetFqdn -Port $TargetPort
			if ($ConnectionTest.TcpTestSucceeded -eq $true) {
				$TargetInterface = $ConnectionTest.InterfaceAlias
				Write-Log -Message "Traffic will be sent on interface '$TargetInterface'" -Source "$LogType" -MessageType Info
			} else {
				$TargetInterface = $null
				Write-Log -Message "Unable to reach the destination, unable to determine which interface will be used to send queries" -Source "$LogType" -MessageType Warning
			}
		}

		$Timestamp = Get-DateInFile
		$FileTimestamp = Get-DateInFileName
		$OutputFile = Join-Path -Path $Outputpath -ChildPath "$FileTimestamp-$CopilotType.pcapng"

		Start-NetworkTrace -Workload Copilot -OutputFile $OutputFile -TargetInterface $TargetInterface

		$InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
		# Set TCP idle timeout to 5 seconds
		[System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

		Write-Log -Message "Starting connection" -Source "$LogType" -MessageType Info
		if ($CopilotType -eq "CopilotWeb" -or $CopilotType -eq "CopilotWork") {
			try {
				$CopilotConnectivity = Invoke-WebRequest -Uri $CopilotURL -UserAgent (Get-UserAgent) -UseBasicParsing -MaximumRedirection 0 -ErrorAction SilentlyContinue

				if ($CopilotConnectivity.statuscode -notmatch "200|301|302") {
					Write-Log -Message "Failed to connect to '$CopilotURL' (HTTP code $($CopilotConnectivity.statuscode))" -Source "$LogType" -MessageType Error
					$CopilotConnectivity.Headers.Keys | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
						Write-Log -Message "$_ = $($CopilotConnectivity.Headers[$_])" -Source "$LogType" -MessageType Error
					}
					$ErrorDetails += "Failed to connect (HTTP code $($CopilotConnectivity.statuscode))"
					$OverallErrorDetails += "Failed to connect (HTTP code $($CopilotConnectivity.statuscode))"
				} else {
					Write-Log -Message "Connected successfully to '$CopilotURL'" -Source "$LogType" -MessageType Info
					$FrontDoorCode = Get-FrontDoorFromHTTPResponse -HTTPResponse $CopilotConnectivity
					if ($FrontDoorCode -notlike "") {
						Write-Log -Message "$CopilotName Front Door: '$FrontDoorCode'" -Source "$LogType" -MessageType Info
						Resolve-DnsName -Name "$FrontDoorCode.frontdoor.$CopilotType.office365.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
					} else {
						Write-Log -Message "$CopilotName Front Door not detected" -Source "$LogType" -MessageType Warning
					}
					Write-Log -Message "Attempting DNS resolution of '$CopilotFQDN'" -Source "$LogType" -MessageType Info
					Resolve-DnsName -Name $CopilotFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
				}
			} catch {
				Write-Log -Message "Failed to connect to '$CopilotURL' with exception: $($_.Exception.Message)" -Source "$LogType" -MessageType Error
				if ($_.Exception.Response) {
					$ErrorResponse = $_
					Write-Log -Message "Known headers in response:" -Source "$LogType" -MessageType Error
					$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
						Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "$LogType" -MessageType Error
					}
				}
				$ErrorDetails += "Failed to connect to '$CopilotURL' with exception: $($_.Exception.Message)"
				$OverallErrorDetails += "Failed to connect to '$CopilotURL' with exception: $($_.Exception.Message)"
			}
		} else {
			try {
				$CurrentWebSocketConnection = New-Object PSObject -Property ([ordered]@{
					Timestamp			= $Timestamp
					Service				= $CopilotType
					Target          	= $CopilotFQDN
					WSSConnectSuccess	= $false
					WSSQuerySuccess		= $false
					WSSResponseSuccess	= $false
					WSSExpectedResponse	= $false
					FrontDoor			= $null
				})

				$WebSocket = New-Object System.Net.WebSockets.ClientWebSocket
				$CancellationToken = New-Object System.Threading.CancellationToken($false)
				$CancellationTokenSource = New-Object System.Threading.CancellationTokenSource

				$ConnectResult = $WebSocket.ConnectAsync($CopilotURL, $CancellationTokenSource.Token)
				while ($ConnectResult.GetAwaiter().IsCompleted -eq $false) { Start-Sleep -Milliseconds 500 }
				
				if ($ConnectResult.Status -ne "Faulted") {
					$CurrentWebSocketConnection.WSSConnectSuccess = $true
					Write-Log -Message "Connected successfully to '$CopilotURL'" -Source "$LogType" -MessageType Info
					
					Write-Log -Message "Generating websocket response buffer" -Source "$LogType" -MessageType Info
					$ClientBuffer = [Net.WebSockets.WebSocket]::CreateClientBuffer(1024,1024)
					$ReceiveResult = $WebSocket.ReceiveAsync($ClientBuffer, $CancellationTokenSource.token)

					Write-Log -Message "Generating websocket command" -Source "$LogType" -MessageType Info
					$PingText = '{"protocolVersion":2,"H_":{"T_":"AugLoop_Session_Protocol_SessionInitMessage","B_":["AugLoop_Session_Protocol_Message"]}}'
					$PingCommandBytesArray = [System.Text.Encoding]::UTF8.GetBytes($PingText)
					$PingCommandBytesArraySegment = New-Object System.ArraySegment[byte] -ArgumentList @(,$PingCommandBytesArray)
		
					Write-Log -Message "Sending websocket command" -Source "$LogType" -MessageType Info
					$SendResult = $WebSocket.SendAsync($PingCommandBytesArraySegment,[System.Net.WebSockets.WebSocketMessageType]::Text, $true, $CancellationToken)

					Start-Sleep -Seconds 1
		
					if ($SendResult.Status -ne "Faulted" -and $SendResult.IsCompleted -eq $true) {
						$CurrentWebSocketConnection.WSSQuerySuccess = $true
						Write-Log -Message "Websocket command sent successfully" -Source "$LogType" -MessageType Info
		
						Start-Sleep -Seconds 1
						
						Write-Log -Message "Checking server response" -Source "$LogType" -MessageType Info
						if ($ReceiveResult.Status -ne "Faulted" -and $ReceiveResult.IsCompleted -eq $true) {
							$CurrentWebSocketConnection.WSSResponseSuccess = $true
							Write-Log -Message "Got a response from the server, checking actual content of the response" -Source "$LogType" -MessageType Info
							$RawServiceResponse = [Text.Encoding]::UTF8.GetString($ClientBuffer, 0, $ReceiveResult.Result.Count)
							
							if ($RawServiceResponse -match "sessionUrlBase") {
								$CurrentWebSocketConnection.WSSExpectedResponse = $true
								Write-Log -Message "Got a valid response from the server" -Source "$LogType" -MessageType Info
								$ServiceResponse = $RawServiceResponse | ConvertFrom-Json
								$FrontDoorCode = $ServiceResponse.sessionUrlBase -replace 'https://(.*?)\.augloop\.svc\.cloud\.microsoft/.*','$1'
								if ($FrontDoorCode -notlike "") {
									Write-Log -Message "$CopilotName Front Door: '$FrontDoorCode'" -Source "$LogType" -MessageType Info
									Resolve-DnsName -Name "$FrontDoorCode.frontdoor.$CopilotType.office365.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
									$CurrentWebSocketConnection.FrontDoor = $FrontDoorCode
								} else {
									Write-Log -Message "$CopilotName Front Door not detected" -Source "$LogType" -MessageType Warning
								}
							} else {
								Write-Log -Message "Got an unexpected response from the server ($RawServiceResponse)" -Source "$LogType" -MessageType Error
								$ErrorDetails += "Received an invalid response from service - $RawServiceResponse"
								$OverallErrorDetails += "Received an invalid response from service - $RawServiceResponse"
							}
						} else {
							if ($ReceiveResult.Status -eq "WaitingForActivation") {
								Write-Log -Message "Failed to receive server response (No response received)" -Source "$LogType" -MessageType Error
								$ErrorDetails += "Failed to receive server response (No response received)"
								$OverallErrorDetails += "Failed to receive server response (No response received)"
							} else {
								Write-Log -Message "Failed to receive server response (Error $($ReceiveResult.Exception.HResult) - $($ReceiveResult.Exception.GetBaseException()))" -Source "$LogType" -MessageType Error
								$ErrorDetails += "Failed to receive server response (Error $($ReceiveResult.Exception.HResult) - $($ReceiveResult.Exception.GetBaseException()))"
								$OverallErrorDetails += "Failed to receive server response (Error $($ReceiveResult.Exception.HResult) - $($ReceiveResult.Exception.GetBaseException()))"
							}
						}			
					} else {
						Write-Log -Message "Failed to send websocket command (Error $($SendResult.Exception.HResult) - $($SendResult.Exception.GetBaseException()))" -Source "$LogType" -MessageType Error
						$ErrorDetails += "Failed to send websocket command (Error $($SendResult.Exception.HResult) - $($SendResult.Exception.GetBaseException()))"
						$OverallErrorDetails += "Failed to send websocket command (Error $($SendResult.Exception.HResult) - $($SendResult.Exception.GetBaseException()))"
					}
					
					Write-Log -Message "Closing websocket connection" -Source "$LogType" -MessageType Info
					$WebSocket.CloseAsync([System.Net.WebSockets.WebSocketCloseStatus]::NormalClosure,"Closing",$CancellationToken) | Out-Null
		
					Write-Log -Message "Attempting DNS resolution of '$CopilotFQDN'" -Source "$LogType" -MessageType Info
					Resolve-DnsName -Name $CopilotFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
				} else {
					if ($ConnectResult.Exception.InnerException.InnerException.Message -notlike "") {
						$ErrorMessage = $ConnectResult.Exception.InnerException.InnerException.Message
					} else {
						$ErrorMessage = $ConnectResult.Exception.GetBaseException()
					}
					Write-Log -Message "Failed to connect to '$CopilotURL' (Error $($ConnectResult.Exception.HResult) - $ErrorMessage)" -Source "$LogType" -MessageType Error
					$ErrorDetails += "Failed to connect (Error $($ConnectResult.Exception.HResult) - $ErrorMessage)"
					$OverallErrorDetails += "Failed to connect (Error $($ConnectResult.Exception.HResult) - $ErrorMessage)"
				}
			} catch {
				Write-Log -Message "Failed to connect to '$CopilotURL' with exception: $($_.Exception.Message)" -Source "$LogType" -MessageType Error
				if ($_.Exception.Response) {
					$ErrorResponse = $_
					Write-Log -Message "Known headers in response:" -Source "$LogType" -MessageType Error
					$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
						Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "$LogType" -MessageType Error
					}
				}
				$ErrorDetails += "Failed to connect to '$CopilotURL' with exception: $($_.Exception.Message)"
				$OverallErrorDetails += "Failed to connect to '$CopilotURL' with exception: $($_.Exception.Message)"
			}

			$Values = ($CurrentWebSocketConnection.Timestamp , $CurrentWebSocketConnection.Service , $CurrentWebSocketConnection.Target , $CurrentWebSocketConnection.WSSConnectSuccess , $CurrentWebSocketConnection.WSSQuerySuccess , $CurrentWebSocketConnection.WSSResponseSuccess , $CurrentWebSocketConnection.WSSExpectedResponse , $CurrentWebSocketConnection.FrontDoor) -join "`t"
			if (-not (Test-Path $WebSocketCSVFileOutput)) {
				#If it is first time we need create file with following structure
				$Headers = ( "Timestamp" , "Service" , "Target" , "WSSConnectSuccess" , "WSSQuerySuccess" , "WSSResponseSuccess" , "WSSExpectedResponse" , "FrontDoor" ) -join "`t"
				Add-Content -Value $Headers -Path $WebSocketCSVFileOutput
			}
			Add-Content -Value $Values -Path $WebSocketCSVFileOutput
		}

		# Reset TCP idle timeout to its initial value
		[System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout

		Stop-NetworkTrace -Workload Copilot -OutputFile $OutputFile

		Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload Copilot

		Write-TestStatus -StartTime $TestStartTime -Type "$CopilotName" -ErrorDetails $ErrorDetails
	}
		
	$NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "Copilot" -MessageType Error
    $OverallErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "Copilot" -MessageType Info
    try {
        if ($null -eq $OverallTestStartTime) {
            $OverallTestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $OverallTestStartTime -Type "Copilot" -ErrorDetails $OverallErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($OverallErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "Copilot" -MessageType Error
    } finally {
        try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "Copilot" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "Copilot" -MessageType Info
    }
}