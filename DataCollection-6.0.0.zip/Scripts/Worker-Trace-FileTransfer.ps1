﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - FileTransfer"
$ErrorActionPreference = 'Stop'
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "FileTransfer" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

	# Fetching settings
	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$Outputpath = $CurrentSettings.OutputPath
	$UseAppRegistration = if ($CurrentSettings.AppRegistration -match "True") {$true} else {$false}
	$OneDriveFQDN = $CurrentSettings.OneDriveFQDN
	$OneDriveURL = $CurrentSettings.OneDriveURL
	$ProxyConfiguration = $CurrentSettings.ProxyConfiguration
	Get-ProxyCredentials

	Set-OutputFolders

	Wait-LockFile -LockFile $Lockfile -Workload FileTransfer

	Write-Log -Message "Tests started" -Source "FileTransfer" -MessageType Info
	Set-Content -Value "FileTransfer" -Path $Lockfile -ErrorAction SilentlyContinue

	$OverallTestStartTime = Get-Date
	$OverallErrorDetails = @()

	# Setting up the destination
	if ($UseAppRegistration -eq $false) {
		if ($OneDriveFQDN -like "") {
			$OneDriveFQDN = "microsoft-my.sharepoint.com"
		}
		$OneDriveURL = "https://$OneDriveFQDN/_layouts/15/"
		Write-Log -Message "Tests will be carried without token with URL '$($OneDriveURL -replace '(https://.*?)/.*','$1')'" -Source "FileTransfer" -MessageType Info
	} else {
		Write-Log -Message "Tests will be carried with token with URL '$($OneDriveURL -replace '(https://.*?)/.*','$1')'" -Source "FileTransfer" -MessageType Info
		
		#Check for token and document library
		if (Test-Path "$env:NPAPath\secret") {
			Write-Log -Message "Fetching secret from file" -Source "FileTransfer" -MessageType Info
			$clientsecret = Get-Secret -path "$env:NPAPath\secret"
			
			Write-Log -Message "Fetching a new access token" -Source "FileTransfer" -MessageType Info
			$SPOAccesstoken = Get-SPOAccessToken -clientid $($CurrentSettings.OneDriveClientid) -clientsecret $clientsecret -tenantid $($CurrentSettings.tenantid) -targetURL $($CurrentSettings.OneDriveURL)

			if ($null -ne $SPOAccesstoken -and $SPOAccesstoken.expires_on) {
				$TokenExpiration = ([DateTime]('1970,1,1')).AddSeconds($SPOAccesstoken.expires_on)
				Write-Log -Message "Fetched access token is valid until '$($TokenExpiration.ToString("yyyy-MM-dd HH:mm:ss"))'" -Source "FileTransfer" -MessageType Info
				Write-Log -Message "Fetching Sharepoint Documents folder name" -Source "FileTransfer" -MessageType Info
				#get document folder
				$DocumentFolder = Get-SPODocumentFolder -token $SPOAccesstoken.access_token -targetURL $CurrentSettings.OneDriveURL
				if ($null -eq $DocumentFolder) {
					Write-Log -Message "Failed to get Sharepoint Documents folder name, can't proceed further" -Source "FileTransfer" -MessageType Error
				} else {
					Write-Log -Message "Documents folder name: $DocumentFolder" -Source "FileTransfer" -MessageType Info
				}

			} else {
				Write-Log -Message "Failed to get a valid access token, can't proceed further" -Source "FileTransfer" -MessageType Error
			}
		} else {
			Write-Log -Message "Unable to fetch secret (file does not exist at path '$env:NPAPath\secret'), can't proceed further" -Source "FileTransfer" -MessageType Error
			$OverallErrorDetails += "No secret file at path '$env:NPAPath\secret'"
		}
	}

	# Testing which interface is used
	if ($ProxyConfiguration -match "PAC=") {
		$TargetInterface = $null
		Write-Log -Message "Proxy auto configuration (PAC) is used, unable to determine which interface will be used to send queries" -Source "FileTransfer" -MessageType Info
	} else {
		if ($ProxyConfiguration -match "Static=") {
			$Proxy = ($ProxyConfiguration -replace '.*Static=(.*)','$1')
			$TargetFqdn,$TargetPort = $Proxy -split ':'
			Write-Log -Message "Static proxy is used ($Proxy), checking which interface will be used to send queries" -Source "FileTransfer" -MessageType Info
		} else {
			$TargetFqdn,$TargetPort = $OneDriveFQDN,"443"
			Write-Log -Message "No explicit proxy is used, checking which interface will be used to send queries" -Source "FileTransfer" -MessageType Info
		}
		$ConnectionTest = Test-NetConnection $TargetFqdn -Port $TargetPort
		if ($ConnectionTest.TcpTestSucceeded -eq $true) {
			$TargetInterface = $ConnectionTest.InterfaceAlias
			Write-Log -Message "Traffic will be sent on interface '$TargetInterface'" -Source "FileTransfer" -MessageType Info
		} else {
			$TargetInterface = $null
			Write-Log -Message "Unable to reach the destination, unable to determine which interface will be used to send queries" -Source "FileTransfer" -MessageType Warning
		}
	}

	if ($UseAppRegistration -eq $false -or $null -ne $DocumentFolder) {

		# Resetting the PreviousFilter variable
		$PreviousFilter = $null
		# Settings the file sizes to test
		$FilesToProcess = @("3MB", "15MB", "45MB")

		foreach ($FileSize in $FilesToProcess) {

			Write-Log -Message "Processing $FileSize file" -Source "FileTransfer" -MessageType Info

			$TestStartTime = Get-Date
			$ErrorDetails = @()

			$FileTimestamp = Get-DateInFileName
			$OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-$($FileSize)UP.pcapng"

			Write-Log -Message "Generating random file" -Source "FileTransfer - SPO $($FileSize)UP" -MessageType Info
			#[byte[]]$FileContent = new-randomfile -filesize $FileSize
			$FileSizeInBytes = [int]($FileSize -replace '(kb|mb|gb)','') * ($FileSize -replace '\d+','1')
			$FileContent = new-object byte[] $FileSizeInBytes
			(new-object Random).NextBytes($FileContent)
			$FileName = (($OutputFile -split "\\")[-1] -replace (".pcapng", ".bin"))

			Start-NetworkTrace -Workload FileTransfer -OutputFile $OutputFile -TargetInterface $TargetInterface

			Write-Log -Message "File Upload start" -Source "FileTransfer - SPO $($FileSize)UP" -MessageType Info
			$HTTPResult = $null
			if ($UseAppRegistration -eq $false) {
				$HTTPResult = New-SPOFileUpload -targeturl $OneDriveURL -content $FileContent -filename $FileName
				Write-Log -Message "File Upload result: $HTTPResult" -Source "FileTransfer - SPO $($FileSize)UP" -MessageType Info
				if ($HTTPResult -notlike "OK") {
					$ErrorDetails += $HTTPResult
					$OverallErrorDetails += $HTTPResult
				}
			} else {
				$HTTPResult = New-SPOFileUpload -targeturl $OneDriveURL -targetfolder $DocumentFolder -token $SPOAccesstoken.access_token -content $FileContent -filename $FileName
				Write-Log -Message "File Upload result: $HTTPResult" -Source "FileTransfer - SPO $($FileSize)UP" -MessageType Info
				$HTTPResult = $null
				$HTTPResult = Test-SPOFileExists -targeturl $CurrentSettings.OneDriveURL -targetfolder $DocumentFolder -token $SPOAccesstoken.access_token -filename $FileName
				Write-Log -Message "Check file result: $HTTPResult" -Source "FileTransfer - SPO $($FileSize)UP" -MessageType Info
				if ($HTTPResult -eq $true) {
					Write-Log -Message "File was found on the Onedrive folder" -Source "FileTransfer - SPO $($FileSize)UP" -MessageType Info
					$FileFound = $true
				} else {
					Write-Log -Message "File was NOT found on the Onedrive folder" -Source "FileTransfer - SPO $($FileSize)UP" -MessageType Error
					$FileFound = $false
					$ErrorDetails += "File not uploaded properly"
					$OverallErrorDetails += "File not uploaded properly"
				}
			}
			
			Stop-NetworkTrace -Workload FileTransfer -OutputFile $OutputFile

			$PreviousFilter = Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload FileTransfer -PreviousFilter $PreviousFilter

			Write-TestStatus -StartTime $TestStartTime -Type "SPO $($FileSize)UP" -ErrorDetails $ErrorDetails

			Start-Sleep -Seconds 2

			if ($UseAppRegistration -eq $false -or $FileFound -eq $true) {

				$TestStartTime = Get-Date
				$ErrorDetails = @()

				$FileTimestamp = Get-DateInFileName
				$OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-$($FileSize)DOWN.pcapng"

				Start-NetworkTrace -Workload FileTransfer -OutputFile $OutputFile -TargetInterface $TargetInterface

				Write-Log -Message "File Download start" -Source "FileTransfer - SPO $($FileSize)DOWN" -MessageType Info
				$HTTPResult = $null
				if ($UseAppRegistration -eq $false) {
					$HTTPResult = New-SPOFileDownload -targeturl $OneDriveURL -filename $FileName
					Write-Log -Message "File Download result: $HTTPResult" -Source "FileTransfer - SPO $($FileSize)DOWN" -MessageType Info
					if ($HTTPResult -notlike "OK") {
						$ErrorDetails += $HTTPResult
						$OverallErrorDetails += $HTTPResult
					}
				} else {
					$HTTPResult = New-SPOFileDownload -targeturl $OneDriveURL -targetfolder $DocumentFolder -token $SPOAccesstoken.access_token -filename $FileName
					Write-Log -Message "File Download result: $HTTPResult" -Source "FileTransfer - SPO $($FileSize)DOWN" -MessageType Info
					if ($HTTPResult -notlike "OK") {
						$ErrorDetails += $HTTPResult
						$OverallErrorDetails += $HTTPResult
					}
					$HTTPResult = $null
					$HTTPResult = Remove-SPOFile -targetURL $CurrentSettings.OneDriveURL -targetfolder $DocumentFolder -token $SPOAccesstoken.access_token -filename $FileName
					Write-Log -Message "Clean up file result: $HTTPResult" -Source "FileTransfer - SPO $($FileSize)DOWN" -MessageType Info
				}

				Stop-NetworkTrace -Workload FileTransfer -OutputFile $OutputFile

				$PreviousFilter = Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload FileTransfer -PreviousFilter $PreviousFilter

				Write-TestStatus -StartTime $TestStartTime -Type "SPO $($FileSize)DOWN" -ErrorDetails $ErrorDetails

				Start-Sleep -Seconds 2

			} else {
				Write-Log -Message "File was NOT uploaded properly, can't proceed with the download test" -Source "FileTransfer - SPO $($FileSize)DOWN" -MessageType Error
				$TestStartTime = Get-Date
				$ErrorDetails = @()
				$ErrorDetails += "File not uploaded properly, can't download"
				$OverallErrorDetails += "File not uploaded properly, can't download"
				Write-TestStatus -StartTime $TestStartTime -Type "SPO $($FileSize)DOWN" -ErrorDetails $ErrorDetails
			}
		}
	}
	$NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "FileTransfer" -MessageType Error
    $OverallErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "FileTransfer" -MessageType Info
    try {
        if ($null -eq $OverallTestStartTime) {
            $OverallTestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $OverallTestStartTime -Type "SPO UP/DOWN" -ErrorDetails $OverallErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($OverallErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "FileTransfer" -MessageType Error
    } finally {
        try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "FileTransfer" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "FileTransfer" -MessageType Info
    }
}