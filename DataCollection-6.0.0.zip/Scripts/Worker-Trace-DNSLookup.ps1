﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - DNSLookup"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
    Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "DNSLookup" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

    # Fetching settings
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
    $OutputPath = $CurrentSettings.OutputPath
    $TenantType = $CurrentSettings.TenantType[1]
    $Endpoints = (Get-Content $env:NPAPath\scripts\endpoints.json | ConvertFrom-Json).$TenantType
    $ExchangeFQDN = $Endpoints.Exchange
    $TeamsMediaFQDN = $Endpoints.TeamsMedia
    $TeamsWebFQDN = $Endpoints.TeamsWeb
    $TeamsPSTNFQDN = $Endpoints.TeamsPSTN
    if ($TenantType -eq "Worldwide") {
        $VivaFQDN = $Endpoints.Viva
        $CopilotWebFQDN = $Endpoints.CopilotWeb
        $CopilotWorkFQDN = $Endpoints.CopilotWork
        $CopilotOfficeFQDN = $Endpoints.CopilotOffice
        $CloudMicrosoftFQDN = $Endpoints.CloudMicrosoft
        $StaticMicrosoftFQDN = $Endpoints.StaticMicrosoft
        $UsercontentMicrosoftFQDN = $Endpoints.UsercontentMicrosoft
    }

    $OneDriveFQDN = $CurrentSettings.OneDriveFQDN
    $OneDriveURL = $CurrentSettings.OneDriveURL
    if ($OneDriveFQDN -like "") {
        if ($TenantType -eq "Worldwide") {
            $OneDriveFQDN = "microsoft-my.sharepoint.com"
        } else {
            $OneDriveFQDN = $OneDriveURL.Split('/')[2]
        }
    }

    Set-OutputFolders

    Wait-LockFile -LockFile $Lockfile -Workload DNSLookup

    Write-Log -Message "Tests started" -Source "DNSLookup" -MessageType Info
    Set-Content -Value "DNS" -Path $Lockfile -ErrorAction SilentlyContinue

    $TestStartTime = Get-Date
    $ErrorDetails = @()

    Write-Log -Message "Gathering DNS Servers" -Source "DNSLookup" -MessageType Info
    $Networks = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter IPEnabled=True
    $DNSServerList = @()
    foreach ($network in $networks) {
        $DNSServerList += $network.dnsServerSearchOrder
    }

    $DNSServerList = $DNSServerList | Sort-Object | Get-Unique

    if ($DNSServerList.count -eq 0) {
        Write-Log -Message "No DNS servers found" -Source "DNSLookup" -MessageType Error
        throw "No DNS servers found"
    }

    Write-Log -Message "The following DNS servers will be tested:" -Source "DNSLookup" -MessageType Info
    Write-Log -Message "$($DNSServerList -join ' - ')" -Source "DNSLookup" -MessageType Info

    Write-Log -Message "The following DNS entries will be tested:" -Source "DNSLookup" -MessageType Info
    Write-Log -Message "Exchange: $ExchangeFQDN" -Source "DNSLookup" -MessageType Info
    Write-Log -Message "Teams web: $TeamsWebFQDN" -Source "DNSLookup" -MessageType Info
    Write-Log -Message "Teams media: $TeamsMediaFQDN" -Source "DNSLookup" -MessageType Info
    Write-Log -Message "Teams PSTN: $TeamsPSTNFQDN" -Source "DNSLookup" -MessageType Info
    Write-Log -Message "Sharepoint: $OneDriveFQDN" -Source "DNSLookup" -MessageType Info
    if ($TenantType -eq "Worldwide") {
        Write-Log -Message "Viva: $VivaFQDN" -Source "DNSLookup" -MessageType Info
        Write-Log -Message "Copilot Web: $CopilotWebFQDN" -Source "DNSLookup" -MessageType Info
        Write-Log -Message "Copilot Work: $CopilotWorkFQDN" -Source "DNSLookup" -MessageType Info
        Write-Log -Message "Copilot Office: $CopilotOfficeFQDN" -Source "DNSLookup" -MessageType Info
        Write-Log -Message "cloud.microsoft: $CloudMicrosoftFQDN" -Source "DNSLookup" -MessageType Info
        Write-Log -Message "static.microsoft: $StaticMicrosoftFQDN" -Source "DNSLookup" -MessageType Info
        Write-Log -Message "usercontent.microsoft: $UsercontentMicrosoftFQDN" -Source "DNSLookup" -MessageType Info
    }

    foreach ($DNSServer in $DNSServerList) {

        # Skip if there's no valid DNS IP address
        if ($DNSServer -like "") { Continue }

        Write-Log -Message "Running lookups for DNS server $DNSServer" -Source "DNSLookup" -MessageType Info

        $FileTimestamp = Get-DateInFileName
        $OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-DNSLookup-$DNSServer.pcapng"
        
        Start-NetworkTrace -Workload DNSLookup -OutputFile $OutputFile

        # Flush DNS
        ipconfig /flushdns | Out-Null
        Start-Sleep -Seconds 1
        $ErrorDetails += Invoke-DNSQuery -Name $ExchangeFQDN -DNSServer $DNSServer
        Start-Sleep -Seconds 1
        $ErrorDetails += Invoke-DNSQuery -Name $TeamsWebFQDN -DNSServer $DNSServer
        Start-Sleep -Seconds 1
        $ErrorDetails += Invoke-DNSQuery -Name $TeamsMediaFQDN -DNSServer $DNSServer
        Start-Sleep -Seconds 1
        $ErrorDetails += Invoke-DNSQuery -Name $TeamsPSTNFQDN -DNSServer $DNSServer
        Start-Sleep -Seconds 1
        $ErrorDetails += Invoke-DNSQuery -Name $OneDriveFQDN -DNSServer $DNSServer
        if ($TenantType -eq "Worldwide") {
            Start-Sleep -Seconds 1
            $ErrorDetails += Invoke-DNSQuery -Name $VivaFQDN -DNSServer $DNSServer
            Start-Sleep -Seconds 1
            $ErrorDetails += Invoke-DNSQuery -Name $CopilotWebFQDN -DNSServer $DNSServer
            Start-Sleep -Seconds 1
            $ErrorDetails += Invoke-DNSQuery -Name $CopilotWorkFQDN -DNSServer $DNSServer
            Start-Sleep -Seconds 1
            $ErrorDetails += Invoke-DNSQuery -Name $CopilotOfficeFQDN -DNSServer $DNSServer
            Start-Sleep -Seconds 1
            $ErrorDetails += Invoke-DNSQuery -Name $CloudMicrosoftFQDN -DNSServer $DNSServer
            Start-Sleep -Seconds 1
            $ErrorDetails += Invoke-DNSQuery -Name $StaticMicrosoftFQDN -DNSServer $DNSServer
            Start-Sleep -Seconds 1
            $ErrorDetails += Invoke-DNSQuery -Name $UsercontentMicrosoftFQDN -DNSServer $DNSServer
        }

        Stop-NetworkTrace -Workload DNSLookup -OutputFile $OutputFile

        Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload DNSLookup

        $NormalScriptCompletion = $true
    }
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "DNSLookup" -MessageType Error
    $ErrorDetails += "Unhandled error: $($_.Exception.Message)"
    $NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "DNSLookup" -MessageType Info
    try {
        if ($null -eq $TestStartTime) {
            $TestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $TestStartTime -Type "DNS" -ErrorDetails $ErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($ErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "DNSLookup" -MessageType Error
    } finally {
        try {
            Remove-Item -Path $Lockfile -Force | Out-Null
        } catch {
            Write-Log -Message "Failed to remove lockfile" -Source "DNSLookup" -MessageType Error
        }
		Write-Log -Message "Task completed" -Source "DNSLookup" -MessageType Info
    }
}