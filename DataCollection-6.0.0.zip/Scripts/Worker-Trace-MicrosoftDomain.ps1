﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - MicrosoftDomain"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "MicrosoftDomain" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

	# Fetching settings
	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$OutputPath = $CurrentSettings.OutputPath
	$TenantType = $CurrentSettings.TenantType[1]
	$Endpoints = (Get-Content $env:NPAPath\scripts\endpoints.json | ConvertFrom-Json).$TenantType
	$CloudMicrosoftFQDN = $Endpoints.CloudMicrosoft
	$StaticMicrosoftFQDN = $Endpoints.StaticMicrosoft
	$UsercontentMicrosoftFQDN = $Endpoints.UsercontentMicrosoft
	$ProxyConfiguration = $CurrentSettings.ProxyConfiguration
	Get-ProxyCredentials

	Set-OutputFolders

	Wait-LockFile -LockFile $Lockfile -Workload MicrosoftDomain

	Write-Log -Message "Tests started" -Source "MicrosoftDomain" -MessageType Info
	Set-Content -Value "MicrosoftDomain" -Path $Lockfile -ErrorAction SilentlyContinue

	$OverallTestStartTime = Get-Date
	$OverallErrorDetails = @()

	$MicrosoftDomainList = @()
	$MicrosoftDomainList += "CloudMicrosoft"
	$MicrosoftDomainList += "StaticMicrosoft"
	$MicrosoftDomainList += "UsercontentMicrosoft"

	foreach ($MicrosoftDomain in $MicrosoftDomainList) {

		$MicrosoftDomainFQDN, $MicrosoftDomainName = switch ($MicrosoftDomain) {
			"CloudMicrosoft" {$CloudMicrosoftFQDN ; "cloud.microsoft"}
			"StaticMicrosoft" {$StaticMicrosoftFQDN ; "static.microsoft"}
			"UsercontentMicrosoft" {$UsercontentMicrosoftFQDN ; "usercontent.microsoft"}
		}

		$LogType = "MicrosoftDomain - $MicrosoftDomain"

		Write-Log -Message "Starting '$MicrosoftDomainName' domain connectivity check" -Source "$LogType" -MessageType Info

		$TestStartTime = Get-Date
		$ErrorDetails = @()

		# Setting up the destination
		$MicrosoftDomainURL = "https://$MicrosoftDomainFQDN"
		Write-Log -Message "Tests will be carried with URL '$MicrosoftDomainURL'" -Source "$LogType" -MessageType Info

		# Testing which interface is used
		if ($ProxyConfiguration -match "PAC=") {
			$TargetInterface = $null
			Write-Log -Message "Proxy auto configuration (PAC) is used, unable to determine which interface will be used to send queries" -Source "$LogType" -MessageType Info
		} else {
			if ($ProxyConfiguration -match "Static=") {
				$Proxy = ($ProxyConfiguration -replace '.*Static=(.*)','$1')
				$TargetFqdn,$TargetPort = $Proxy -split ':'
				Write-Log -Message "Static proxy is used ($Proxy), checking which interface will be used to send queries" -Source "$LogType" -MessageType Info
			} else {
				$TargetFqdn,$TargetPort = $MicrosoftDomainFQDN,"443"
				Write-Log -Message "No explicit proxy is used, checking which interface will be used to send queries" -Source "$LogType" -MessageType Info
			}
			$ConnectionTest = Test-NetConnection $TargetFqdn -Port $TargetPort
			if ($ConnectionTest.TcpTestSucceeded -eq $true) {
				$TargetInterface = $ConnectionTest.InterfaceAlias
				Write-Log -Message "Traffic will be sent on interface '$TargetInterface'" -Source "$LogType" -MessageType Info
			} else {
				$TargetInterface = $null
				Write-Log -Message "Unable to reach the destination, unable to determine which interface will be used to send queries" -Source "$LogType" -MessageType Warning
			}
		}

		$FileTimestamp = Get-DateInFileName
		$OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-$MicrosoftDomain.pcapng"

		Start-NetworkTrace -Workload MicrosoftDomain -OutputFile $OutputFile -TargetInterface $TargetInterface

		$InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
		# Set TCP idle timeout to 5 seconds
		[System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

		Write-Log -Message "Starting connection" -Source "$LogType" -MessageType Info
			try {

				$MicrosoftDomainConnectivity = Invoke-WebRequest -Uri $MicrosoftDomainURL -UserAgent (Get-UserAgent) -UseBasicParsing

				if ($MicrosoftDomainConnectivity.statuscode -notlike "200") {
					Write-Log -Message "Failed to connect to '$MicrosoftDomainURL' (HTTP code $($MicrosoftDomainConnectivity.statuscode))" -Source "$LogType" -MessageType Error
					$MicrosoftDomainConnectivity.Headers.Keys | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
						Write-Log -Message "$_ = $($MicrosoftDomainConnectivity.Headers[$_])" -Source "$LogType" -MessageType Error
					}
					$ErrorDetails += "Failed to connect (HTTP code $($MicrosoftDomainConnectivity.statuscode))"
					$OverallErrorDetails += "Failed to connect (HTTP code $($MicrosoftDomainConnectivity.statuscode))"
				} else {
					Write-Log -Message "Connected successfully to '$MicrosoftDomainURL'" -Source "$LogType" -MessageType Info
					$FrontDoorCode = Get-FrontDoorFromHTTPResponse -HTTPResponse $MicrosoftDomainConnectivity
					if ($FrontDoorCode -notlike "") {
						Write-Log -Message "$MicrosoftDomain Front Door: '$FrontDoorCode'" -Source "$LogType" -MessageType Info
						Resolve-DnsName -Name "$FrontDoorCode.frontdoor.$MicrosoftDomain.office365.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
					} else {
						Write-Log -Message "$MicrosoftDomain Front Door not detected" -Source "$LogType" -MessageType Warning
					}
					Write-Log -Message "Attempting DNS resolution of '$MicrosoftDomainFQDN'" -Source "$LogType" -MessageType Info
					Resolve-DnsName -Name $MicrosoftDomainFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
				}
			} catch {
				Write-Log -Message "Failed to connect to '$MicrosoftDomainURL' with exception: $($_.Exception.Message)" -Source "$LogType" -MessageType Error
				if ($_.Exception.Response) {
					$ErrorResponse = $_
					Write-Log -Message "Known headers in response:" -Source "$LogType" -MessageType Error
					$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
						Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "$LogType" -MessageType Error
					}
				}
				$ErrorDetails += "Failed to connect to '$MicrosoftDomainURL' with exception: $($_.Exception.Message)"
				$OverallErrorDetails += "Failed to connect to '$MicrosoftDomainURL' with exception: $($_.Exception.Message)"
			}

		# Reset TCP idle timeout to its initial value
		[System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout

		Stop-NetworkTrace -Workload MicrosoftDomain -OutputFile $OutputFile

		Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload MicrosoftDomain

		Write-TestStatus -StartTime $TestStartTime -Type "$MicrosoftDomain" -ErrorDetails $ErrorDetails
	}
		
	$NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "MicrosoftDomain" -MessageType Error
    $OverallErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "MicrosoftDomain" -MessageType Info
    try {
        if ($null -eq $OverallTestStartTime) {
            $OverallTestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $OverallTestStartTime -Type "MicrosoftDomain" -ErrorDetails $OverallErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($OverallErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "MicrosoftDomain" -MessageType Error
    } finally {
        try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "MicrosoftDomain" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "MicrosoftDomain" -MessageType Info
    }
}