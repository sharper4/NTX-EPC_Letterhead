﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - EXO"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "EXO" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

	# Fetching settings
	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$OutputPath = $CurrentSettings.OutputPath
	$TenantType = $CurrentSettings.TenantType[1]
	$Endpoints = (Get-Content $env:NPAPath\scripts\endpoints.json | ConvertFrom-Json).$TenantType
	$ExchangeFQDN = $Endpoints.Exchange
	$ProxyConfiguration = $CurrentSettings.ProxyConfiguration
	Get-ProxyCredentials

	Set-OutputFolders

	Wait-LockFile -LockFile $Lockfile -Workload EXO

	Write-Log -Message "Tests started" -Source "EXO" -MessageType Info
	Set-Content -Value "EXO" -Path $Lockfile -ErrorAction SilentlyContinue

	$TestStartTime = Get-Date
	$ErrorDetails = @()

	# Setting up the destination
	$ExchangeURL = "https://$ExchangeFQDN/apc/trans.gif"
	Write-Log -Message "Tests will be carried with URL '$($ExchangeURL -replace '(https://.*?)/.*','$1')'" -Source "EXO" -MessageType Info

	# Testing which interface is used
	if ($ProxyConfiguration -match "PAC=") {
		$TargetInterface = $null
		Write-Log -Message "Proxy auto configuration (PAC) is used, unable to determine which interface will be used to send queries" -Source "EXO" -MessageType Info
	} else {
		if ($ProxyConfiguration -match "Static=") {
			$Proxy = ($ProxyConfiguration -replace '.*Static=(.*)','$1')
			$TargetFqdn,$TargetPort = $Proxy -split ':'
			Write-Log -Message "Static proxy is used ($Proxy), checking which interface will be used to send queries" -Source "EXO" -MessageType Info
		} else {
			$TargetFqdn,$TargetPort = $ExchangeFQDN,"443"
			Write-Log -Message "No explicit proxy is used, checking which interface will be used to send queries" -Source "EXO" -MessageType Info
		}
		$ConnectionTest = Test-NetConnection $TargetFqdn -Port $TargetPort
		if ($ConnectionTest.TcpTestSucceeded -eq $true) {
			$TargetInterface = $ConnectionTest.InterfaceAlias
			Write-Log -Message "Traffic will be sent on interface '$TargetInterface'" -Source "EXO" -MessageType Info
		} else {
			$TargetInterface = $null
			Write-Log -Message "Unable to reach the destination, unable to determine which interface will be used to send queries" -Source "EXO" -MessageType Warning
		}
	}
	
	$FileTimestamp = Get-DateInFileName
	$OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-EXO.pcapng"

	Start-NetworkTrace -Workload EXO -OutputFile $OutputFile -TargetInterface $TargetInterface

	$InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
	# Set TCP idle timeout to 5 seconds
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

	Write-Log -Message "Starting connection" -Source "EXO" -MessageType Info
	try {
		$EXOConnectivity = Invoke-WebRequest -Uri $ExchangeURL -UserAgent (Get-UserAgent) -UseBasicParsing

		if ($EXOConnectivity.statuscode -notlike "200") {
			Write-Log -Message "Failed to connect to '$ExchangeURL' (HTTP code $($EXOConnectivity.statuscode))" -Source "EXO" -MessageType Error
			$EXOConnectivity.Headers.Keys | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
				Write-Log -Message "$_ = $($EXOConnectivity.Headers[$_])" -Source "EXO" -MessageType Error
			}
			$ErrorDetails += "Failed to connect (HTTP code $($EXOConnectivity.statuscode))"
		} else {
			Write-Log -Message "Connected successfully to '$ExchangeURL'" -Source "EXO" -MessageType Info
			$FrontDoorCode = Get-FrontDoorFromHTTPResponse -HTTPResponse $EXOConnectivity
			if ($FrontDoorCode -notlike "") {
				Write-Log -Message "Exchange Front Door: '$FrontDoorCode'" -Source "EXO" -MessageType Info
				Resolve-DnsName -Name "$FrontDoorCode.frontdoor.outlook.office365.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
			} else {
				Write-Log -Message "Exchange Front Door not detected" -Source "EXO" -MessageType Warning
			}
			Write-Log -Message "Attempting DNS resolution of '$ExchangeFQDN'" -Source "EXO" -MessageType Info
			Resolve-DnsName -Name $ExchangeFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
		}
	} catch {
		Write-Log -Message "Failed to connect to '$ExchangeURL' with exception: $($_.Exception.Message)" -Source "EXO" -MessageType Error
		if ($_.Exception.Response) {
			$ErrorResponse = $_
			Write-Log -Message "Known headers in response:" -Source "EXO" -MessageType Error
			$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
				Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "EXO" -MessageType Error
			}
		}
		$ErrorDetails += "Failed to connect to '$ExchangeURL' with exception: $($_.Exception.Message)"
	}

	# Reset TCP idle timeout to its initial value
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout

	Stop-NetworkTrace -Workload EXO -OutputFile $OutputFile

	Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload EXO

	$NormalScriptCompletion = $true

} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "EXO" -MessageType Error
    $ErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "EXO" -MessageType Info
    try {
        if ($null -eq $TestStartTime) {
            $TestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $TestStartTime -Type "EXO" -ErrorDetails $ErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($ErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "EXO" -MessageType Error
    } finally {
        try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "EXO" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "EXO" -MessageType Info
    }
}