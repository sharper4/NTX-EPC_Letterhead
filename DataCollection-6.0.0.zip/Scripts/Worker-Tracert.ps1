﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - Tracert"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
    Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "Tracert" -MessageType Info

    # Fetching settings
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
    $OutputPath = $CurrentSettings.OutputPath
    $Egress = $CurrentSettings.EgressIP
    $TenantType = $CurrentSettings.TenantType[1]
    $Endpoints = (Get-Content $env:NPAPath\scripts\endpoints.json | ConvertFrom-Json).$TenantType
    $OneDriveFQDN = $CurrentSettings.OneDriveFQDN
    $OneDriveURL = $CurrentSettings.OneDriveURL
    if ($OneDriveFQDN -like "") {
        if ($TenantType -eq "Worldwide") {
            $OneDriveFQDN = "microsoft-my.sharepoint.com"
        } else {
            $OneDriveFQDN = $OneDriveURL.Split('/')[2]
        }
    }
    Get-ProxyCredentials

    # Output Paths
    $TracertFileOutput = Join-Path -Path $OutputPath -ChildPath 'tracert.log'
    $TracerouteResults = Join-Path -Path $OutputPath -ChildPath 'TracerouteResults.csv'

    # Getting Time
    $Timestamp = Get-DateInFile

    Write-Log -Message "Starting traceroute to $TenantType endpoints" -Source "Tracert" -MessageType Info

    $TestStartTime = Get-Date
    $ErrorDetails = @()

    # Path Testing
    if ((Test-Path $TracertFileOutput) -eq $false) {
        ' ' | Set-Content -Path $TracertFileOutput
    }

    # Adding header to log
    Add-Content -Path $TracertFileOutput -Value ' '
    Add-Content -Path $TracertFileOutput -Value '************************************'
    Add-Content -Path $TracertFileOutput -Value '| Tracert Tests         '
    Add-Content -Path $TracertFileOutput -Value "| $Timestamp"
    Add-Content -Path $TracertFileOutput -Value '************************************'
    Add-Content -Path $TracertFileOutput -Value ' '


    # Traceroute to Exchange, Teams, Sharepoint, Viva and Copilot
    if ($TenantType -eq "Worldwide") {
        Write-Log -Message "Traceroute to Exchange, Teams, Sharepoint, Viva, Copilot and .Microsoft domain started" -Source "Tracert" -MessageType Info
        $EndpointsList = $Endpoints.psobject.properties | Where-Object { $_.Name -match "Exchange|Teams|Sharepoint|Viva|Copilot|Microsoft" }
    } else {
        Write-Log -Message "Traceroute to Exchange, Teams, and Sharepoint started" -Source "Tracert" -MessageType Info
        $EndpointsList = $Endpoints.psobject.properties | Where-Object { $_.Name -match "Exchange|Teams|Sharepoint" }
    }

    foreach ($Workload in $EndpointsList) {
        if ($Workload.Name -match "Sharepoint") {
            $Workload.value = $OneDriveFQDN
        }
        if ($Workload.Name -match "TeamsPSTN") {
            $TCPPort = "5061"
        } else {
            $TCPPort = "443"
        }

        Write-Log -Message "Starting traceroute to $($Workload.Name)" -Source "Tracert" -MessageType Info

        Start-TracerouteProcess -RemoteHost $Workload.value -TCPPort $TCPPort -Service $Workload.Name -TracertFileOutput $TracertFileOutput -TracerouteResults $TracerouteResults -ErrorDetailsReference ([ref]$ErrorDetails)
    }

    if ($TenantType -eq "Worldwide") {
        Write-Log -Message "Traceroute to Exchange, Teams, Sharepoint, Viva, Copilot and .Microsoft domain completed" -Source "Tracert" -MessageType Info
    } else {
        Write-Log -Message "Traceroute to Exchange, Teams and Sharepoint completed" -Source "Tracert" -MessageType Info
    }

    # DNS TraceRoute
    Write-Log -Message "Starting traceroute to DNS servers" -Source "Tracert" -MessageType Info
    Add-Content -Path $TracertFileOutput -Value ('Tracing DNS Servers: ')

    $Networks = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter IPEnabled=True
    foreach ($network in $networks) {
        $DNSServerList += $network.dnsServerSearchOrder
    }

    $DNSServerList = $DNSServerList | Sort-Object | Get-Unique

    # Foreach IP in the collection
    foreach ($DNSServer in $DNSServerList) {
        Start-TracerouteProcess -RemoteHost $DNSServer -TCPPort 53 -Service "DNS" -TracertFileOutput $TracertFileOutput -TracerouteResults $TracerouteResults -ErrorDetailsReference ([ref]$ErrorDetails)
    }

    Write-Log -Message "Traceroute to DNS servers completed" -Source "Tracert" -MessageType Info

    $ValidIPRegex = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(:\d+)?$"
    $ValidFQDNRegex = "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])(:\d+)?$"
    if ($Egress -match $ValidIPRegex -or $Egress -match $ValidFQDNRegex) {
        if ($Egress -match ':') {
            $Egress = $Egress -replace '(.*):.*','$1'
        }
    } else {
        # If not a DOD tenant we can try to fetch public IP by using OpenDNS/Bing
        if ($TenantType -ne "DOD") {
            Write-Log -Message "Invalid egress provided, fetching egress IP from Bing" -Source "Tracert" -MessageType Warning
            try {
                $BingQuery = Invoke-WebRequest -Uri "https://www.bing.com/maps/sdkrelease/mapcontrol" -UserAgent (Get-UserAgent) -UseBasicParsing
                $Egress = ($BingQuery.RawContent -split ':{' | Where-Object {$_ -match "clientIP"}) -replace '.*"clientIP":"(.*?)".*','$1'
            } catch {
                Write-Log -Message "Failed to fetch egress IP from Bing with exception: $($_.Exception.Message)" -Source "Tracert" -MessageType Error
            }
            if ($Egress -match $ValidIPRegex) {
                Write-Log -Message "Egress IP found with Bing: $Egress" -Source "Tracert" -MessageType Info
                Write-Log -Message "Saving Egress IP in the settings file" -Source "Tracert" -MessageType Info
                $CurrentSettings.EgressIP = $Egress
                $CurrentSettings | ConvertTo-Json | Out-File -FilePath $env:NPAPath\Settings.json -Encoding UTF8 -Force
            } else {
                Write-Log -Message "Egress IP not found with Bing, attempting to fetch egress IP from OpenDNS" -Source "Tracert" -MessageType Warning
                try { $Egress = (Resolve-DnsName -Name myip.opendns.com. -DnsOnly -Type A -Server resolver1.opendns.com -ErrorAction SilentlyContinue).IPAddress } catch {}
                if ($Egress -match $ValidIPRegex) {
                    Write-Log -Message "Egress IP found with OpenDNS: $Egress" -Source "Tracert" -MessageType Info
                    Write-Log -Message "Saving Egress IP in the settings file" -Source "Tracert" -MessageType Info
                    $CurrentSettings.EgressIP = $Egress
                    $CurrentSettings | ConvertTo-Json | Out-File -FilePath $env:NPAPath\Settings.json -Encoding UTF8 -Force
                } else {
                    Write-Log -Message "Egress IP not found with OpenDNS" -Source "Tracert" -MessageType Warning
                }
            }
        }
    }

    if ($Egress -match $ValidIPRegex -or $Egress -match $ValidFQDNRegex) {
        Write-Log -Message "Traceroute to egress started" -Source "Tracert" -MessageType Info
        Start-TracerouteProcess -RemoteHost $Egress -Service "Egress" -TracertFileOutput $TracertFileOutput -TracerouteResults $TracerouteResults -ErrorDetailsReference ([ref]$ErrorDetails)

    } else {
        Write-Log -Message "Invalid egress provided, can't proceed with traceroute" -Source "Tracert" -MessageType Error
    }

    $NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "Tracert" -MessageType Error
    $ErrorDetails += "Unhandled error: $($_.Exception.Message)"
    $NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "Tracert" -MessageType Info
    try {
        if ($null -eq $TestStartTime) {
            $TestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $TestStartTime -Type "Tracert" -ErrorDetails $ErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($ErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "Tracert" -MessageType Error
    } finally {
		Write-Log -Message "Task completed" -Source "Tracert" -MessageType Info
    }
}