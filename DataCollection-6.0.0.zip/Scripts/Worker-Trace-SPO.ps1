﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - SPO"
$ErrorActionPreference = 'Stop'
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "SPO" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

	# Fetching settings
	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$Outputpath = $CurrentSettings.OutputPath
	$OneDriveFQDN = $CurrentSettings.OneDriveFQDN
	$OneDriveURL = $CurrentSettings.OneDriveURL
	$ProxyConfiguration = $CurrentSettings.ProxyConfiguration
	Get-ProxyCredentials

	Set-OutputFolders

	Wait-LockFile -LockFile $Lockfile -Workload SPO

	Write-Log -Message "Tests started" -Source "SPO" -MessageType Info
	Set-Content -Value "SPO" -Path $Lockfile -ErrorAction SilentlyContinue

	$TestStartTime = Get-Date
	$ErrorDetails = @()

	# Setting up the destination
	if ($OneDriveFQDN -like "") {
		$OneDriveFQDN = "microsoft-my.sharepoint.com"
	}
	$OneDriveURL = "https://$OneDriveFQDN/_layouts/15/transfertestfootprint.aspx?op=down&length=1"
	Write-Log -Message "Tests will be carried with URL '$($OneDriveURL -replace '(https://.*?)/.*','$1')'" -Source "SPO" -MessageType Info

	# Testing which interface is used
	if ($ProxyConfiguration -match "PAC=") {
		$TargetInterface = $null
		Write-Log -Message "Proxy auto configuration (PAC) is used, unable to determine which interface will be used to send queries" -Source "SPO" -MessageType Info
	} else {
		if ($ProxyConfiguration -match "Static=") {
			$Proxy = ($ProxyConfiguration -replace '.*Static=(.*)','$1')
			$TargetFqdn,$TargetPort = $Proxy -split ':'
			Write-Log -Message "Static proxy is used ($Proxy), checking which interface will be used to send queries" -Source "SPO" -MessageType Info
		} else {
			$TargetFqdn,$TargetPort = $OneDriveFQDN,"443"
			Write-Log -Message "No explicit proxy is used, checking which interface will be used to send queries" -Source "SPO" -MessageType Info
		}
		$ConnectionTest = Test-NetConnection $TargetFqdn -Port $TargetPort
		if ($ConnectionTest.TcpTestSucceeded -eq $true) {
			$TargetInterface = $ConnectionTest.InterfaceAlias
			Write-Log -Message "Traffic will be sent on interface '$TargetInterface'" -Source "SPO" -MessageType Info
		} else {
			$TargetInterface = $null
			Write-Log -Message "Unable to reach the destination, unable to determine which interface will be used to send queries" -Source "SPO" -MessageType Warning
		}
	}

	$FileTimestamp = Get-DateInFileName
	$OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-SPO.pcapng"

	Start-NetworkTrace -Workload SPO -OutputFile $OutputFile -TargetInterface $TargetInterface

	$InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
	# Set TCP idle timeout to 5 seconds
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

	Write-Log -Message "Starting connection" -Source "SPO" -MessageType Info
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = 1900
	$ValidResponse = $false
	$Retries = 0
	While ($ValidResponse -ne $true -and $Retries -lt 10) {
		try {
			$SPConnectivity = Invoke-WebRequest -Uri $OneDriveURL -UserAgent (Get-UserAgent) -UseBasicParsing
			$ValidResponse = $true
			if ($SPConnectivity.statuscode -notlike "200") {
				Write-Log -Message "Failed to connect to '$OneDriveURL' (HTTP code $($SPConnectivity.statuscode))" -Source "SPO" -MessageType Error
				$SPConnectivity.Headers.Keys | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
					Write-Log -Message "$_ = $($SPConnectivity.Headers[$_])" -Source "SPO" -MessageType Error
				}
				$ErrorDetails += "Failed to connect (HTTP code $($SPConnectivity.statuscode))"
			} else {
				Write-Log -Message "Connected successfully to '$OneDriveURL'" -Source "SPO" -MessageType Info
				$FrontDoorCode = Get-FrontDoorFromHTTPResponse -HTTPResponse $SPConnectivity
				if ($FrontDoorCode -notlike "") {
					Write-Log -Message "Sharepoint Front Door: '$FrontDoorCode'" -Source "SPO" -MessageType Info
					Resolve-DnsName -Name "$FrontDoorCode.frontdoor.sharepoint.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
				} else {
					Write-Log -Message "Sharepoint Front Door not detected" -Source "SPO" -MessageType Warning
				}
				Write-Log -Message "Attempting DNS resolution of '$OneDriveFQDN'" -Source "SPO" -MessageType Info
				Resolve-DnsName -Name $OneDriveFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null

			}
		} catch {
			if ($_.Exception.Message -match '\(404\)') {
				Write-Log -Message "Got a 404 from service with URI '$OneDriveURL', retrying" -Source "SPO" -MessageType Warning
				ipconfig /flushdns | out-null
				$Retries++
				Start-Sleep -Milliseconds 2000
			} else {
				Write-Log -Message "Failed to connect to '$OneDriveURL' with exception: $($_.Exception.Message)" -Source "SPO" -MessageType Error
				if ($_.Exception.Response) {
					$ErrorResponse = $_
					Write-Log -Message "Known headers in response:" -Source "SPO" -MessageType Error
					$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
						Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "SPO" -MessageType Error
					}
				}
				$Retries++
			}
		}
	}

	if ($ValidResponse -ne $true) {
		$OneDriveURL = "https://spo-ring.msedge.net/transfertest?op=down&length=1"
		try {
			Write-Log -Message "Retrying with URI '$OneDriveURL'" -Source "SPO" -MessageType Info
			$SPConnectivity = Invoke-WebRequest -Uri $OneDriveURL -UserAgent (Get-UserAgent) -UseBasicParsing
			if ($SPConnectivity.statuscode -notlike "200") {
				Write-Log -Message "Failed to connect to '$OneDriveURL' (HTTP code $($SPConnectivity.statuscode))" -Source "SPO" -MessageType Error
				$SPConnectivity.Headers.Keys | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
					Write-Log -Message "$_ = $($SPConnectivity.Headers[$_])" -Source "SPO" -MessageType Error
				}
				$ErrorDetails += "Failed to connect (HTTP code $($SPConnectivity.statuscode))"
			} else {
				Write-Log -Message "Connected successfully to '$OneDriveURL'" -Source "SPO" -MessageType Info
				$FrontDoorCode = Get-FrontDoorFromHTTPResponse -HTTPResponse $SPConnectivity
				if ($FrontDoorCode -notlike "") {
					Write-Log -Message "Sharepoint Front Door: '$FrontDoorCode'" -Source "SPO" -MessageType Info
					Resolve-DnsName -Name "$FrontDoorCode.frontdoor.sharepoint.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
				} else {
					Write-Log -Message "Sharepoint Front Door not detected" -Source "SPO" -MessageType Warning
				}
				Write-Log -Message "Attempting DNS resolution of '$OneDriveFQDN'" -Source "SPO" -MessageType Info
				Resolve-DnsName -Name $OneDriveFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
			}
		} catch {
			Write-Log -Message "Failed to connect to '$OneDriveURL' with exception: $($_.Exception.Message)" -Source "SPO" -MessageType Error
			if ($_.Exception.Response) {
				$ErrorResponse = $_
				Write-Log -Message "Known headers in response:" -Source "SPO" -MessageType Error
				$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
					Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "SPO" -MessageType Error
				}
			}
			$ErrorDetails += "Failed to connect to '$OneDriveURL' with exception: $($_.Exception.Message)"
		}
	}

	# Reset TCP idle timeout to its initial value
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout

	Stop-NetworkTrace -Workload SPO -OutputFile $OutputFile

	Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload SPO

	$NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "SPO" -MessageType Error
    $ErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "SPO" -MessageType Info
    try {
        if ($null -eq $TestStartTime) {
            $TestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $TestStartTime -Type "SPO" -ErrorDetails $ErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($ErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "SPO" -MessageType Error
    } finally {
        try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "SPO" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "SPO" -MessageType Info
    }
}