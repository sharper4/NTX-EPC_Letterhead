﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - Teams"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "Teams" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

	# Fetching settings
	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$OutputPath = $CurrentSettings.OutputPath
	$TenantType = $CurrentSettings.TenantType[1]
	$Endpoints = (Get-Content $env:NPAPath\scripts\endpoints.json | ConvertFrom-Json).$TenantType
	$TeamsFQDN = $Endpoints.TeamsWeb
	$ProxyConfiguration = $CurrentSettings.ProxyConfiguration
	Get-ProxyCredentials

	Set-OutputFolders

	Wait-LockFile -LockFile $Lockfile -Workload Teams

	Write-Log -Message "Tests started" -Source "Teams" -MessageType Info
	Set-Content -Value "Teams" -Path $Lockfile -ErrorAction SilentlyContinue

	$TestStartTime = Get-Date
	$ErrorDetails = @()

	# Setting up the destination
	$TeamsURL = "https://$TeamsFQDN/"
	Write-Log -Message "Tests will be carried with URL '$($TeamsURL -replace '(https://.*?)/.*','$1')'" -Source "Teams" -MessageType Info

	# Testing which interface is used
	if ($ProxyConfiguration -match "PAC=") {
		$TargetInterface = $null
		Write-Log -Message "Proxy auto configuration (PAC) is used, unable to determine which interface will be used to send queries" -Source "Teams" -MessageType Info
	} else {
		if ($ProxyConfiguration -match "Static=") {
			$Proxy = ($ProxyConfiguration -replace '.*Static=(.*)','$1')
			$TargetFqdn,$TargetPort = $Proxy -split ':'
			Write-Log -Message "Static proxy is used ($Proxy), checking which interface will be used to send queries" -Source "Teams" -MessageType Info
		} else {
			$TargetFqdn,$TargetPort = $TeamsFQDN,"443"
			Write-Log -Message "No explicit proxy is used, checking which interface will be used to send queries" -Source "Teams" -MessageType Info
		}
		$ConnectionTest = Test-NetConnection $TargetFqdn -Port $TargetPort
		if ($ConnectionTest.TcpTestSucceeded -eq $true) {
			$TargetInterface = $ConnectionTest.InterfaceAlias
			Write-Log -Message "Traffic will be sent on interface '$TargetInterface'" -Source "Teams" -MessageType Info
		} else {
			$TargetInterface = $null
			Write-Log -Message "Unable to reach the destination, unable to determine which interface will be used to send queries" -Source "Teams" -MessageType Warning
		}
	}

	$FileTimestamp = Get-DateInFileName
	$OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-Teams.pcapng"

	Start-NetworkTrace -Workload Teams -OutputFile $OutputFile -TargetInterface $TargetInterface

	$InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
	# Set TCP idle timeout to 5 seconds
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

	Write-Log -Message "Starting connection" -Source "Teams" -MessageType Info
	try {
		$TeamsConnectivity = Invoke-WebRequest -Uri $TeamsURL -UserAgent (Get-UserAgent) -UseBasicParsing

		if ($TeamsConnectivity.statuscode -notlike "200") {
			Write-Log -Message "Failed to connect to '$TeamsURL' (HTTP code $($TeamsConnectivity.statuscode))" -Source "Teams" -MessageType Error
			$TeamsConnectivity.Headers.Keys | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
				Write-Log -Message "$_ = $($TeamsConnectivity.Headers[$_])" -Source "Teams" -MessageType Error
			}
			$ErrorDetails += "Failed to connect (HTTP code $($TeamsConnectivity.statuscode))"
		} else {
			Write-Log -Message "Connected successfully to '$TeamsURL'" -Source "Teams" -MessageType Info
			$FrontDoorCode = Get-FrontDoorFromHTTPResponse -HTTPResponse $TeamsConnectivity
			if ($FrontDoorCode -notlike "") {
				Write-Log -Message "Teams Front Door: '$FrontDoorCode'" -Source "Teams" -MessageType Info
				Resolve-DnsName -Name "$FrontDoorCode.frontdoor.teams.office365.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
			} else {
				Write-Log -Message "Teams Front Door not detected" -Source "Teams" -MessageType Warning
			}
			Write-Log -Message "Attempting DNS resolution of '$TeamsFQDN'" -Source "Teams" -MessageType Info
			Resolve-DnsName -Name $TeamsFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
		}
	} catch {
		Write-Log -Message "Failed to connect to '$TeamsURL' with exception: $($_.Exception.Message)" -Source "Teams" -MessageType Error
		if ($_.Exception.Response) {
			$ErrorResponse = $_
			Write-Log -Message "Known headers in response:" -Source "Teams" -MessageType Error
			$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
				Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "Teams" -MessageType Error
			}
		}
		$ErrorDetails += "Failed to connect to '$TeamsURL' with exception: $($_.Exception.Message)"
	}

	# Reset TCP idle timeout to its initial value
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout

	Stop-NetworkTrace -Workload Teams -OutputFile $OutputFile

	Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload Teams

	$NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "Teams" -MessageType Error
    $ErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "Teams" -MessageType Info
    try {
        if ($null -eq $TestStartTime) {
            $TestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $TestStartTime -Type "Teams" -ErrorDetails $ErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($ErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "Teams" -MessageType Error
    } finally {
        try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "Teams" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "Teams" -MessageType Info
    }
}