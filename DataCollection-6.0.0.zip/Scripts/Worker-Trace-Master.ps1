﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - Master7Days"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "TraceMaster" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"
	$TracemasterLockfile = "$env:NPAPath\tracemaster.lck"


	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$WindowStyle = if ($DebugMode) { "Normal" } else { "Hidden" }
	$TenantType = $CurrentSettings.TenantType[1]

	$LastBootTime = Get-CimInstance -ClassName win32_operatingsystem | Select-Object lastbootuptime
	$TimeDifference = New-TimeSpan -Start $LastBootTime.lastbootuptime -End (Get-Date)
	# If the reboot time is less than 15 minutes ago it is likely we rebooted. In that case, if the lockfiles exists, we need to remove them
	if ($TimeDifference.TotalMinutes -lt 15 -and (Test-Path $LockFile)) {
		Write-Log -Message "Forcefully removing stale lockfile (machine rebooted less than 15 minutes ago)" -Source "TraceMaster" -MessageType Warning
		try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "TraceMaster" -MessageType Error
		}
	}

	if (Test-Path $TracemasterLockfile) {
		Write-Log -Message "Tracemaster lockfile exists" -Source "TraceMaster" -MessageType Warning
		$LockingProcesses = Get-Content -Path $TracemasterLockfile
		$TracemasterProcess = Get-Process | Where-Object { $_.Id -eq ($LockingProcesses | Select-Object -First 1) }
		if ($TracemasterProcess) {
			Write-Log -Message "Another tracemaster process is still active since '$($TracemasterProcess.StartTime.ToString("yyyy-MM-dd HH:mm:ss"))'" -Source "TraceMaster" -MessageType Warning
			Wait-LockFile -LockFile $TracemasterLockfile -Workload TraceMaster
		} else {
			Write-Log -Message "No other active tracemaster process found, removing stale tracemaster lockfile" -Source "TraceMaster" -MessageType Warning
			try {
				Remove-Item -Path $TracemasterLockfile | Out-Null
			} catch {
				Write-Log -Message "Failed to remove tracemaster lockfile" -Source "TraceMaster" -MessageType Error
			}
		}
		if (Test-Path $Lockfile) {
			Write-Log -Message "Removing stale lockfile" -Source "TraceMaster" -MessageType Warning
			try {
				Remove-Item -Path $Lockfile -Force | Out-Null
			} catch {
				Write-Log -Message "Failed to remove lockfile" -Source "TraceMaster" -MessageType Error
			}
		}
	} else {
		Write-Log -Message "No previous tracemaster lockfile exists" -Source "TraceMaster" -MessageType Info
	}

	Wait-LockFile -LockFile $Lockfile -Workload TraceMaster

	Write-Log -Message "Starting tests" -Source "TraceMaster" -MessageType Info
	$PID | Out-File -FilePath $TracemasterLockfile -Force
	
	Get-ProxyConfiguration -LogType "TraceMaster"
	
	$TestStartTime = Get-Date
	$ErrorDetails = @()

	if ($CurrentSettings.CaptureScenario[1] -match "Zscaler.*tunnel") {
		Write-Log -Message "Zscaler tunnel scenario has been configured, unable to run automated collection" -Source "TraceMaster" -MessageType Error
		Write-Log -Message "Removing existing registered tasks" -Source "Main" -MessageType Info -DisplayInGui
    	Unregister-ScheduledTask -TaskName "NPA - *" -Confirm:$false
		throw "Zscaler tunnel scenario has been configured, unable to run automated collection"
	}

	Write-Log -Message "Checking previous runs of tasks" -Source "TraceMaster" -MessageType Info
	$TestsResultsPath = Join-Path -Path $CurrentSettings.OutputPath -ChildPath "TestsResults.csv"
	if (Test-Path $TestsResultsPath) {
		$TestsResultsContent = Get-Content -Path $TestsResultsPath
		if (($TestsResultsContent | Select-Object -First 1) -match ";") {
			Write-Log -Message "Tests results file was previously generated using ';' delimiter, converting to tab delimiter" -Source "TraceMaster" -MessageType Info
			$TestsResultsContent = $TestsResultsContent -replace ';',"`t"
			$TestsResultsContent | Set-Content -Path $TestsResultsPath -Encoding UTF8
		}
		$TestsResults = $TestsResultsContent | ConvertFrom-Csv -Delimiter "`t"
		if ($TestsResults.count -gt 0) {
			$TestTypes = "TraceMaster","Tracert","SPO UP/DOWN"
			foreach ($TestType in $TestTypes) {
				$LastTestResult = $TestsResults | Where-Object {$_.Type -eq $TestType} | Select-Object -Last 1
				if ($LastTestResult) {
					$LastRunTime = [datetime]::ParseExact($LastTestResult.StartTime,'yyyyMMdd HH:mm:ss',$null)
					if ($TestType -eq "Tracert" -or $TestType -eq "SPO UP/DOWN") {
						$LastRunTimeMinutesAgo = (New-TimeSpan -Start $LastRunTime -End (Get-Date)).TotalMinutes
						if ($LastRunTimeMinutesAgo -gt 50) {
							Write-Log -Message "Last '$TestType' test ran more than 50 minutes ago ('$($LastRunTime.ToString("yyyy-MM-dd HH:mm:ss"))' - Result: $($LastTestResult.Result)), the test will be executed again" -Source "TraceMaster" -MessageType Info
							if ($TestType -eq "Tracert") { $SkipTracert = $false }
							if ($TestType -eq "SPO UP/DOWN") { $SkipSPOUpDown = $false }
						} else {
							Write-Log -Message "Last '$TestType' test ran less than 50 minutes ago ('$($LastRunTime.ToString("yyyy-MM-dd HH:mm:ss"))' - Result: $($LastTestResult.Result)), the test will be skipped" -Source "TraceMaster" -MessageType Info
							if ($TestType -eq "Tracert") { $SkipTracert = $true }
							if ($TestType -eq "SPO UP/DOWN") { $SkipSPOUpDown = $true }
						}
					} else {
						Write-Log -Message "Last '$TestType' test ran at '$($LastRunTime.ToString("yyyy-MM-dd HH:mm:ss"))' (Result: $($LastTestResult.Result))" -Source "TraceMaster" -MessageType Info
					}
				} else {
					Write-Log -Message "No '$TestType' test ran yet" -Source "TraceMaster" -MessageType Info
					if ($TestType -eq "Tracert") { $SkipTracert = $false }
					if ($TestType -eq "SPO UP/DOWN") { $SkipSPOUpDown = $false }
				}
			}
		} else {
			Write-Log -Message "No test ran yet" -Source "TraceMaster" -MessageType Info
		}
	} else {
		Write-Log -Message "No test ran yet" -Source "TraceMaster" -MessageType Info
	}

	Get-IPConfig

	Copy-RunlogAndSettingsToOutputFolder

	if ($SkipTracert -eq $false) {
		Write-Log -Message "Starting Tracert test" -Source "TraceMaster" -MessageType Info
		$Command = "& `'$env:NPAPath\Scripts\Worker-Tracert.ps1`' -SkipTracert"
		$TracertProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
		Write-Log -Message "Started Tracert test (PID:$($TracertProcess.Id))" -Source "TraceMaster" -MessageType Info
		$TracertProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
		$TracertProcess.WaitForExit()
	} else {
		Write-Log -Message "Skipping Tracert test" -Source "TraceMaster" -MessageType Info
	}

	Copy-RunlogAndSettingsToOutputFolder

	Write-Log -Message "Starting DNS resolution test" -Source "TraceMaster" -MessageType Info
	$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-DNSLookup.ps1`'"
	$DNSProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
	Write-Log -Message "Started DNS resolution test (PID:$($DNSProcess.Id))" -Source "TraceMaster" -MessageType Info
	$DNSProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
	$DNSProcess.WaitForExit()

	Copy-RunlogAndSettingsToOutputFolder

	Write-Log -Message "Starting Exchange connectivity test" -Source "TraceMaster" -MessageType Info
	$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-EXO.ps1`'"
	$EXOProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
	Write-Log -Message "Started Exchange connectivity test (PID:$($EXOProcess.Id))" -Source "TraceMaster" -MessageType Info
	$EXOProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
	$EXOProcess.WaitForExit()

	Copy-RunlogAndSettingsToOutputFolder

	Write-Log -Message "Starting Teams connectivity test" -Source "TraceMaster" -MessageType Info
	$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-Teams.ps1`'"
	$TeamsProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
	Write-Log -Message "Started Teams connectivity test (PID:$($TeamsProcess.Id))" -Source "TraceMaster" -MessageType Info
	$TeamsProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
	$TeamsProcess.WaitForExit()

	Copy-RunlogAndSettingsToOutputFolder

	Write-Log -Message "Starting Sharepoint connectivity test" -Source "TraceMaster" -MessageType Info
	$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-SPO.ps1`'"
	$SPOProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
	Write-Log -Message "Started Sharepoint connectivity test (PID:$($SPOProcess.Id))" -Source "TraceMaster" -MessageType Info
	$SPOProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
	$SPOProcess.WaitForExit()

	Copy-RunlogAndSettingsToOutputFolder

	if ($TenantType -eq "Worldwide") {
		Write-Log -Message "Starting Viva connectivity test" -Source "TraceMaster" -MessageType Info
		$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-Viva.ps1`'"
		$VivaProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
		Write-Log -Message "Started Viva connectivity test (PID:$($VivaProcess.Id))" -Source "TraceMaster" -MessageType Info
		$VivaProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
		$VivaProcess.WaitForExit()

		Copy-RunlogAndSettingsToOutputFolder

		Write-Log -Message "Starting Copilot connectivity test" -Source "TraceMaster" -MessageType Info
		$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-Copilot.ps1`'"
		$CopilotProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
		Write-Log -Message "Started Copilot connectivity test (PID:$($CopilotProcess.Id))" -Source "TraceMaster" -MessageType Info
		$CopilotProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
		$CopilotProcess.WaitForExit()

		Copy-RunlogAndSettingsToOutputFolder

		Write-Log -Message "Starting MicrosoftDomain connectivity test" -Source "TraceMaster" -MessageType Info
		$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-MicrosoftDomain.ps1`'"
		$MicrosoftDomainProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
		Write-Log -Message "Started MicrosoftDomain connectivity test (PID:$($MicrosoftDomainProcess.Id))" -Source "TraceMaster" -MessageType Info
		$MicrosoftDomainProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
		$MicrosoftDomainProcess.WaitForExit()

		Copy-RunlogAndSettingsToOutputFolder
	}
	
	if ($SkipSPOUpDown -eq $false) {
		Write-Log -Message "Starting File Transfer test" -Source "TraceMaster" -MessageType Info
		$Command = "& `'$env:NPAPath\Scripts\Worker-Trace-FileTransfer.ps1`'"
		$FileTransferProcess = Start-Process powershell -ArgumentList $Command -PassThru -WindowStyle $WindowStyle
		Write-Log -Message "Started File Transfer test (PID:$($FileTransferProcess.Id))" -Source "TraceMaster" -MessageType Info
		$FileTransferProcess.Id | Out-File -FilePath $TracemasterLockfile -Append -Force
		$FileTransferProcess.WaitForExit()
	} else {
		Write-Log -Message "Skipping File Transfer test" -Source "TraceMaster" -MessageType Info
	}
	
	Copy-RunlogAndSettingsToOutputFolder

	$NormalScriptCompletion = $true
} catch {
	Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "TraceMaster" -MessageType Error
	$ErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
	Write-Log -Message "All tests completed" -Source "TraceMaster" -MessageType Info
	try {
		if ($null -eq $TestStartTime) {
			$TestStartTime = Get-Date
		}
		Write-TestStatus -StartTime $TestStartTime -Type "TraceMaster" -ErrorDetails $ErrorDetails
		if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
			if ($ErrorDetails.count -gt 0) {
				timeout /t 30
			} else {
				timeout /t 10
			}
		}
	} catch {
		Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "TraceMaster" -MessageType Error
	} finally {
		try {
			Remove-Item -Path $TracemasterLockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "TraceMaster" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "TraceMaster" -MessageType Info
		Copy-RunlogAndSettingsToOutputFolder
	}
}