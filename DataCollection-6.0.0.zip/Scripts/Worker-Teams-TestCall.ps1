﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - TeamsMediaQuality"
$ErrorActionPreference = 'Stop'
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
    Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
    Write-Log -Message "Task started" -Source "TeamsNAT" -MessageType Info

    # Fetching settings
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
    $Outputpath = $CurrentSettings.OutputPath
    $TeamsNATpath = $CurrentSettings.TeamsNATpath
    $ResultsFile = "$Outputpath\TeamsMediaQuality.csv"
    Get-ProxyCredentials

    #Path where the Teams tool save the results files
    $TeamsNATOutputPath = "$env:LocalAppData\Microsoft Teams Network Assessment Tool"
    $TeamsNATOutputFilePath = "$TeamsNATOutputPath\*quality_check_results*.csv"

    if (Test-Path $TeamsNATpath) {

        Set-TeamsConfigFile
        
        #Remove previous quality_check_results files before running the test
        if (Test-Path $TeamsNATOutputFilePath) { Remove-Item -Path $TeamsNATOutputFilePath -Force }

        Write-Log -Message "Attempting to start Teams test call" -Source "TeamsNAT" -MessageType Info

        $TestStartTime = Get-Date
        $ErrorDetails = @()

        try {

            $OriginalDecimalSeparator = (Get-ItemProperty -Path "HKCU:\Control Panel\International").sDecimal
            $TemporaryDecimalSeparator = "."
            if ($OriginalDecimalSeparator -ne $TemporaryDecimalSeparator) {
                # Force the decimal separator to "dot" for locales that use a comma
                Set-ItemProperty -Path "HKCU:\Control Panel\International" -Name "sDecimal" -Value $TemporaryDecimalSeparator
            }

            # Teams call test
            $ExecutionResult = $null
            & "$TeamsNATpath\NetworkAssessmentTool.exe" /qualitycheck | ForEach-Object {
                $Line = $_
                
                if ($Line -match "Call Quality Metrics:") {
                    $ExecutionResult = "Success"
                    Write-Log -Message "Successfully started test call" -Source "TeamsNAT" -MessageType Info
                    Write-Host "DateTime`tLossRate`tLatency`tJitter`tProtocol`tLocalIP`tRemoteIP`tProxied`tReflexiveIP"
                }
                
                if ($ExecutionResult -eq "Success") {
                    # If it's a new result row
                    if ($Line -match "^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}") {
                        $CurrentResult = New-Object PSObject -Property ([Ordered]@{
                            DateTime		= $Line -replace '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}).*','$1'
                            LossRate		= $Line -replace '.*Loss Rate: (.*?)\s+.*','$1'
                            Latency			= $Line -replace '.*Latency: (.*?)\s+.*','$1'
                            Jitter			= $Line -replace '.*Jitter: (.*?)\s+.*','$1'
                            Protocol		= $Line -replace '.*Protocol: (.*?)$','$1'
                            LocalIP			= $null
                            RemoteIP		= $null
                            Proxied			= $null
                            ReflexiveIP		= $null
                        })
                    # If it's a second result row
                    } elseif ($Line -match "^Local IP: ") {
                        $CurrentResult.LocalIP	= $Line -replace '.*Local IP: (.*?)\s+.*','$1'
                        $CurrentResult.RemoteIP	= $Line -replace '.*Remote IP: (.*?)$*','$1'
                    # If it's a third result row
                    } elseif ($Line -match "^Is Proxied Path: ") {
                        $CurrentResult.Proxied		= if (($Line -replace '.*Is Proxied Path: (.*?)\s+.*','$1') -eq "True") {$true} else {$false}
                        $CurrentResult.ReflexiveIP	= $Line -replace '.*Last Known Reflexive IP: (.*?)$*','$1'
                        Write-Host "$($CurrentResult.DateTime)`t$($CurrentResult.LossRate)`t$($CurrentResult.Latency)`t$($CurrentResult.Jitter)`t$($CurrentResult.Protocol)`t$($CurrentResult.LocalIP)`t$($CurrentResult.RemoteIP)`t$($CurrentResult.Proxied)`t$($CurrentResult.ReflexiveIP)"
                    }
                }
                
                if  ($Line -match "ERROR:") {
                    if ($Line -notmatch "ERROR: (Check that|Recommend running)") {
                        $ExecutionResult = "Error"
                        $ErrorDetails += $Line -replace 'ERROR: ',""
                    }
                }
            }

            if ($ExecutionResult -ne "Success") {
                Write-Log -Message "Failed to start test call" -Source "TeamsNAT" -MessageType Error
                $ErrorDetails | ForEach-Object { Write-Log -Message "$_" -Source "TeamsNAT" -MessageType Error}
            } else {
                Write-Log -Message "Test call ended without error" -Source "TeamsNAT" -MessageType Info
            }

            if ($OriginalDecimalSeparator -ne $TemporaryDecimalSeparator) {
                # Reset the decimal separator to the initial value
                Set-ItemProperty -Path "HKCU:\Control Panel\International" -Name "sDecimal" -Value $OriginalDecimalSeparator
            }

            if (Test-Path $TeamsNATOutputFilePath) {
                $Results = Get-Item -Path $TeamsNATOutputFilePath | ForEach-Object { Import-Csv -Path $_.FullName }

                #Check for null results
                if (($results | Measure-Object).count -gt 0) {
                    ForEach ($Result in $results) {
                        $DateFormatted = $Result.'Timestamp-UTC' -replace '(\d{4}-\d{2}-\d{2})-((\d*):\d{2}:\d{2})', '$1 $2'
                        $TimestampUTC = Get-LocalTime -UTCTime $DateFormatted -format "yyyy-MM-dd HH:mm:ss"
                        $Result.'Timestamp-UTC' = $TimestampUTC
                        $Values = ($Result.'Timestamp-UTC' , $Result.'LossRate-%' , $Result.'AverageLatency-Ms' , $Result.'AverageJitter-MS' , $Result.Protocol , $Result.LocalIP , $Result.ReflexiveIP , $Result.RemoteIP , $Result.ProxyUsed) -join "`t"
                        if (-not (Test-Path $ResultsFile)) {
                            #If it is first time we need create file with following structure
                            $Headers = ( "Timestamp" , "LossRate-%" , "AverageLatency-Ms" , "AverageJitter-MS" , "Protocol" , "LocalIP" , "ReflexiveIP" , "RemoteIP" , "ProxyUsed" ) -join "`t"
                            Add-Content -Value $Headers -Path $ResultsFile
                        }
                        Add-Content -Value $Values -Path $ResultsFile
                    }
                    Remove-Item -Path $TeamsNATOutputFilePath -Force
                    Write-Log -Message "Data added to the result file" -Source "TeamsNAT" -MessageType Info
                } else {
                    Write-Log -Message "Result file is empty" -Source "TeamsNAT" -MessageType Error
                    $ErrorDetails += "result file is empty"
                }
            } else {
                Write-Log -Message "No result file found" -Source "TeamsNAT" -MessageType Error
                $ErrorDetails += "no result file found"
            }

        } catch {
            Write-Log -Message "Failed to perform Teams test call: $($_.Exception.Message)" -Source "TeamsNAT" -MessageType Error
            $ErrorDetails += "Failed to perform Teams test call: $($_.Exception.Message)"
        }
    } else {
        Write-Log -Message "TeamsNAT not found during test call" -Source "TeamsNAT" -MessageType Error
        $ErrorDetails += "TeamsNAT not found"
    }
    $NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "TeamsNAT" -MessageType Error
    $ErrorDetails += "Unhandled error: $($_.Exception.Message)"
    $NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Test call completed" -Source "TeamsNAT" -MessageType Info
    try {
        if ($null -eq $TestStartTime) {
            $TestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $TestStartTime -Type "TeamsMediaQuality" -ErrorDetails $ErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($ErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "TeamsNAT" -MessageType Error
    } finally {
        Write-Log -Message "Task completed" -Source "TeamsNAT" -MessageType Info
    }
}