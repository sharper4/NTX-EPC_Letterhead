﻿$host.ui.RawUI.WindowTitle = "NPA - Tests - Viva"
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$NormalScriptCompletion = $false

try {
	Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
	Write-Log -Message "Task started" -Source "Viva" -MessageType Info
	$Lockfile = "$env:NPAPath\lock.lck"

	# Fetching settings
	$CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
	$DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
	$OutputPath = $CurrentSettings.OutputPath
	$TenantType = $CurrentSettings.TenantType[1]
	$Endpoints = (Get-Content $env:NPAPath\scripts\endpoints.json | ConvertFrom-Json).$TenantType
	$VivaFQDN = $Endpoints.Viva
	$ProxyConfiguration = $CurrentSettings.ProxyConfiguration
	Get-ProxyCredentials

	Set-OutputFolders

	Wait-LockFile -LockFile $Lockfile -Workload Viva

	Write-Log -Message "Tests started" -Source "Viva" -MessageType Info
	Set-Content -Value "Viva" -Path $Lockfile -ErrorAction SilentlyContinue

	$TestStartTime = Get-Date
	$ErrorDetails = @()

	# Setting up the destination
	$VivaURL = "https://$VivaFQDN/"
	Write-Log -Message "Tests will be carried with URL '$($VivaURL -replace '(https://.*?)/.*','$1')'" -Source "Viva" -MessageType Info

	# Testing which interface is used
	if ($ProxyConfiguration -match "PAC=") {
		$TargetInterface = $null
		Write-Log -Message "Proxy auto configuration (PAC) is used, unable to determine which interface will be used to send queries" -Source "Viva" -MessageType Info
	} else {
		if ($ProxyConfiguration -match "Static=") {
			$Proxy = ($ProxyConfiguration -replace '.*Static=(.*)','$1')
			$TargetFqdn,$TargetPort = $Proxy -split ':'
			Write-Log -Message "Static proxy is used ($Proxy), checking which interface will be used to send queries" -Source "Viva" -MessageType Info
		} else {
			$TargetFqdn,$TargetPort = $VivaFQDN,"443"
			Write-Log -Message "No explicit proxy is used, checking which interface will be used to send queries" -Source "Viva" -MessageType Info
		}
		$ConnectionTest = Test-NetConnection $TargetFqdn -Port $TargetPort
		if ($ConnectionTest.TcpTestSucceeded -eq $true) {
			$TargetInterface = $ConnectionTest.InterfaceAlias
			Write-Log -Message "Traffic will be sent on interface '$TargetInterface'" -Source "Viva" -MessageType Info
		} else {
			$TargetInterface = $null
			Write-Log -Message "Unable to reach the destination, unable to determine which interface will be used to send queries" -Source "Viva" -MessageType Warning
		}
	}

	$FileTimestamp = Get-DateInFileName
	$OutputFile = Join-Path -Path $OutputPath -ChildPath "$FileTimestamp-Viva.pcapng"

	Start-NetworkTrace -Workload Viva -OutputFile $OutputFile -TargetInterface $TargetInterface

	$InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
	# Set TCP idle timeout to 5 seconds
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

	Write-Log -Message "Starting connection" -Source "Viva" -MessageType Info
	try {
		$VivaConnectivity = Invoke-WebRequest -Uri $VivaURL -UserAgent (Get-UserAgent) -UseBasicParsing

		if ($VivaConnectivity.statuscode -notlike "200") {
			Write-Log -Message "Failed to connect to '$VivaURL' (HTTP code $($VivaConnectivity.statuscode))" -Source "Viva" -MessageType Error
			$VivaConnectivity.Headers.Keys | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
				Write-Log -Message "$_ = $($VivaConnectivity.Headers[$_])" -Source "Viva" -MessageType Error
			}
			$ErrorDetails += "Failed to connect (HTTP code $($VivaConnectivity.statuscode))"
		} else {
			Write-Log -Message "Connected successfully to '$VivaURL'" -Source "Viva" -MessageType Info
			$FrontDoorCode = Get-FrontDoorFromHTTPResponse -HTTPResponse $VivaConnectivity
			if ($FrontDoorCode -notlike "") {
				Write-Log -Message "Viva Front Door: '$FrontDoorCode'" -Source "Viva" -MessageType Info
				Resolve-DnsName -Name "$FrontDoorCode.frontdoor.viva.office365.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
			} else {
				Write-Log -Message "Viva Front Door not detected" -Source "Viva" -MessageType Warning
			}
			Write-Log -Message "Attempting DNS resolution of '$VivaFQDN'" -Source "Viva" -MessageType Info
			Resolve-DnsName -Name $VivaFQDN -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
		}
	} catch {
		Write-Log -Message "Failed to connect to '$VivaURL' with exception: $($_.Exception.Message)" -Source "Viva" -MessageType Error
		if ($_.Exception.Response) {
			$ErrorResponse = $_
			Write-Log -Message "Known headers in response:" -Source "Viva" -MessageType Error
			$_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
				Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "Viva" -MessageType Error
			}
		}
		$ErrorDetails += "Failed to connect to '$VivaURL' with exception: $($_.Exception.Message)"
	}

	# Reset TCP idle timeout to its initial value
	[System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout

	Stop-NetworkTrace -Workload Viva -OutputFile $OutputFile

	Invoke-NetworkTraceFiltering -OutputFile $OutputFile -Workload Viva

	$NormalScriptCompletion = $true
} catch {
    Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "Viva" -MessageType Error
    $ErrorDetails += "Unhandled error: $($_.Exception.Message)"
	$NormalScriptCompletion = $true
} finally {
    Write-Log -Message "Tests completed" -Source "Viva" -MessageType Info
    try {
        if ($null -eq $TestStartTime) {
            $TestStartTime = Get-Date
        }
        Write-TestStatus -StartTime $TestStartTime -Type "Viva" -ErrorDetails $ErrorDetails
        if ($DebugMode -ne $false -and $NormalScriptCompletion -eq $true) {
            if ($ErrorDetails.count -gt 0) {
                timeout /t 30
            } else {
                timeout /t 10
            }
        }
    } catch {
        Write-Log -Message "Failed to write test result: $($_ | Format-List * -Force | Out-String)" -Source "Viva" -MessageType Error
    } finally {
        try {
			Remove-Item -Path $Lockfile -Force | Out-Null
		} catch {
			Write-Log -Message "Failed to remove lockfile" -Source "Viva" -MessageType Error
		}
		Write-Log -Message "Task completed" -Source "Viva" -MessageType Info
    }
}