function Write-Log {
	Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[ValidateSet("Info","Warning","Error")]
		[string]$MessageType
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Message
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[string]$Source
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[switch]$DisplayInGui
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[switch]$NoConsoleDisplay
	)

    try {
        ## Mutex is required to allow parallel writting to logfile
        $Mutex = $null
        $MutexAcquired = $false
        $Mutex = New-Object System.Threading.Mutex($false, "DataCollectionLogFile")
        $MutexAcquired = $Mutex.WaitOne(200)

        if ($Source) {
            if ($Source -match ' - ') {
                $SourceWithPID = $Source -replace '^(.*?) - ',('$1 (PID:'+$PID+') - ')
            } else {
                $SourceWithPID = "$Source (PID:$($PID))"
            }
            $MessageInLogs = "$SourceWithPID - $Message"
            $Message = "$Source - $Message"
        } else {
            $MessageInLogs = $Message
        }

        if ($MessageType -eq "Error") {
            $LogLine = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - ERROR - $MessageInLogs"
            $LogLineForDisplay = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - ERROR - $Message"
            $BackgroundColor = "Black"
            $ForegroundColor = "Red"
        } elseif ($MessageType -eq "Warning") {
            $LogLine = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - WARN  - $MessageInLogs"
            $LogLineForDisplay = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - WARN  - $Message"
            $BackgroundColor = "Black"
            $ForegroundColor = "Yellow"
        } elseif ($MessageType -eq "Info") {
            $LogLine = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - INFO  - $MessageInLogs"
            $LogLineForDisplay = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - INFO    - $Message"
            $BackgroundColor = "Black"
            $ForegroundColor = "White"
        } else {
            $LogLine = $MessageInLogs
            $LogLineForDisplay = $Message
            $BackgroundColor = "Black"
            $ForegroundColor = "White"
        }

        if (-not $NoConsoleDisplay -and $Source -notmatch "Init" -and $MessageType -notlike "") { Write-Host -BackgroundColor $BackgroundColor -ForegroundColor $ForegroundColor $LogLine }
        
        $LogLine | Out-File -FilePath "$env:NPAPath\NPARunlog.log" -Append -Encoding UTF8
    } catch {
        Write-Host "Failed to write to log file"
        Write-Host $_
    } finally {
        if ($MutexAcquired) {
            $Mutex.ReleaseMutex()
        }
        if ($Mutex) {
            $Mutex.Dispose()
        }
    }

    if ($DisplayInGui -and $null -ne $SyncHash.OutputWindow) {
        $SyncHash.OutputWindow.Dispatcher.invoke([action] {
            $SyncHash.OutputWindow.AppendText("$LogLineForDisplay`n")
            $SyncHash.OutputWindow.ScrollToEnd()
        },
        "Normal")
    }
}

function Copy-RunlogAndSettingsToOutputFolder {

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $OutputPath = $CurrentSettings.OutputPath
    
    $RunlogPath = "$env:NPAPath\NPARunlog.log"
    $SettingsPath = "$env:NPAPath\Settings.json"

    Set-OutputFolders

    Copy-Item -Path $RunlogPath -Destination $OutputPath -Force -ErrorAction SilentlyContinue
    Copy-Item -Path $SettingsPath -Destination $OutputPath -Force -ErrorAction SilentlyContinue

}

function Set-OutputFolders {

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $OutputPath = $CurrentSettings.OutputPath
    $OutputPathUnfilteredTraces = Join-Path -Path $OutputPath -ChildPath "UnfilteredTraces"

	if ((Test-Path $OutputPath) -eq $false) {
		New-Item $OutputPath -type directory | Out-Null
	}
	if ((Test-Path $OutputPathUnfilteredTraces) -eq $false) {
		New-Item $OutputPathUnfilteredTraces -type directory | Out-Null
	}
}

function Wait-LockFile {
    Param(
        $Workload,
        $Lockfile
    )

    $count = 0
    While ((Test-Path $Lockfile) -eq $true) {
        # Only display a message every 30sec to prevent spam
        if ($count % 30 -eq 0 -and $count -ne 0) {
            $LockedSince = (Get-Item $Lockfile).LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
            if ($Lockfile -match "tracemaster") {
                $LockingTask = Get-Content -Path $Lockfile | Select-Object -First 1
                Write-Log -Message "Another tracemaster task is still running (PID:$LockingTask since '$LockedSince'). Sleeping..." -Source "$Workload" -MessageType Info
            } else {
                $LockingTask = Get-Content -Path $Lockfile
                Write-Log -Message "Another test is still running ($LockingTask since '$LockedSince'). Sleeping..." -Source "$Workload" -MessageType Info
            }
        }
        $count += 1
        
        if ((New-TimeSpan -Start (Get-Item $Lockfile).LastWriteTime -End (Get-Date)).TotalMinutes -ge 30) {
            if ($Lockfile -match "tracemaster") {
                Write-Log -Message "Killing running tasks and forcefully removing tracemaster lockfile (last locked more than 30 minutes ago)" -Source "$Workload" -MessageType Info
                $ActiveProcesses = Get-Content -Path $Lockfile
                Stop-RunningProcess -ProcessID $ActiveProcesses
                try {
                    Remove-Item -Path $Lockfile -Force | Out-Null
                } catch {
                    Write-Log -Message "Failed to remove tracemaster lockfile" -Source "$Workload" -MessageType Error
                }
            } else {
                Write-Log -Message "Forcefully removing lockfile (last locked more than 30 minutes ago)" -Source "$Workload" -MessageType Info
                try {
                    Remove-Item -Path $Lockfile -Force | Out-Null
                } catch {
                    Write-Log -Message "Failed to remove lockfile" -Source "$Workload" -MessageType Error
                }
            }
        }
        Start-Sleep -Seconds 1
    }
}

function Get-Settings {
    Write-Log -Message "Getting current settings values" -Source "Main" -MessageType Info
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $CurrentSettings | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name | ForEach-Object {
        $SettingName = $_
        $SettingValue = $CurrentSettings.$_
        Write-Log -Message "$SettingName = $SettingValue" -Source "Main" -MessageType Info
    }
}

function Test-Settings {
    Param(
        $SyncHash
    )

    Write-Log -Message "Starting checks" -Source "Main - SettingsCheck" -MessageType Info

    $InvalidSettings = @()

    $OutputPathInvalid = $false

    Write-Log -Message "Processing Output path '$($SyncHash.OutputPath.text)'" -Source "Main - SettingsCheck" -MessageType Info
    if ($SyncHash.OutputPath.text -notlike "") {
        if ($SyncHash.OutputPath.text -match '^\w:\\?$') {
            Write-Log -Message "Output path is a drive root, using an 'Output' subfolder" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
            $SyncHash.OutputPath.text = Join-Path -Path $SyncHash.OutputPath.text -ChildPath "Output"
        }
        if (-not (Test-Path (Split-Path $SyncHash.OutputPath.text))) {
            Write-Log -Message "Output path parent folder does not exist '$(Split-Path $SyncHash.OutputPath.text)'" -Source "Main - SettingsCheck" -MessageType Error -DisplayInGui
            $InvalidSettings += " - Output path parent folder does not exist"
            $OutputPathInvalid = $true
        } else {
            Write-Log -Message "Output path '$($SyncHash.OutputPath.text)' is valid" -Source "Main - SettingsCheck" -MessageType Info
        }
    } else {
        Write-Log -Message "Output path is empty, using the NPA directory by default" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        $SyncHash.OutputPath.text = "$env:NPAPath\Output"
    }

    $RegexInvalidCharacters = "[<>:'`"/\\\|\?\*]"
    Write-Log -Message "Processing Sitename '$($SyncHash.Sitename.Text)'" -Source "Main - SettingsCheck" -MessageType Info
    if ($SyncHash.Sitename.Text -notlike "") {
        if ($SyncHash.Sitename.Text -match $RegexInvalidCharacters) {
            Write-Log -Message "Sitename field contains invalid characters: <>:'`"/\|?*" -Source "Main - SettingsCheck" -MessageType Warning
            Write-Log -Message "Replacing illegal characters with '_'" -Source "Main - SettingsCheck" -MessageType Warning
            $SyncHash.Sitename.Text = $SyncHash.Sitename.Text -replace $RegexInvalidCharacters,'_'
        }
        Write-Log -Message "Sitename field '$($SyncHash.Sitename.Text)' is valid" -Source "Main - SettingsCheck" -MessageType Info
    } else {
        Write-Log -Message "Sitename field is empty" -Source "Main - SettingsCheck" -MessageType Warning
        Write-Log -Message "Valid example: Redmonth_Eth" -Source "Main - SettingsCheck" -MessageType Warning
        $InvalidSettings += " - Sitename field is empty"
    }

    Write-Log -Message "Processing Location '$($SyncHash.Location.Text)'" -Source "Main - SettingsCheck" -MessageType Info
    if ($SyncHash.Location.Text -notlike "") {
        Write-Log -Message "Location field '$($SyncHash.Location.Text)' is valid" -Source "Main - SettingsCheck" -MessageType Info
    } else {
        Write-Log -Message "Location field is empty" -Source "Main - SettingsCheck" -MessageType Warning
        Write-Log -Message "Valid examples: Kansas City, Missouri, USA / London, UK" -Source "Main - SettingsCheck" -MessageType Warning
        $InvalidSettings += " - Location field is empty"
    }
    
    # regex to match IP / IP:port
    $RegexIP = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(:\d{1,5})?$"
    # regex to match FQDN / FQDN:port
    $RegexFQDN = "^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])(\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9]))*(:\d{1,5})?$"

    Write-Log -Message "Processing Egress IP '$($SyncHash.EgressIP.Text)'" -Source "Main - SettingsCheck" -MessageType Info
    if ($SyncHash.EgressIP.text -notlike "") {
        if ($SyncHash.EgressIP.text -notmatch $RegexIP -and $SyncHash.EgressIP.text -notmatch $RegexFQDN) {
            Write-Log -Message "Egress IP field is not a valid IP or FQDN" -Source "Main - SettingsCheck" -MessageType Warning
            Write-Log -Message "Valid examples: 1.2.3.4 / 10.0.0.254:8080 / proxyfqdn.domain.lan / proxyfqdn.domain.lan:8080" -Source "Main - SettingsCheck" -MessageType Warning
            $InvalidSettings += " - Egress IP field is not a valid IP or FQDN"
        } else {
            Write-Log -Message "Egress IP field '$($SyncHash.EgressIP.text)' is valid" -Source "Main - SettingsCheck" -MessageType Info
        }
    }

    $BlockSPOTests = $false

    # regex to match FQDN
    $RegexOneDriveFQDN = "^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])(\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9]))*?)(\.mcas\.ms)?(:\d{1,5})?$"
    # regex to match OneDrive URL with or without mcas.ms/port 'https://contoso-my.sharepoint.com(.mcas.ms)(:xxxx)/personal/user_domain_com...'
    $RegexOneDriveURL = "^(https://(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])(\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9]))*?))(\.mcas\.ms)?(:\d{1,5})?(/personal/(\w|\d|-|_)*?)(/.*)?$"

    Write-Log -Message "Processing OneDrive FQDN '$($SyncHash.OneDriveFQDN.Text)'" -Source "Main - SettingsCheck" -MessageType Info
    if ($SyncHash.OneDriveFQDN.Text -notlike "") {
        if ($SyncHash.OneDriveFQDN.Text -notmatch $RegexOneDriveFQDN) {
            Write-Log -Message "OneDrive FQDN field is incorrect" -Source "Main - SettingsCheck" -MessageType Warning
            if ($SyncHash.OneDriveFQDN.Text -match $RegexOneDriveURL) {
                $SyncHash.OneDriveFQDN.Text = $SyncHash.OneDriveFQDN.Text -replace $RegexOneDriveURL,'$2'
                Write-Log -Message "Extracted OneDrive FQDN from the provided URL" -Source "Main - SettingsCheck" -MessageType Warning
                Write-Log -Message "OneDrive FQDN field '$($SyncHash.OneDriveFQDN.Text)' is valid" -Source "Main - SettingsCheck" -MessageType Info
            } else {
                Write-Log -Message "Valid example: contoso-my.sharepoint.com" -Source "Main - SettingsCheck" -MessageType Warning
                $InvalidSettings += " - OneDrive FQDN field is incorrect"
                $BlockSPOTests = $true
            }
        } else {
            Write-Log -Message "Cleaning provided OneDrive FQDN if necessary" -Source "Main - SettingsCheck" -MessageType Info
            # Sanitize FQDN (remove mcas.ms/port)
            $SyncHash.OneDriveFQDN.Text = $SyncHash.OneDriveFQDN.Text -replace $RegexOneDriveFQDN,'$1'
            Write-Log -Message "OneDrive FQDN field '$($SyncHash.OneDriveFQDN.Text)' is valid" -Source "Main - SettingsCheck" -MessageType Info
        }
    } else {
        Write-Log -Message "OneDrive FQDN field is empty" -Source "Main - SettingsCheck" -MessageType Warning
        Write-Log -Message "Valid example: contoso-my.sharepoint.com" -Source "Main - SettingsCheck" -MessageType Warning
        $InvalidSettings += " - OneDrive FQDN field is empty"
        $BlockSPOTests = $true
    }

    # If app registration is used, validate the OneDrive settings
    if ($SyncHash.cb_AppRegistration.IsChecked -eq $true) {
        
        Write-Log -Message "Processing OneDrive URL '$($SyncHash.OneDriveURL.Text)'" -Source "Main - SettingsCheck" -MessageType Info
        if ($SyncHash.OneDriveURL.Text -notlike "") {
            if ($SyncHash.OneDriveURL.Text -notmatch $RegexOneDriveURL) {
                Write-Log -Message "OneDrive URL field is incorrect" -Source "Main - SettingsCheck" -MessageType Warning
                Write-Log -Message "Valid example: https://contoso-my.sharepoint.com/personal/user_contoso_onmicrosoft_com" -Source "Main - SettingsCheck" -MessageType Warning
                $InvalidSettings += " - OneDrive URL field is incorrect"
                $BlockSPOTests = $true
            } else {
                Write-Log -Message "Cleaning provided OneDrive URL if necessary" -Source "Main - SettingsCheck" -MessageType Info
                # Sanitize URL to match format 'https://contoso-my.sharepoint.com/personal/user_domain_com' (remove mcas.ms/port/trailing text)
                $SyncHash.OneDriveURL.Text = $SyncHash.OneDriveURL.Text -replace $RegexOneDriveURL,'$1$8'
                Write-Log -Message "OneDrive URL field '$($SyncHash.OneDriveURL.Text)' is valid" -Source "Main - SettingsCheck" -MessageType Info
            }
        } else {
            Write-Log -Message "OneDrive URL field is empty" -Source "Main - SettingsCheck" -MessageType Warning
            Write-Log -Message "Valid example: https://contoso-my.sharepoint.com/personal/user_contoso_onmicrosoft_com" -Source "Main - SettingsCheck" -MessageType Warning
            $InvalidSettings += " - OneDrive URL field is empty"
            $BlockSPOTests = $true
        }

        Write-Log -Message "Processing OneDrive Client ID '$($SyncHash.OneDriveClientID.Text)'" -Source "Main - SettingsCheck" -MessageType Info
        if ($SyncHash.OneDriveClientID.Text -notlike "") {
            if ($SyncHash.OneDriveClientID.Text -notmatch "^[0-9A-Fa-f]{8}[-]?(?:[0-9A-Fa-f]{4}[-]?){3}[0-9A-Fa-f]{12}$") {
                Write-Log -Message "OneDrive Client ID field is not a valid GUID" -Source "Main - SettingsCheck" -MessageType Warning
                Write-Log -Message "Valid example: 12345678-abcd-1234-abcd-123456789012" -Source "Main - SettingsCheck" -MessageType Warning
                $InvalidSettings += " - OneDrive Client ID field is not a valid GUID"
                $BlockSPOTests = $true
            } else {
                Write-Log -Message "OneDrive Client ID '$($SyncHash.OneDriveClientID.Text)' is a valid GUID" -Source "Main - SettingsCheck" -MessageType Info
            }
        } else {
            Write-Log -Message "OneDrive Client ID field is empty" -Source "Main - SettingsCheck" -MessageType Warning
            Write-Log -Message "Valid example: 12345678-abcd-1234-abcd-123456789012" -Source "Main - SettingsCheck" -MessageType Warning
            $InvalidSettings += " - OneDrive Client ID field is empty"
            $BlockSPOTests = $true
        }

        Write-Log -Message "Processing Tenant ID '$($SyncHash.TenantID.Text)'" -Source "Main - SettingsCheck" -MessageType Info
        if ($SyncHash.TenantID.Text -notlike "") {
            if ($SyncHash.TenantID.Text -notmatch "^[0-9A-Fa-f]{8}[-]?(?:[0-9A-Fa-f]{4}[-]?){3}[0-9A-Fa-f]{12}$") {
                Write-Log -Message "Tenant ID field is not a valid GUID" -Source "Main - SettingsCheck" -MessageType Warning
                Write-Log -Message "Valid example: 12345678-abcd-1234-abcd-123456789012" -Source "Main - SettingsCheck" -MessageType Warning
                $InvalidSettings += " - Tenant ID field is not a valid GUID"
                $BlockSPOTests = $true
            } else {
                Write-Log -Message "Tenant ID '$($SyncHash.TenantID.Text)' is a valid GUID" -Source "Main - SettingsCheck" -MessageType Info
            }
        } else {
            Write-Log -Message "Tenant ID field is empty" -Source "Main - SettingsCheck" -MessageType Warning
            $InvalidSettings += " - Tenant ID field is empty"
            Write-Log -Message "Valid example: 12345678-abcd-1234-abcd-123456789012" -Source "Main - SettingsCheck" -MessageType Warning
            $BlockSPOTests = $true
        }

        if ($SyncHash.OneDriveClientSecret.password -notlike "") {
            if ($SyncHash.OneDriveClientSecret.password -match "\s+") {
                Write-Log -Message "Removing whitespaces from OneDrive Client Secret field" -Source "Main - SettingsCheck" -MessageType Warning
                $SyncHash.OneDriveClientSecret.password = $SyncHash.OneDriveClientSecret.password -replace '\s+',''
            } else {
                Write-Log -Message "OneDrive Client Secret does not contain whitespaces" -Source "Main - SettingsCheck" -MessageType Info
                Set-Secret -path "$env:NPAPath\secret" -secret $SyncHash.OneDriveClientSecret.password$
            }
        } else {
            Write-Log -Message "OneDrive Client Secret field is empty" -Source "Main - SettingsCheck" -MessageType Warning
            $InvalidSettings += " - OneDrive Client Secret field is empty"
            $BlockSPOTests = $true
        }
    }

    if ($OutputPathInvalid -eq $true) {
        Write-Log -Message "Invalid settings detected" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        Write-Log -Message "Disabling one-time and 7-days collection" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        Write-Log -Message "Correct and save settings to re-enable" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        $SyncHash.TabControl.Items[2].IsEnabled = $false
        $SyncHash.TabControl.Items[3].IsEnabled = $false
        Write-Log -Message "Displaying warning popup" -Source "Main - SettingsCheck" -MessageType Warning
        $WarningText = @"
The following issues were found with the settings:
$($InvalidSettings -Join "`r`n")

Disabling one-time and 7-days collection
Correct and save settings to re-enable
"@
        New-Popup -Title "Invalid settings detected" -Message $WarningText -Buttons OK -Icon Stop | Out-Null
    } elseif ($BlockSPOTests -eq $true) {
        Write-Log -Message "Invalid settings detected" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        Write-Log -Message "Disabling Sharepoint tests and 7-days collection" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        Write-Log -Message "Correct and save settings to re-enable" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        $SyncHash.TabControl.Items[3].IsEnabled = $false
        $SyncHash.cb_Network_SPO.IsChecked = $false
        $SyncHash.cb_Network_SPO.IsEnabled = $false
        $SyncHash.cb_Network_FileTransfer.IsChecked = $false
        $SyncHash.cb_Network_FileTransfer.IsEnabled = $false
        Write-Log -Message "Displaying warning popup" -Source "Main - SettingsCheck" -MessageType Warning
        $WarningText = @"
The following issues were found with the settings:
$($InvalidSettings -Join "`r`n")

Disabling SPO tests and 7-days collection
Correct and save settings to re-enable
"@
        New-Popup -Title "Invalid settings detected" -Message $WarningText -Buttons OK -Icon Stop | Out-Null
    } elseif ($InvalidSettings.count -gt 0) {
        Write-Log -Message "Invalid settings detected" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        Write-Log -Message "Disabling 7-days collection" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        Write-Log -Message "Correct and save settings to re-enable" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
        $SyncHash.TabControl.Items[3].IsEnabled = $false
        Write-Log -Message "Displaying warning popup" -Source "Main - SettingsCheck" -MessageType Warning
        $WarningText = @"
The following issues were found with the settings:
$($InvalidSettings -Join "`r`n")

Disabling 7-days collection
Correct and save settings to re-enable
"@
        New-Popup -Title "Invalid settings detected" -Message $WarningText -Buttons OK -Icon Stop | Out-Null
    } else {
        Write-Log -Message "Settings are valid" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        if ($SyncHash.TabControl.Items[3].IsEnabled -eq $false) {
            if ($SyncHash.CaptureScenario.SelectedValue.Content -eq "Zscaler - encrypted tunnel") {
                Write-Log -Message "Not enabling 7-days collection for Zscaler (encrypted tunnel) scenario" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
            } else {
                Write-Log -Message "Enabling 7-days collection" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
                $SyncHash.TabControl.Items[3].IsEnabled = $true
            }
        } else {
            if ($SyncHash.CaptureScenario.SelectedValue.Content -eq "Zscaler - encrypted tunnel") {
                Write-Log -Message "Disabling 7-days collection for Zscaler (encrypted tunnel) scenario" -Source "Main - SettingsCheck" -MessageType Warning -DisplayInGui
                $SyncHash.TabControl.Items[3].IsEnabled = $false
            }
        }
        
        if ($SyncHash.cb_Network_SPO.IsEnabled -eq $false) {
            Write-Log -Message "Enabling Sharepoint tests" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
            $SyncHash.cb_Network_SPO.IsEnabled = $true
            $SyncHash.cb_Network_FileTransfer.IsEnabled = $true
        }
    }

    if ($SyncHash.TenantType.SelectedIndex -ne 0 -and $SyncHash.cb_Network_Viva.IsEnabled -eq $true) {
        Write-Log -Message "Disabling Viva tests for GCCH/DOD tenants" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        $SyncHash.cb_Network_Viva.IsChecked = $false
        $SyncHash.cb_Network_Viva.IsEnabled = $false
    } elseif ($SyncHash.TenantType.SelectedIndex -eq 0 -and $SyncHash.cb_Network_Viva.IsEnabled -eq $false) {
        Write-Log -Message "Enabling Viva tests for non GCCH/DOD tenants" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        $SyncHash.cb_Network_Viva.IsEnabled = $true
    }

    if ($SyncHash.TenantType.SelectedIndex -ne 0 -and $SyncHash.cb_Network_Copilot.IsEnabled -eq $true) {
        Write-Log -Message "Disabling Copilot tests for GCCH/DOD tenants" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        $SyncHash.cb_Network_Copilot.IsChecked = $false
        $SyncHash.cb_Network_Copilot.IsEnabled = $false
    } elseif ($SyncHash.TenantType.SelectedIndex -eq 0 -and $SyncHash.cb_Network_Copilot.IsEnabled -eq $false) {
        Write-Log -Message "Enabling Copilot tests for non GCCH/DOD tenants" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        $SyncHash.cb_Network_Copilot.IsEnabled = $true
    }

    if ($SyncHash.TenantType.SelectedIndex -ne 0 -and $SyncHash.cb_Network_MicrosoftDomain.IsEnabled -eq $true) {
        Write-Log -Message "Disabling MicrosoftDomain tests for GCCH/DOD tenants" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        $SyncHash.cb_Network_MicrosoftDomain.IsChecked = $false
        $SyncHash.cb_Network_MicrosoftDomain.IsEnabled = $false
    } elseif ($SyncHash.TenantType.SelectedIndex -eq 0 -and $SyncHash.cb_Network_MicrosoftDomain.IsEnabled -eq $false) {
        Write-Log -Message "Enabling MicrosoftDomain tests for non GCCH/DOD tenants" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        $SyncHash.cb_Network_MicrosoftDomain.IsEnabled = $true
    }

    if ($OutputPathInvalid -eq $false -and $SyncHash.TabControl.Items[2].IsEnabled -eq $false) {
        Write-Log -Message "Output path is valid, enabling one-time collection" -Source "Main - SettingsCheck" -MessageType Info -DisplayInGui
        $SyncHash.TabControl.Items[2].IsEnabled
    }

    Write-Log -Message "Checks done" -Source "Main - SettingsCheck" -MessageType Info
}

function Set-SettingsVisibility {
    if ($SyncHash.cb_AppRegistration.IsChecked -eq $false) {
        if ($SyncHash.OneDriveURL.Visibility -eq "Visible") {
            Write-Log -Message "Disabling OneDrive related fields when app registration is not used" -Source "Main" -MessageType Info

            $SyncHash.OneDriveURL.Visibility = "Collapsed"
            $SyncHash.OneDriveURL_Label.Visibility = "Collapsed"
            $SyncHash.OneDriveClientID.Visibility = "Collapsed"
            $SyncHash.OneDriveClientID_Label.Visibility = "Collapsed"
            $SyncHash.OneDriveClientSecret.Visibility = "Collapsed"
            $SyncHash.OneDriveClientSecret_Label.Visibility = "Collapsed"
            $SyncHash.TenantID.Visibility = "Collapsed"
            $SyncHash.TenantID_Label.Visibility = "Collapsed"
            $SyncHash.grp_Setting_OneDrive.Height = 75
        }
    } else {
        if ($SyncHash.OneDriveURL.Visibility -eq "Collapsed") {
            Write-Log -Message "Enabling OneDrive related fields when app registration is used" -Source "Main" -MessageType Info

            $SyncHash.OneDriveURL.Visibility = "Visible"
            $SyncHash.OneDriveURL_Label.Visibility = "Visible"
            $SyncHash.OneDriveClientID.Visibility = "Visible"
            $SyncHash.OneDriveClientID_Label.Visibility = "Visible"
            $SyncHash.OneDriveClientSecret.Visibility = "Visible"
            $SyncHash.OneDriveClientSecret_Label.Visibility = "Visible"
            $SyncHash.TenantID.Visibility = "Visible"
            $SyncHash.TenantID_Label.Visibility = "Visible"
            $SyncHash.grp_Setting_OneDrive.Height = 200
        }
    }

    Set-ExamplesVisibility
}

function Set-ExamplesVisibility {

    if ($SyncHash.Sitename.Text -notlike "") {
        $SyncHash.Sitename_Example.Visibility = "Collapsed"
    } else {
        $SyncHash.Sitename_Example.Visibility = "Visible"
    }

    if ($SyncHash.Location.Text -notlike "") {
        $SyncHash.Location_Example.Visibility = "Collapsed"
    } else {
        $SyncHash.Location_Example.Visibility = "Visible"
    }

    if ($SyncHash.EgressIP.Text -notlike "") {
        $SyncHash.EgressIP_Example.Visibility = "Collapsed"
    } else {
        $SyncHash.EgressIP_Example.Visibility = "Visible"
    }

    if ($SyncHash.OneDriveFQDN.Visibility -eq "Visible") {
        if ($SyncHash.OneDriveFQDN.Text -notlike "") {
            $SyncHash.OneDriveFQDN_Example.Visibility = "Collapsed"
        } else {
            $SyncHash.OneDriveFQDN_Example.Visibility = "Visible"
        }
    } else {
        $SyncHash.OneDriveFQDN_Example.Visibility = "Collapsed"
    }

    if ($SyncHash.OneDriveURL.Visibility -eq "Visible") {
        if ($SyncHash.OneDriveURL.Text -notlike "") {
            $SyncHash.OneDriveURL_Example.Visibility = "Collapsed"
        } else {
            $SyncHash.OneDriveURL_Example.Visibility = "Visible"
        }
    } else {
        $SyncHash.OneDriveURL_Example.Visibility = "Collapsed"
    }

    if ($SyncHash.OneDriveClientID.Visibility -eq "Visible") {
        if ($SyncHash.OneDriveClientID.Text -notlike "") {
            $SyncHash.OneDriveClientID_Example.Visibility = "Collapsed"
        } else {
            $SyncHash.OneDriveClientID_Example.Visibility = "Visible"
        }
    } else {
        $SyncHash.OneDriveClientID_Example.Visibility = "Collapsed"
    }
    
    if ($SyncHash.TenantID.Visibility -eq "Visible") {
        if ($SyncHash.TenantID.Text -notlike "") {
            $SyncHash.TenantID_Example.Visibility = "Collapsed"
        } else {
            $SyncHash.TenantID_Example.Visibility = "Visible"
        }
    } else {
        $SyncHash.TenantID_Example.Visibility = "Collapsed"
    }

}

# Creates consistent dates in the logs and files
function Get-DateInFile {
    Param(
        [Parameter(Mandatory=$false)]
        $DateTime = (Get-Date)
    )

    Get-Date $DateTime -Format "yyyyMMdd HH:mm:ss"
}

# Consistent dates in filenames
function Get-DateInFileName {
    Param(
        [Parameter(Mandatory=$false)]
        $DateTime = (Get-Date)
    )

    Get-Date $DateTime -Format "yyyyMMdd-HHmm"
}

function Write-TestStatus {
    Param(
        [Parameter(Mandatory=$true)]
        $StartTime
        ,
        [Parameter(Mandatory=$true)]
        $Type
        ,
        [Parameter(Mandatory=$false)]
        $ErrorDetails
    )

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $OutputPath = $CurrentSettings.OutputPath

    $CurrentTestStatus = New-Object PSObject -Property ([ordered]@{
        StartTime       = Get-DateInFile $StartTime
        EndTime         = Get-DateInFile
        Duration        = [math]::Round((New-TimeSpan $StartTime (Get-Date)).TotalSeconds,2) -replace ',','.'
        Type            = $Type
        Result          = if ($ErrorDetails.Count -gt 0) {"Failure"} else {"Success"}
        ErrorDetails    = $ErrorDetails -join ' / '
    })
    if (-not (Test-Path "$OutputPath\TestsResults.csv")) {
        ("StartTime","EndTime","Duration","Type","Result","ErrorDetails") -join "`t" | Out-File -FilePath "$OutputPath\TestsResults.csv" -Encoding UTF8
    }
    ($CurrentTestStatus.StartTime,$CurrentTestStatus.EndTime,$CurrentTestStatus.Duration,$CurrentTestStatus.Type,$CurrentTestStatus.Result,$CurrentTestStatus.ErrorDetails) -join "`t" | Out-File -FilePath "$OutputPath\TestsResults.csv" -Encoding UTF8 -Append
}

# Function to create a pop up message
function New-Popup {
    Param (
        [Parameter(Position = 0, Mandatory = $true, HelpMessage = "Enter a message for the popup")]
        [ValidateNotNullorEmpty()]
        [string]$Message,
        [Parameter(Position = 1, Mandatory = $true, HelpMessage = "Enter a title for the popup")]
        [ValidateNotNullorEmpty()]
        [string]$Title,
        [Parameter(Position = 2, HelpMessage = "How many seconds to display? Use 0 require a button click.")]
        [ValidateScript( { $_ -ge 0 })]
        [int]$Time = 0,
        [Parameter(Position = 3, HelpMessage = "Enter a button group")]
        [ValidateNotNullorEmpty()]
        [ValidateSet("OK", "OKCancel", "AbortRetryIgnore", "YesNo", "YesNoCancel", "RetryCancel", "CancelTryAgainCOntinue")]
        [string]$Buttons = "OK",
        [Parameter(Position = 4, HelpMessage = "Enter an icon set")]
        [ValidateNotNullorEmpty()]
        [ValidateSet("Stop", "Question", "Exclamation", "Information" )]
        [string]$Icon = "Information",
        [Parameter(HelpMessage = "Select which button will be selected as the default")]
        [ValidateSet("Second", "Third")]
        [string]$DefaultButton
    )

    #convert buttons to their integer equivalents
    Switch ($Buttons) {
        "OK" { $ButtonValue = 0 }
        "OKCancel" { $ButtonValue = 1 }
        "AbortRetryIgnore" { $ButtonValue = 2 }
        "YesNoCancel" { $ButtonValue = 3 }
        "YesNo" { $ButtonValue = 4 }
        "RetryCancel" { $ButtonValue = 5 }
        "CancelTryAgainCOntinue" { $ButtonValue = 6 }
    }

    #set an integer value for Icon type
    Switch ($Icon) {
        "Stop" { $iconValue = 16 }
        "Question" { $iconValue = 32 }
        "Exclamation" { $iconValue = 48 }
        "Information" { $iconValue = 64 }
    }

    Switch ($DefaultButton) {
        "Second" { $Selectedbtn = 256 }
        "Third" { $Selectedbtn = 512 }
    }

    #create the COM Object
    try {
        $wshell = New-Object -ComObject Wscript.Shell -ErrorAction Stop
        #Button and icon type values are added together to create an integer value
        $wshell.Popup($Message, $Time, $Title, $ButtonValue + $iconValue + $Selectedbtn)
    }
    catch {
        #You should never really run into an exception in normal usage
        Write-Warning "Failed to create Wscript.Shell COM object: $($_.Exception.Message)"
    }
}

function New-Balloontip {
    Param(
        [Parameter(Position = 0, Mandatory = $true, HelpMessage = "Enter a title for the balloon tip")]
        [ValidateNotNullorEmpty()]
        [string]$Title,
        [Parameter(Position = 1, Mandatory = $true, HelpMessage = "Enter a message for the balloon tip")]
        [ValidateNotNullorEmpty()]
        [string]$message,
        [Parameter(Position = 2, HelpMessage = "Enter a button group")]
        [ValidateSet("Error", "Info", "None", "Warning")]
        [string]$ToolTipIcon = "None",
        [Parameter(Position = 3, HelpMessage = "Duration for the balloon tip to be visable in milliseconds")]
        [int]$duration = 5000
    )
    Add-Type -AssemblyName System.Windows.Forms

    # Have to check if it already exisist, otherwise we get errors!
    if (-not $global:balloon) {
        $global:balloon = New-Object System.Windows.Forms.NotifyIcon

        # Double click to remove the balloontip
        [void](Register-ObjectEvent  -InputObject $balloon  -EventName MouseDoubleClick  -SourceIdentifier IconClicked  -Action {

                #Perform cleanup actions on balloon tip
                $global:balloon.dispose()

                Unregister-Event  -SourceIdentifier IconClicked
                Remove-Job -Name IconClicked
                Remove-Variable  -Name balloon  -Scope Global
            })
    }

    # This will take the icon of whatever process is launching it
    $path = (Get-Process -Id $pid).Path
    $balloon.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($path)

    $balloon.BalloonTipText = $message
    $balloon.BalloonTipTitle = $Title

    switch ($ToolTipIcon) {
        "Error" { $balloon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Error }
        "Info" { $balloon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info }
        "None" { $balloon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::None }
        "Warning" { $balloon.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Warning }
    }

    $balloon.Visible = $true

    # Time in ms to display the tooltip
    $balloon.ShowBalloonTip($Duration)
}

function Update-Control {
    Param (
        $SyncHash,
        $Control,
        $Property,
        $Value,
        [switch]$AppendContent,
        [Switch]$Add
    )

    #TODO Can we find a better way to do this?
    if ($Property -eq "Close") {
        $SyncHash.Window.Dispatcher.invoke([action] { $SyncHash.Window.Close() }, "Normal")
        return
    }

    # This updates the control based on the parameters passed to the function
    $SyncHash.$Control.Dispatcher.Invoke([action] {
        # This bit is only really meaningful for the TextBox control, which might be useful for logging progress steps
        if ($PSBoundParameters['AppendContent']) {
            $SyncHash.$Control.AppendText($Value)
        }
        if ($PSBoundParameters['Add']) {
            $current = $SyncHash.$Control.$Property
            $Value = $current + $Value
            $SyncHash.$Control.$Property = $Value
        } else {
            $SyncHash.$Control.$Property = $Value
        }
    }, "Normal")
}

function Update-TestsStatusLabel {
    foreach ($CurrentTest in $SyncHash.TestsStates) {
        if ($SyncHash.($CurrentTest.StatusLabelName).Content -ne $CurrentTest.State) {
            Update-Control -SyncHash $SyncHash -Control $CurrentTest.StatusLabelName -Property Content -Value $CurrentTest.State
        }
    }
}

function Get-FileContentHash {
    Param (
		[Parameter(ValueFromPipeline=$true, ValueFromPipelineByPropertyName = $true, Mandatory = $true)]
        [Alias('FileInfo')]
		[System.IO.FileSystemInfo]$File
	)

    Process {
        $FilePath = $File.FullName
        # Get the line for the start of signature block
        if ($File.Name -eq "DataCollection.psm1") {
            # Skip the 2 expected occurences which are the two lines below
            $SignatureBlockLineNumber = (Get-Item $FilePath | Select-String -Pattern '# SIG # Begin signature block').LineNumber | Select-Object -Skip 2
        } else {
            $SignatureBlockLineNumber = (Get-Item $FilePath | Select-String -Pattern '# SIG # Begin signature block').LineNumber
        }
        # Get file content up to the signature block (if it exists)
        if ($SignatureBlockLineNumber) {
            $FileContent = Get-Content $FilePath -First ($SignatureBlockLineNumber-1)
        } else {
            $FileContent = Get-Content $FilePath
        }
        # Convert content to Base64 encoding
        $FileContentBase64 = [System.Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($FileContent))
        # Get SHA256 hash from Base64 encoded string
        $FileHash = Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$FileContentBase64)) -Algorithm SHA256
        $FileHash.Path = $FilePath
        $FileHash
    }
}

function Compress-FilesInBatches {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[System.IO.FileSystemInfo[]]$Files
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Destination
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[string]$BaseName
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[int]$MaxPackageSizeMB
	)

    try {
        $TotalSize = ($Files | Measure-Object -Property Length -Sum).Sum
        
        Write-Log -Message "Total size to compress: $([int]($TotalSize/1MB))MB ($($Files.count) files)" -Source "Main - Packaging" -MessageType Info
        
        # Calculate how many files is 2% progress
        $UpdateStep = [math]::Ceiling($Files.count/50)
        # Minimum progress value is 10 files
        if ($UpdateStep -lt 10) { $UpdateStep = 10 }
        # Maximum progress value is 50 files
        if ($UpdateStep -gt 50) { $UpdateStep = 50 }
        
        $CurrentPackage = 1
        $CurrentPackageSize = 0
        $FilesInCurrentPackage = @()

        $CurrentBatchSize = 0
        $FilesInCurrentBatch = @()
        
        $TotalFilesProcessed = 0
        
        if ($MaxPackageSizeMB -eq 0) {
            $DestinationPath = Join-Path -Path $Destination -ChildPath "$($BaseName).zip"
            Write-Log -Message "Creating a single archive" -Source "Main - Packaging" -MessageType Info

            foreach ($File in $Files) {
                if ($SyncHash.CurrentlyPackaging -eq $false) {
                    break
                }

                $FilesInCurrentBatch += $File
                $TotalFilesProcessed++

                # Add files to the archive by batches to prevent slowing down
                if ($FilesInCurrentBatch.count -eq $UpdateStep -or $TotalFilesProcessed -eq $Files.count) {
                    Write-Log -Message "Processed $TotalFilesProcessed files ($($Files.count - $TotalFilesProcessed) files left)" -Source "Main - Packaging" -MessageType Info
                    $FilesInCurrentBatch | Compress-Archive -DestinationPath $DestinationPath -Update
                    Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Value -Value $FilesInCurrentBatch.count -Add
                    $FilesInCurrentBatch = @()
                }
            }

            Write-Log -Message "Last file reached: $($TotalFilesProcessed) files - $([int]((Get-Item -Path $DestinationPath).Length/1MB))MB" -Source "Main - Packaging" -MessageType Info

        } else {

            $DestinationPath = Join-Path -Path $Destination -ChildPath "$($BaseName)_Part$CurrentPackage.zip"
            Write-Log -Message "Creating $($MaxPackageSizeMB)MB archives" -Source "Main - Packaging" -MessageType Info

            Write-Log -Message "Starting new package" -Source "Main - Packaging - Package $CurrentPackage" -MessageType Info

            foreach ($File in $Files) {
                if ($SyncHash.CurrentlyPackaging -eq $false) {
                    break
                }

                if ($CurrentPackageSize -gt ($($MaxPackageSizeMB) * 1MB)) {
                    Write-Log -Message "Maximum package size reached: $($FilesInCurrentPackage.count) files - $([int]($CurrentPackageSize/1MB))MB" -Source "Main - Packaging - Package $CurrentPackage" -MessageType Info
                    $CurrentPackage++
                    $CurrentPackageSize = 0
                    $FilesInCurrentPackage = @()
                    $DestinationPath = Join-Path -Path $Destination -ChildPath "$($BaseName)_Part$CurrentPackage.zip"
                    Write-Log -Message "Starting new package" -Source "Main - Packaging - Package $CurrentPackage" -MessageType Info
                }

                $TotalFilesProcessed++
                $FilesInCurrentPackage += $File
                $FilesInCurrentBatch += $File
                $CurrentBatchSize = ($FilesInCurrentBatch | Measure-Object -Sum -Property Length).Sum
                Write-Log -Message "Processing file: $($File.Name) - $([int]($File.Length/1KB))KB ($TotalFilesProcessed/$($Files.count))" -Source "Main - Packaging - Package $CurrentPackage" -MessageType Info

                # Add files to the archive by batches to prevent slowing down
                if ($FilesInCurrentBatch.count -eq $UpdateStep -or ($CurrentPackageSize + $CurrentBatchSize) -ge ($MaxPackageSizeMB*1MB) -or $TotalFilesProcessed -eq ($Files.count)) {
                    $FilesInCurrentBatch | Compress-Archive -DestinationPath $DestinationPath -Update
                    $CurrentPackageSize = (Get-Item -Path $DestinationPath).Length
                    Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Value -Value $FilesInCurrentBatch.count -Add
                    Write-Log -Message "$($FilesInCurrentPackage.count) files in current package - $([int]($CurrentPackageSize/1MB))MB ($($Files.count - $TotalFilesProcessed) files left)" -Source "Main - Packaging - Package $CurrentPackage" -MessageType Info
                    $CurrentBatchSize = 0
                    $FilesInCurrentBatch = @()
                }

            }

            if ($SyncHash.CurrentlyPackaging -eq $false) {
                Write-Log -Message "Stopping packaging" -Source "Main - Packaging - Package $CurrentPackage" -MessageType Warning
            } else {
                Write-Log -Message "Last file reached: $($FilesInCurrentPackage.count) files - $([int]($CurrentPackageSize/1MB))MB" -Source "Main - Packaging - Package $CurrentPackage" -MessageType Info
            }
        }
    } catch {
        Write-Log -Message "Failed to compress files: $($_.Exception.Message)" -Source "Main - Packaging" -MessageType Error -DisplayInGui
    }
}

function Start-AsyncTask {
    Param(
        $Workload
    )

    $ActivityName,$ScriptName = Switch ($Workload) {
        "Package" {"Package",$null}
        "Status" {"Status",$null}
        "OutputCheck" {"OutputCheck",$null}
        "ScheduledTasksStatus" {"ScheduledTasksStatus",$null}
        "ScheduleTasks" {"ScheduleTasks",$null}
        "IPConfig" {"IPConfig",$null}
        "Tracert" {"Traceroute","Worker-Tracert.ps1"}
        "DNSLookup" {"DNS","Worker-Trace-DNSLookup.ps1"}
        "EXO" {"Exchange","Worker-Trace-EXO.ps1"}
        "Teams" {"Teams","Worker-Trace-Teams.ps1"}
        "SPO" {"Sharepoint","Worker-Trace-SPO.ps1"}
        "Viva" {"Viva","Worker-Trace-Viva.ps1"}
        "Copilot" {"Copilot","Worker-Trace-Copilot.ps1"}
        "MicrosoftDomain" {"MicrosoftDomain","Worker-Trace-MicrosoftDomain.ps1"}
        "FileTransfer" {"File Transfer","Worker-Trace-FileTransfer.ps1"}
        "TeamsMediaQuality" {"Teams Media Quality","Worker-Teams-TestCall.ps1"}
    }

    # Runspace building for the task
    $newRunspace = [runspacefactory]::CreateRunspace()
    $newRunspace.ApartmentState = "STA"
    $newRunspace.ThreadOptions = "ReuseThread"
    if ($ScriptName -notlike "" -or $Workload -eq "IPConfig") {
        $newRunspace.Name = "DataCollection_Tests_$Workload"
    } else {
        $newRunspace.Name = "DataCollection_$Workload"
    }

    $newRunspace.Open()
    $newRunspace.SessionStateProxy.SetVariable("SyncHash", $SyncHash)
    $newRunspace.SessionStateProxy.SetVariable("OutputPath", $OutputPath)
    $newRunspace.SessionStateProxy.SetVariable("Workload", $Workload)
    $newRunspace.SessionStateProxy.SetVariable("ActivityName", $ActivityName)
    $newRunspace.SessionStateProxy.SetVariable("ScriptName", $ScriptName)
    $newRunspace.SessionStateProxy.SetVariable("SkipTeamsNAT", $SyncHash.cb_SkipTeamsNAT.IsChecked)

    $powershell_CurrentTask = [PowerShell]::Create().AddScript({
        
        Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null
        
        if ($Workload -eq "Package") {

            Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Value -Value 0
            Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Maximum -Value 1
        
            # Variables
            $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
        
            $OutputPath = $CurrentSettings.OutputPath
            $OutputPathUnfilteredTraces = Join-Path -Path $OutputPath -ChildPath "UnfilteredTraces"
            $Sitename = $CurrentSettings.SiteName
            if ($Sitename -like "") {$Sitename = $env:COMPUTERNAME}
            $UploadPath = (Join-Path -Path (Split-Path $OutputPath) -ChildPath "FilesToUpload")
        
            
            # Create upload directory if it does not exist
            if (-not (Test-Path $UploadPath)) {
                Write-Log -Message "Creating packages directory" -Source "Main - Packaging" -MessageType Info -DisplayInGui
                New-Item -ItemType Directory -Path $UploadPath | Out-Null
            } else {
                Write-Log -Message "Packages directory already exists" -Source "Main - Packaging" -MessageType Info
                if (Get-ChildItem -Path $UploadPath -Filter *.zip) {
                    Write-Log -Message "Packages directory already contains zip files, move them to a different destination" -Source "Main - Packaging" -MessageType Warning -DisplayInGui
                    explorer.exe "$UploadPath"
                    return
                }
            }
            
            Copy-RunlogAndSettingsToOutputFolder
            
            Write-Log -Message "Fetching files to package" -Source "Main - Packaging" -MessageType Info
            $OutputFiles = @()
            # Process non-traces files first and exclude zip files
            $OutputFiles += Get-ChildItem -Path $OutputPath -Exclude *.zip,*.pcapng | Where-Object {$_.PSIsContainer -eq $false}
            # Process traces files next
            $OutputFiles += Get-ChildItem -Path $OutputPath -Filter *.pcapng | Where-Object {$_.PSIsContainer -eq $false}
            # Get unfiltered traces into dedicated archives
            $UnfilteredTracesFiles = Get-ChildItem -Path $OutputPathUnfilteredTraces | Where-Object {$_.PSIsContainer -eq $false}

            Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Maximum -Value ($OutputFiles.count + $UnfilteredTracesFiles.count)
            Update-Control -SyncHash $SyncHash -Control btn_finish_Package -Property Content -Value "Stop"

            if ($SyncHash.PackageSizeMB -eq 0) {
                Write-Log -Message "Files will be compressed in single archives" -Source "Main - Packaging" -MessageType Info
            } else {
                Write-Log -Message "Files will be split in $($SyncHash.PackageSizeMB)MB archives" -Source "Main - Packaging" -MessageType Info
            }

            Write-Log -Message "Packaging output files" -Source "Main - Packaging" -MessageType Info -DisplayInGui
            Compress-FilesInBatches -Files $OutputFiles -Destination $UploadPath -BaseName "NPAData_$($SiteName)" -MaxPackageSizeMB $SyncHash.PackageSizeMB
            # Break if user clicked the "Stop" button
            if ($SyncHash.CurrentlyPackaging -eq $true) {
                Write-Log -Message "Packaging unfiltered traces" -Source "Main - Packaging" -MessageType Info -DisplayInGui
                Compress-FilesInBatches -Files $UnfilteredTracesFiles -Destination $UploadPath -BaseName "NPAData_$($SiteName)_UnfilteredTraces" -MaxPackageSizeMB $SyncHash.PackageSizeMB
                Write-Log -Message "Packages created in folder: $UploadPath" -Source "Main - Packaging" -MessageType Info -DisplayInGui
                explorer.exe "$UploadPath"
                $SyncHash.CurrentlyPackaging = $false
            } else {
                Write-Log -Message "Packaging stopped" -Source "Main - Packaging" -MessageType Warning -DisplayInGui
                Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Value -Value 0
                Update-Control -SyncHash $SyncHash -Control ProgressBar -Property Maximum -Value 1
            }
            Update-Control -SyncHash $SyncHash -Control btn_finish_Package -Property Content -Value "Package"
        
        } elseif ($Workload -eq "Status") {

            $Lockfile = "$env:NPAPath\lock.lck"
            Start-Sleep -Seconds 2

            While ($SyncHash.TestsStates | Where-Object {$_.State -notmatch "Idle|Finished"}) {
                Start-Sleep -Milliseconds 200
                Update-TestsStatusLabel
            }

            Update-TestsStatusLabel
            
            # Run only if the tests have ended normally (not manually stopped)
            if ($SyncHash.CollectionInProgress -eq $true) {
                $SyncHash.CollectionInProgress = $false
                Stop-AllNetworkTraces -LogType "Main - Normal Stop"
                Write-Log -Message "Cleaning up runspaces for the tasks" -Source "Main" -MessageType Info
                Get-Runspace | Where-Object {$_.Name -match "DataCollection_Tests_.*"} | ForEach-Object {$_.Close()}
                Get-Runspace | Where-Object {$_.Name -match "DataCollection_Tests_.*"} | ForEach-Object {$_.Dispose()}
                Write-Log -Message "Done cleaning runspaces for the tasks" -Source "Main" -MessageType Info

                Write-Log -Message "All tests completed" -Source "Main" -MessageType Info -DisplayInGui
                New-Balloontip -Title "Network Performance Assessment" -message "All tests completed"

            # Run only when tests have been manually stopped
            } else {
                Stop-AllNetworkTraces -LogType "Main - Manual Stop"
                Write-Log -Message "Cleaning up runspaces for the tasks after manual close in 1 second" -Source "Main" -MessageType Info
                Start-Sleep -Seconds 1
                Get-Runspace | Where-Object {$_.Name -match "DataCollection_Tests_.*"} | ForEach-Object {$_.Close()}
                Get-Runspace | Where-Object {$_.Name -match "DataCollection_Tests_.*"} | ForEach-Object {$_.Dispose()}
                Write-Log -Message "Done cleaning runspaces for the tasks" -Source "Main" -MessageType Info

                Write-Log -Message "All tests have been canceled" -Source "Main" -MessageType Info -DisplayInGui
                New-Balloontip -Title "Network Performance Assessment" -message "All tests have been canceled"

            }

            Update-Control -SyncHash $SyncHash -Control btn_Single_collect -Property Content -Value "Collect"

            #clear lock file if present
            Remove-Item $Lockfile -Force -ErrorAction SilentlyContinue | Out-Null

        } elseif ($Workload -eq "OutputCheck") {

            Update-Control -SyncHash $SyncHash -Control btn_Network_OutputCheck -Property IsEnabled -Value $false
            $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
            $WiresharkPath = $CurrentSettings.WiresharkPath
            if (-not (Test-Path "$WiresharkPath\tshark.exe")) {
                Write-Log -Message "Wireshark not found at $WiresharkPath" -Source "Main" -MessageType Warning -DisplayInGui
                Write-Log -Message "Tshark (Wireshark) cannot be found, network trace validation will not be possible" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                New-Popup -Title "Traces will NOT be validated" -Message "The network traces validation requires Tshark (Wireshark) which wasn't detected`r`n`r`nNetwork trace files will NOT be validated" -Buttons OK -Icon Exclamation | Out-Null
            }

            Write-Log -Message "Checking all output files" -Source "Main" -MessageType Info -DisplayInGui
            $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
            if ($CurrentSettings.TenantType[0] -ne 0) {
                $TestsList = "IPConfig","Tracert","DNSLookup","EXO","Teams","SPO","FileTransfer","TeamsMediaQuality"
            } else {
                $TestsList = "IPConfig","Tracert","DNSLookup","EXO","Teams","SPO","Viva","Copilot","MicrosoftDomain","FileTransfer","TeamsMediaQuality"
            }
            foreach ($Test in $TestsList) {
                Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Test)_CheckResult" foreground -Value "Black"
                Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Test)_CheckResult" -Property Content -Value "-"
            }
            foreach ($Test in $TestsList) {
                Test-OutputFile -Workload $Test
            }
            Write-Log -Message "All output files have been checked" -Source "Main" -MessageType Info -DisplayInGui
            Update-Control -SyncHash $SyncHash -Control btn_Network_OutputCheck -Property IsEnabled -Value $true

        } elseif ($Workload -eq "ScheduledTasksStatus") {

            Get-TaskStatus

        } elseif ($Workload -eq "ScheduleTasks") {

            $SyncHash.credValid = $false
            $InvalidCredCount = 0
            $DisableDomainCreds = (Get-ItemProperty -path Registry::HKLM\System\CurrentControlSet\Control\Lsa\ -Name DisableDomainCreds).DisableDomainCreds
            $ScheduleTasksWithoutPassword = $false
            
            $RunningAsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
            if ($RunningAsAdmin) {
                Write-Log -Message "Script is running as administrator, tasks will be set with 'Highest' run level" -Source "Main - TaskScheduling" -MessageType Info
                $TasksRunLevel = "Highest"
            } else {
                Write-Log -Message "Script is not running as administrator, tasks will be set with 'Limited' run level" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
                $TasksRunLevel = "Limited"
            }

            Write-Log -Message "Removing any previously created test task" -Source "Main - TaskScheduling" -MessageType Info
            $TestTaskName = "NPA - TestTask"
            if (Get-ScheduledTaskInfo -TaskName $TestTaskName -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName $TestTaskName -Confirm:$false }
            
            while ($SyncHash.credValid -eq $false) {
                if ($DisableDomainCreds -or $ScheduleTasksWithoutPassword) {
                    if ($DisableDomainCreds) {
                        Write-Log -Message "Attempting to register test task without user credentials due to policy (DisableDomainCreds)" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
                    } elseif ($ScheduleTasksWithoutPassword) {
                        Write-Log -Message "Attempting to register test task without user credentials at user request" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
                    }
                    $SyncHash.cred = New-Object System.Management.Automation.PSCredential([System.Security.Principal.WindowsIdentity]::GetCurrent().Name,(ConvertTo-SecureString -String " " -AsPlainText -Force))
                    Write-Log -Message "Validating task creation permissions" -Source "Main - TaskScheduling" -MessageType Info
                    try {
                        Register-ScheduledTask -TaskName $TestTaskName -User $SyncHash.cred.UserName -RunLevel $TasksRunLevel -Action (New-ScheduledTaskAction -Execute "PowerShell") -ErrorAction Stop | Out-Null
                        Start-Sleep -Seconds 1
                        if (Get-ScheduledTaskInfo -TaskName $TestTaskName -ErrorAction SilentlyContinue) {
                            Write-Log -Message "Test task created successfully" -Source "Main - TaskScheduling" -MessageType Info
                            $SyncHash.credValid = $true
                            Write-Log -Message "Removing test task" -Source "Main - TaskScheduling" -MessageType Info
                            Unregister-ScheduledTask -TaskName $TestTaskName -Confirm:$false
                        } else {
                            Write-Log -Message "Unable to register test task (unknown error)" -Source "Main - TaskScheduling" -MessageType Error
                            break
                        }
                    } catch {
                        Write-Log -Message "Unable to register test task: $($_.Exception.Message)" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                        break
                    }
                } else {
                    Write-Log -Message "Requesting credentials for task scheduling" -Source "Main - TaskScheduling" -MessageType Info
                    try {
                        $CurrentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                        $SyncHash.cred = $SyncHash.host.ui.PromptForCredential('Task Scheduling Credentials Request', 'Current user password to schedule the NPA tasks (current user only)', "$CurrentUser","")
                        if ($null -eq $synchash.cred) {
                            Write-Log -Message "No credentials provided" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                            $Message = "No credentials provided`r`n`r`n"
                            $Message += "Attempt to register tasks without providing credentials?`r`n`r`n"
                            $Message += "Note: Tasks will not be able to restart if the machine reboots, the user logs off or the session locks"
                            $UserAnswer = New-Popup -Title "Task Scheduling Credentials Request" -Message $Message -Buttons "YesNo" -Icon Exclamation -DefaultButton "Second"
                            if ($UserAnswer -eq 6) {
                                Write-Log -Message "Retrying to schedule test task without credentials" -Source "Main - TaskScheduling" -MessageType Info
                                $ScheduleTasksWithoutPassword = $true
                            } else {
                                break
                            }
                        } elseif ($SyncHash.cred.GetNetworkCredential().Password -eq "") {
                            Write-Log -Message "Empty password provided for user account '$($SyncHash.cred.UserName)'" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                            $Message = "Empty password provided`r`n`r`n"
                            $Message += "Attempt to register tasks without providing credentials?`r`n`r`n"
                            $Message += "Note: Tasks will not be able to restart if the machine reboots, the user logs off or the session locks"
                            $UserAnswer = New-Popup -Title "Task Scheduling Credentials Request" -Message $Message -Buttons "YesNo" -Icon Exclamation -DefaultButton "Second"
                            if ($UserAnswer -eq 6) {
                                Write-Log -Message "Retrying to schedule test task without credentials" -Source "Main - TaskScheduling" -MessageType Info
                                $ScheduleTasksWithoutPassword = $true
                            } else {
                                break
                            }
                        } elseif ($SyncHash.cred.UserName -ne $CurrentUser) {
                            Write-Log -Message "Credentials provided for user account '$($SyncHash.cred.UserName)' do not match the current user '$CurrentUser'" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                            New-Popup -Title "Task Scheduling Credentials Request" -Message "Invalid credentials - Use the current user only" -Buttons OK -Icon Exclamation
                        } else {
                            Write-Log -Message "Validating user account '$($SyncHash.cred.UserName)' credentials for task scheduling" -Source "Main - TaskScheduling" -MessageType Info -DisplayInGui
                            try {
                                Register-ScheduledTask -TaskName $TestTaskName -User $SyncHash.cred.UserName -Password $SyncHash.cred.GetNetworkCredential().Password -RunLevel $TasksRunLevel -Action (New-ScheduledTaskAction -Execute "PowerShell") -ErrorAction Stop | Out-Null
                                Start-Sleep -Seconds 1
                                if (Get-ScheduledTaskInfo -TaskName $TestTaskName -ErrorAction SilentlyContinue) {
                                    Write-Log -Message "Credentials provided are valid" -Source "Main - TaskScheduling" -MessageType Info
                                    $SyncHash.credValid = $true
                                    Write-Log -Message "Removing test task" -Source "Main - TaskScheduling" -MessageType Info
                                    Unregister-ScheduledTask -TaskName $TestTaskName -Confirm:$false
                                } else {
                                    Write-Log -Message "Unable to register test task (unknown error)" -Source "Main - TaskScheduling" -MessageType Error
                                    break
                                }
                            } catch {
                                if ($_.FullyQualifiedErrorId -match "0x8007052E") {
                                    Write-Log -Message "Credentials provided are invalid" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                                    $InvalidCredCount++
                                    if ($InvalidCredCount -gt 1) {
                                        Write-Log -Message "Prompting to retry without credentials after multiple ($InvalidCredCount) failures" -Source "Main - TaskScheduling" -MessageType Info
                                        $Message = "Invalid credentials provided`r`n`r`n"
                                        $Message += "Attempt to register tasks without providing credentials?`r`n`r`n"
                                        $Message += "Note: Tasks will not be able to restart if the machine reboots, the user logs off or the session locks"
                                        $UserAnswer = New-Popup -Title "Task Scheduling Credentials Request" -Message $Message -Buttons "YesNo" -Icon Exclamation -DefaultButton "Second"
                                        if ($UserAnswer -eq 6) {
                                            Write-Log -Message "Retrying to schedule test task without credentials" -Source "Main - TaskScheduling" -MessageType Info
                                            $ScheduleTasksWithoutPassword = $true
                                        } else {
                                            Write-Log -Message "Retrying to schedule test task with credentials" -Source "Main - TaskScheduling" -MessageType Info
                                        }
                                    } else {
                                        Write-Log -Message "Retrying to schedule test task with credentials" -Source "Main - TaskScheduling" -MessageType Info
                                        New-Popup -Title "Task Scheduling Credentials Request" -Message "Invalid credentials provided" -Buttons "Ok" -Icon Exclamation | Out-Null
                                    }
                                } else {
                                    Write-Log -Message "Unable to register test task: $($_.Exception.Message)" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                                    break
                                }
                            }
                        }
                    } catch {
                        Write-Log -Message "Failed to get credentials: $($_.Exception.Message)" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                        break
                    }
                }
            }

            if ($SyncHash.credValid) {
                $LocalCreds = $SyncHash.cred

                if ($DisableDomainCreds -or $ScheduleTasksWithoutPassword) {
                    if ($DisableDomainCreds) {
                        Write-Log -Message "Registering the tasks without user credentials due to policy (DisableDomainCreds)" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
                    } elseif ($ScheduleTasksWithoutPassword) {
                        Write-Log -Message "Registering the tasks without user credentials at user request" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
                    }
                    Write-Log -Message "Tasks will not be able to restart if the machine reboots, the user logs off or the session locks" -Source "Main - TaskScheduling" -MessageType Warning -DisplayInGui
                } else {
                    Write-Log -Message "Registering the tasks with user credentials" -Source "Main - TaskScheduling" -MessageType Info
                }

                if ($SkipTeamsNAT -eq $false) {
                    try {
                        Write-Log -Message "Creating scheduled task" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Info -DisplayInGui

                        $TaskName = "NPA - Teams"
                        Write-Log -Message "Removing any previously created scheduled task" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Info
                        if (Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false }

                        Write-Log -Message "Generating task parameters" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Info
                        $Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date -Second 0).AddMinutes(5) -RepetitionDuration (New-TimeSpan -Days 7) -RepetitionInterval (New-TimeSpan -Minutes 1)
                        $Settings = New-ScheduledTaskSettingsSet -Compatibility Win8 -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances Queue -ExecutionTimeLimit (New-TimeSpan -Hours 1)
                        $Script = "$env:NPAPath\Scripts\Worker-Teams-TestCall.ps1"
                        $Action = New-ScheduledTaskAction -Execute powershell -Argument "-NoProfile -NoLogo -WindowStyle Normal -ExecutionPolicy Bypass -File `"$Script`""

                        Write-Log -Message "Registering the task" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Info
                        if ($DisableDomainCreds -or $ScheduleTasksWithoutPassword) {
                            Register-ScheduledTask -TaskName $TaskName -Trigger $Trigger -Settings $Settings -User $localCreds.UserName -RunLevel $TasksRunLevel -Action $Action -ErrorAction Stop
                        } else {
                            Register-ScheduledTask -TaskName $TaskName -Trigger $Trigger -Settings $Settings -User $localCreds.UserName -Password $localCreds.GetNetworkCredential().Password -RunLevel $TasksRunLevel -Action $Action -ErrorAction Stop
                        }
                        Start-Sleep -Seconds 1

                        if (Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue) {
                            Write-Log -Message "Task scheduling completed without error" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Info -DisplayInGui
                        } else {
                            Write-Log -Message "Task wasn't registered properly" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Error -DisplayInGui
                        }
                    } catch {
                        Write-Log -Message "Task scheduling failed: $($_.Exception.Message)" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Error -DisplayInGui
                    }
                } else {
                    Write-Log -Message "Skipping task scheduling" -Source "Main - TaskScheduling - 1 Minute Task" -MessageType Info -DisplayInGui
                }

                try {
                    Write-Log -Message "Creating scheduled task" -Source "Main - TaskScheduling - 15 Minutes Task" -MessageType Info -DisplayInGui

                    $Taskname = "NPA - Trace"
                    Write-Log -Message "Removing any previously created scheduled task" -Source "Main - TaskScheduling - 15 Minutes Task" -MessageType Info
                    if (Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false }

                    Write-Log -Message "Generating task parameters" -Source "Main - TaskScheduling - 15 Minutes Task" -MessageType Info
                    $Trigger = New-ScheduledTaskTrigger -Once -At (Get-Date -Second 0).AddMinutes(10) -RepetitionDuration (New-TimeSpan -Days 7) -RepetitionInterval (New-TimeSpan -Minutes 15)
                    $Settings = New-ScheduledTaskSettingsSet -Compatibility Win8 -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances Parallel -ExecutionTimeLimit (New-TimeSpan -Hours 1)
                    $Script = "$env:NPAPath\Scripts\Worker-Trace-Master.ps1"
                    $Action = New-ScheduledTaskAction -Execute powershell -Argument "-NoProfile -NoLogo -WindowStyle Normal -ExecutionPolicy Bypass -File `"$Script`""

                    Write-Log -Message "Registering the task" -Source "Main - TaskScheduling - 15 Minutes Task" -MessageType Info
                    if ($DisableDomainCreds -or $ScheduleTasksWithoutPassword) {
                        Register-ScheduledTask -TaskName $TaskName -Trigger $Trigger -Settings $Settings -User $localCreds.UserName -RunLevel $TasksRunLevel -Action $Action -ErrorAction Stop
                    } else {
                        Register-ScheduledTask -TaskName $TaskName -Trigger $Trigger -Settings $Settings -User $localCreds.UserName -Password $localCreds.GetNetworkCredential().Password -RunLevel $TasksRunLevel -Action $Action -ErrorAction Stop
                    }
                    Start-Sleep -Seconds 1

                    if (Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue) {
                        Write-Log -Message "Task scheduling completed without error" -Source "Main - TaskScheduling - 15 Minutes Task" -MessageType Info -DisplayInGui
                    } else {
                        Write-Log -Message "Task wasn't registered properly" -Source "Main - TaskScheduling - 15 Minutes Task" -MessageType Error -DisplayInGui
                    }
                } catch {
                    Write-Log -Message "Task scheduling failed: $($_.Exception.Message)" -Source "Main - TaskScheduling - 15 Minutes Task" -MessageType Error -DisplayInGui
                }
            } else {
                Write-Log -Message "Unable to schedule tasks without valid credentials" -Source "Main - TaskScheduling" -MessageType Error -DisplayInGui
                New-Popup -Title "Task scheduling failed" -Message "Unable to schedule tasks without valid credentials" -Buttons OK -Icon Stop | Out-Null
            }

            Get-TaskStatus

            Write-Log -Message "Task scheduling completed" -Source "Main - TaskScheduling" -MessageType Info -DisplayInGui

        } elseif ($Workload -eq "IPConfig") {

            $CurrentTaskState = ($SyncHash.TestsStates | Where-Object {$_.TestName -eq $Workload})
            $CurrentTaskState.State = "Collecting"

            Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null

            Write-Log -Message "Starting IPConfig collection" -Source "IPConfig" -MessageType Info -DisplayInGui
            Get-IPConfig

            Write-Log -Message "Tests completed" -Source "IPConfig" -MessageType Info -DisplayInGui
            Update-Control -SyncHash $SyncHash -Control ProgressBar -Property value -Value 1 -Add

            Test-OutputFile -Workload $Workload
            $CurrentTaskState.State = "Finished"

            New-Balloontip -Title "Network Performance Assessment" -message "IPConfig - Tests completed"

        } else {

            $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
            $DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
            $WindowStyle = if ($DebugMode) { "Normal" } else { "Hidden" }
            
            $CurrentTaskState = ($SyncHash.TestsStates | Where-Object {$_.TestName -eq $Workload})
            
            if ($Workload -in "DNSLookup","EXO","Teams","SPO","Viva","Copilot","MicrosoftDomain","FileTransfer") {
                $Lockfile = "$env:NPAPath\lock.lck"
                Write-Log -Message "Queuing task" -Source "Main - $Workload" -MessageType Info

                $CurrentTaskState.State = "Waiting"
                While ($SyncHash.TestsStates | Where-Object {$_.NetworkTrace -eq $true -and $_.Priority -lt $CurrentTaskState.Priority -and $_.State -notmatch "Idle|Finished"}) {
                    Start-Sleep -Seconds 2
                }
                
                # Cancel task if a manual stop has been requested
                if ($SyncHash.CollectionInProgress -eq $false) {
                    Write-Log -Message "Aborting $ActivityName test after manual stop request" -Source "Main - $Workload" -MessageType Info
                    $CurrentTaskState.State = "Idle"
                    exit
                }
            }

            $CurrentTaskState.State = "Collecting"

            try {
                $Global:ErrorActionPreference = 'stop'
                
                Write-Log -Message "Starting $ActivityName test" -Source "Main - $Workload" -MessageType Info -DisplayInGui
                
                #Start script
                $Command = "& `'$env:NPAPath\Scripts\$ScriptName`'"
                Write-Log -Message "Executing command: $Command" -Source "Main - $Workload" -MessageType Info
                $CurrentTaskProcess = Start-Process powershell -ArgumentList $Command -WindowStyle $WindowStyle -PassThru
                $CurrentTaskState.PID = $CurrentTaskProcess.Id
        
                # waiting to make sure the file gets locked
                Start-Sleep -second 5
        
            }
            catch {
                Write-Log -Message "Error performing $ActivityName test: $($_.Exception.Message)" -Source "Main - $Workload" -MessageType Error -DisplayInGui
            }
            Finally {
                $Global:ErrorActionPreference = 'continue'
            }
            
            if ($Workload -in "DNSLookup","EXO","Teams","SPO","Viva","Copilot","MicrosoftDomain","FileTransfer") {
                # Wait if another test is running
                $count = 0
                $CurrentProcessTerminated = $false
                # While ((Test-Path $Lockfile) -eq $true -or $CurrentTaskProcess.HasExited -ne $true) {
                While ($CurrentTaskProcess.HasExited -ne $true) {
                    # Only log a message every 30sec to prevent spam
                    if ($count % 30 -eq 0 -and $count -ne 0) {
                        $LockingTask = Get-Content -Path $Lockfile -ErrorAction SilentlyContinue
                        if ($LockingTask -eq $Workload) {
                            Write-Log -Message "$ActivityName test is still running. Sleeping..." -Source "Main - $Workload" -MessageType Info
                        } else {
                            Write-Log -Message "Another test is still running ($LockingTask). Sleeping..." -Source "Main - $Workload" -MessageType Info
                        }
                    }
                    $count += 1
                    Start-Sleep -Seconds 1
                    if ($CurrentProcessTerminated -eq $false -and $CurrentTaskProcess.HasExited -eq $true -and $SyncHash.CollectionInProgress -eq $true) {
                        Update-Control -SyncHash $SyncHash -Control ProgressBar -Property value -Value 1 -Add
                        $CurrentProcessTerminated = $true
                        $LockingTask = Get-Content -Path $Lockfile -ErrorAction SilentlyContinue
                        if ($LockingTask -eq $Workload) {
                            Write-Log -Message "Forcefully removing stale lockfile (test ended but lock file is still present)" -Source "Main - $Workload" -MessageType Warning
                            try {
                                Remove-Item -Path $Lockfile -Force | Out-Null
                            } catch {
                                Write-Log -Message "Failed to remove lockfile" -Source "$Workload" -MessageType Error
                            }
                        }
                    }
                }
            } else {
                # Wait for the task to finish
                $count = 0
                $CurrentProcessTerminated = $false
                While ($CurrentTaskProcess.HasExited -ne $true) {
                    # Only log a message every 30sec to prevent spam
                    if ($count % 30 -eq 0 -and $count -ne 0) {
                        Write-Log -Message "$ActivityName test is still running. Sleeping..." -Source "Main - $Workload" -MessageType Info
                    }
                    $count += 1
                    Start-Sleep -Seconds 1
                    if ($CurrentProcessTerminated -eq $false -and $CurrentTaskProcess.HasExited -eq $true -and $SyncHash.CollectionInProgress -eq $true) {
                        Update-Control -SyncHash $SyncHash -Control ProgressBar -Property value -Value 1 -Add
                        $CurrentProcessTerminated = $true
                    }
                }
            }

            # Only display successful end if the task ended by itself (not manually stopped)
            if ($SyncHash.CollectionInProgress -eq $true) {
                if ($CurrentProcessTerminated -eq $false -and $CurrentTaskProcess.HasExited -eq $true) {
                    Update-Control -SyncHash $SyncHash -Control ProgressBar -Property value -Value 1 -Add
                    $CurrentProcessTerminated = $true
                }
                Write-Log -Message "$ActivityName test completed" -Source "Main - $Workload" -MessageType Info -DisplayInGui
            } else {
                Write-Log -Message "Task was killed after manual stop request" -Source "Main - $Workload" -MessageType Info
                $CurrentTaskState.State = "Idle"
                exit
            }
            
            Test-OutputFile -Workload $Workload
            
            $CurrentTaskState.State = "Finished"
            $CurrentTaskState.PID = $null

            New-Balloontip -Title "Network Performance Assessment" -message "$ActivityName - Test completed"
            
        }

        Copy-RunlogAndSettingsToOutputFolder
    })

    $powershell_CurrentTask.Runspace = $newRunspace
    $powershell_CurrentTask.BeginInvoke() | Out-Null
    # $RunspaceList += $powershell_CurrentTask

    # Cleanup runspaces whenever the threads close
    $null = Register-ObjectEvent -InputObject $powershell_CurrentTask -EventName InvocationStateChanged -Action {
        param([System.Management.Automation.PowerShell] $ps)
        # NOTE: Use $EventArgs.InvocationStateInfo, not $ps.InvocationStateInfo,
        #       as the latter is updated in real-time, so for a short-running script
        #       the state may already have changed since the event fired.
        $state = $EventArgs.InvocationStateInfo.State
        if ($state -in 'Completed', 'Failed') {
            $ps.Runspace.Close()
            $ps.Runspace.Dispose()
            # Speed up resource release by calling the garbage collector explicitly.
            # Note that this will pause *all* threads briefly.
            [GC]::Collect()
        }

    }

}

function Get-TaskStatus {
    # Check if the tasks have previously been scheduled or not
    Write-Log -Message "Checking scheduled tasks status" -Source "Main - TasksCheck" -MessageType Info
    $TasksScheduled = @()
    $NPATasks = Get-ScheduledTask | Where-Object {$_.TaskName -match "NPA -"}
    $1MinuteTaskStatus = ($NPATasks | Where-Object {$_.TaskName -match "NPA - Teams"}).State
    if ($null -ne $1MinuteTaskStatus) {
        $TasksScheduled += "NPA - Teams"
        if ($1MinuteTaskStatus -ne "Disabled") {
            Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property Content -Value "Scheduled"
            Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property foreground -Value "DarkGreen"
            Write-Log -Message "1 Minute Task: Scheduled" -Source "Main - TasksCheck" -MessageType Info
        } elseif ($1MinuteTaskStatus -eq "Disabled") {
            Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property Content -Value "Scheduled and disabled"
            Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property foreground -Value "DarkOrange"
            Write-Log -Message "1 Minute Task: Scheduled and disabled" -Source "Main - TasksCheck" -MessageType Warning
        } else {
            Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property Content -Value "Unknown state"
            Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property foreground -Value "Red"
            Write-Log -Message "1 Minute Task: Unknown state" -Source "Main - TasksCheck" -MessageType Warning
        }
    } else {
        Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property Content -Value "Not scheduled"
        Update-Control -SyncHash $SyncHash -Control lbl_1MinuteTaskStatus -Property foreground -Value "Red"
        Write-Log -Message "1 Minute Task: Not scheduled" -Source "Main - TasksCheck" -MessageType Info
    }
    $15MinutesTaskStatus = ($NPATasks | Where-Object {$_.TaskName -match "NPA - Trace"}).State
    if ($null -ne $15MinutesTaskStatus) {
        $TasksScheduled += "NPA - Trace"
        if ($15MinutesTaskStatus -ne "Disabled") {
            Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property Content -Value "Scheduled"
            Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property foreground -Value "DarkGreen"
            Write-Log -Message "15 Minutes Task: Scheduled" -Source "Main - TasksCheck" -MessageType Info
        } elseif ($15MinutesTaskStatus -eq "Disabled") {
            Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property Content -Value "Scheduled and disabled"
            Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property foreground -Value "DarkOrange"
            Write-Log -Message "15 Minutes Task: Scheduled and disabled" -Source "Main - TasksCheck" -MessageType Warning
        } else {
            Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property Content -Value "Unknown state"
            Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property foreground -Value "Red"
            Write-Log -Message "15 Minutes Task: Unknown state" -Source "Main - TasksCheck" -MessageType Warning
        }
    } else {
        Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property Content -Value "Not scheduled"
        Update-Control -SyncHash $SyncHash -Control lbl_15MinutesTaskStatus -Property foreground -Value "Red"
        Write-Log -Message "15 Minutes Task: Not scheduled" -Source "Main - TasksCheck" -MessageType Info
    }
    
    switch ($TasksScheduled.count) {
        0 {
            Write-Log -Message "No task is scheduled, enabling the 'Schedule' button and disabling the 'Unschedule' button" -Source "Main - TasksCheck" -MessageType Info
            Update-Control -SyncHash $SyncHash -Control btn_Schedule_7Day_Collection -Property IsEnabled -Value $true
            Update-Control -SyncHash $SyncHash -Control btn_Unschedule_7Day_Collection -Property IsEnabled -Value $false
        }
        1 {
            Write-Log -Message "One task is scheduled, enabling the 'Schedule' and 'Unschedule' buttons" -Source "Main - TasksCheck" -MessageType Info
            Update-Control -SyncHash $SyncHash -Control btn_Schedule_7Day_Collection -Property IsEnabled -Value $true
            Update-Control -SyncHash $SyncHash -Control btn_Unschedule_7Day_Collection -Property IsEnabled -Value $true
        }
        2 {
            Write-Log -Message "All tasks are scheduled, disabling the 'Schedule' button and enabling the 'Unschedule' button" -Source "Main - TasksCheck" -MessageType Info
            Update-Control -SyncHash $SyncHash -Control btn_Schedule_7Day_Collection -Property IsEnabled -Value $false
            Update-Control -SyncHash $SyncHash -Control btn_Unschedule_7Day_Collection -Property IsEnabled -Value $true
        }
    }
}

function Set-ProxyCredentials {
    param (
        [System.Management.Automation.PSCredential]$ProxyCredentials
    )

    $ProxyCredentialsPath = "$env:NPAPath\ProxyCredentials.xml"
    Write-Log -Message "Securely storing proxy credentials for account '$($ProxyCredentials.UserName)' to '$ProxyCredentialsPath'" -Source "Init" -MessageType Info
    $ProxyCredentials | Export-CliXml -Path $ProxyCredentialsPath
}

function Get-ProxyCredentials {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $ProxyCredentialsPath = "$env:NPAPath\ProxyCredentials.xml"
    if (Test-Path $ProxyCredentialsPath) {
        $ProxyCredentials = Import-Clixml -Path $ProxyCredentialsPath
        # Configuring proxy credentials with the provided account
        [system.net.webrequest]::defaultwebproxy.Credentials = $ProxyCredentials
    } else {
        # No proxy credentials have been provided, using current user's credentials if necessary
        [system.net.webrequest]::defaultwebproxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
    }
}

function Get-ProxyConfiguration {
    Param (
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $LogType
    )
    
    Write-Log -Message "Detecting current proxy configuration" -Source "$LogType" -MessageType Info

    # https://learn.microsoft.com/en-us/archive/blogs/askie/what-is-defaultconnectionsettings-key
    # https://www.spad.uk/posts/how-does-proxysettingsperuser-work/
    
    $DefaultConnectionSettingsBytes = (Get-ItemProperty -Path 'registry::HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections\' -Name DefaultConnectionSettings -ErrorAction SilentlyContinue).DefaultConnectionSettings

    if ($DefaultConnectionSettingsBytes -notlike "") {
        $ProxyOptions = $DefaultConnectionSettingsBytes[8]

        switch ($ProxyOptions) {
            1 {
                $ProxyDetectionEnabled = $false
                $ProxyAutoConfigEnabled = $false
                $ProxyEnabled = $false
            }
            3 {
                $ProxyDetectionEnabled = $false
                $ProxyAutoConfigEnabled = $false
                $ProxyEnabled = $true
            }
            5 {
                $ProxyDetectionEnabled = $false
                $ProxyAutoConfigEnabled = $true
                $ProxyEnabled = $false
            }
            7 {
                $ProxyDetectionEnabled = $false
                $ProxyAutoConfigEnabled = $true
                $ProxyEnabled = $true
            }
            9 {
                $ProxyDetectionEnabled = $true
                $ProxyAutoConfigEnabled = $false
                $ProxyEnabled = $false
            }
            11 {
                $ProxyDetectionEnabled = $true
                $ProxyAutoConfigEnabled = $false
                $ProxyEnabled = $true
            }
            13 {
                $ProxyDetectionEnabled = $true
                $ProxyAutoConfigEnabled = $true
                $ProxyEnabled = $false
            }
            15 {
                $ProxyDetectionEnabled = $true
                $ProxyAutoConfigEnabled = $true
                $ProxyEnabled = $true
            }
        }

        $ProxyServerStartingPosition = 12
        $ProxyServerByteLength = $DefaultConnectionSettingsBytes[$ProxyServerStartingPosition]
        if ($ProxyServerByteLength -gt 0) {
            $ProxyServer = [System.Text.Encoding]::UTF8.GetString($DefaultConnectionSettingsBytes[($ProxyServerStartingPosition+3+1)..($ProxyServerStartingPosition+3+$ProxyServerByteLength)])
        } else {
            $ProxyServer = $null
        }

        $ProxyExemptionStartingPosition = $ProxyServerStartingPosition+3+$ProxyServerByteLength+1
        $ProxyExemptionByteLength = $DefaultConnectionSettingsBytes[($ProxyExemptionStartingPosition)]
        if ($ProxyExemptionByteLength -gt 0) {
            $ProxyExemption = [System.Text.Encoding]::UTF8.GetString($DefaultConnectionSettingsBytes[($ProxyExemptionStartingPosition+3+1)..($ProxyExemptionStartingPosition+3+$ProxyExemptionByteLength)])
        } else {
            $ProxyExemption = $null
        }

        $ProxyAutoConfigURLStartingPosition = $ProxyExemptionStartingPosition+3+$ProxyExemptionByteLength+1
        $ProxyAutoConfigURLByteLength = $DefaultConnectionSettingsBytes[($ProxyAutoConfigURLStartingPosition)]
        if ($ProxyAutoConfigURLByteLength -gt 0) {
            $ProxyAutoConfigURL = [System.Text.Encoding]::UTF8.GetString($DefaultConnectionSettingsBytes[($ProxyAutoConfigURLStartingPosition+3+1)..($ProxyAutoConfigURLStartingPosition+3+$ProxyAutoConfigURLByteLength)])
        } else {
            $ProxyAutoConfigURL = $null
        }

        $ProxyConfiguration = $null
        if ($ProxyAutoConfigEnabled -eq $true) {
            Write-Log -Message "Found proxy auto configuration (PAC file): '$ProxyAutoConfigURL'" -Source "$LogType" -MessageType Info
            $ProxyConfiguration = "PAC=$ProxyAutoConfigURL"
        }
        if ($ProxyEnabled -eq $true -and $ProxyServer -notlike "") {
            Write-Log -Message "Found static proxy configuration: '$ProxyServer'" -Source "$LogType" -MessageType Info
            if ($ProxyServer -match "https=") {
                $ProxyServer = $ProxyServer -replace '.*(https=([\d,\.,\:]*)).*','$2'
            }
            $ProxyConfiguration = if ($ProxyConfiguration -notlike "") { "$ProxyConfiguration;Static=$ProxyServer" } else { "Static=$ProxyServer" }
        }
        if ($ProxyExemption -notlike "") {
            Write-Log -Message "Found static proxy exemptions: '$ProxyExemption'" -Source "$LogType" -MessageType Info
        }
        if ($ProxyDetectionEnabled -eq $true) {
            Write-Log -Message "Automatic proxy detection is enabled" -Source "$LogType" -MessageType Info
        }
        if ($ProxyAutoConfigEnabled -eq $false -and $ProxyEnabled -eq $false) {
            Write-Log -Message "No explicit proxy configuration found" -Source "$LogType" -MessageType Info
            $ProxyConfiguration = "Direct"
        }
    } else {
        Write-Log -Message "Can't find proxy configuration, proxy was probably never set for the current user ($([System.Security.Principal.WindowsIdentity]::GetCurrent().Name))" -Source "$LogType" -MessageType Warning
        $ProxyConfiguration = "Direct"
    }

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    if ($CurrentSettings.ProxyConfiguration -ne $ProxyConfiguration) {
        Write-Log -Message "Updating stored proxy configuration in settings file" -Source "$LogType" -MessageType Info
        $CurrentSettings.ProxyConfiguration = $ProxyConfiguration
        $CurrentSettings | ConvertTo-Json | Out-File -FilePath $env:NPAPath\Settings.json -Encoding UTF8 -Force
    }
}

function Set-ProxyConfiguration {
    Write-Log -Message "Entering proxy configuration wizard as per user request" -Source "Init" -MessageType Info
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    if ($CurrentSettings.ProxyConfiguration -eq "Direct") {
        Write-Log -Message "No proxy is currently configured" -Source "Init" -MessageType Info
        $Message = "No proxy is currently configured for the current user.`r`n`r`n"
    } else {
        Write-Log -Message "Proxy has already been set: '$($CurrentSettings.ProxyConfiguration)'" -Source "Init" -MessageType Warning
        $Message = "The following proxy configuration has been detected:`r`n`r`n"
        $Message += "$($CurrentSettings.ProxyConfiguration)`r`n`r`n"
    }
    $Message += "Manually setting a proxy will override the current configuration on the device.`r`n`r`n"
    $Message += "Ensure that there is no policy enforcing proxy settings.`r`n`r`n"
    $Message += "Do you confirm that you want to manually set proxy settings?`r`n"
    $UserAnswer = New-Popup -Title "Proxy configuration override" -Message $Message -Buttons "YesNo" -Icon Exclamation

    if ($UserAnswer -eq 6) {
        try {
            Write-Log -Message "User confirmed the manual proxy override request" -Source "Init" -MessageType Info
            $PACFilePath = $null
            $ProxyAddress = $null
            $ProxyExclusions = $null

            Write-Log -Message "Prompting user for the proxy settings to configure" -Source "Init" -MessageType Info
            $ProxyConfigurationType = $null
            while ($ProxyConfigurationType -notin 1,2,3) {
                $ProxyConfigurationType = Read-Host "Set proxy configuration via PAC file [1], static proxy [2], or clear proxy configuration [3] - Type '1', '2' or '3'"
                if ($ProxyConfigurationType -notin 1,2,3) {
                    Write-Log -Message "Invalid proxy configuration selection: $ProxyConfigurationType" -Source "Init" -MessageType Warning
                    Write-Host "Invalid proxy configuration selection" -ForegroundColor Red
                }
            }

            if ($ProxyConfigurationType -eq 1) {
                Write-Log -Message "Configuring proxy via PAC file" -Source "Init" -MessageType Info
                while ($null -eq $PACFilePath) {
                    while ($PACFilePath -notmatch "https?://.*") {
                        $PACFilePath = Read-Host "Enter PAC file path (example: http://proxyfqdn:8080/proxy.pac)"
                        if ($PACFilePath -notmatch "https?://.*") {
                            Write-Log -Message "Invalid PAC file path: $PACFilePath" -Source "Init" -MessageType Warning
                            Write-Host "Invalid PAC file path (expecting http/https path)" -ForegroundColor Red
                        }
                    }
                    Write-Log -Message "Provided PAC file path: '$PACFilePath'" -Source "Init" -MessageType Info
                    $Message = "Do you confirm that the following PAC file path is correct?`r`n`r`n"
                    $Message += "$PACFilePath`r`n"
                    $UserAnswer = New-Popup -Title "PAC file path confirmation" -Message $Message -Buttons "YesNo" -Icon Exclamation
                    if ($UserAnswer -eq 6) {
                        Write-Log -Message "User confirmed provided PAC file path" -Source "Init" -MessageType Info
                    } else {
                        Write-Log -Message "User cancelled provided PAC file path, prompting again" -Source "Init" -MessageType Warning
                        $PACFilePath = $null
                    }
                }
                Write-Log -Message "Setting 'AutoConfigURL' registry key to '$PACFilePath'" -Source "Init" -MessageType Info
                Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "AutoConfigURL" -Value $PACFilePath
                Write-Log -Message "Removing registry key 'ProxyEnable'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyEnable" -ErrorAction SilentlyContinue
                Write-Log -Message "Removing registry key 'ProxyServer'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyServer" -ErrorAction SilentlyContinue
                Write-Log -Message "Removing registry key 'ProxyOverride'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyOverride" -ErrorAction SilentlyContinue
                $ProxyAddress = ""
                $ProxyExclusions = ""
                # Value for PAC enabled + proxy disabled
                $ProxyOptions = "13"
            } elseif ($ProxyConfigurationType -eq 2) {
                Write-Log -Message "Configuring a static proxy" -Source "Init" -MessageType Info
                # regex to match IP:port
                $RegexIP = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(:\d{1,5})$"
                # regex to match FQDN:port
                $RegexFQDN = "^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])(\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]{0,61}[a-zA-Z0-9]))*(:\d{1,5})$"
                while ($null -eq $ProxyAddress) {
                    while ($ProxyAddress -notmatch $RegexIP -and $ProxyAddress -notmatch $RegexFQDN) {
                        $ProxyAddress = Read-Host "Enter proxy (examples: 192.168.1.200:8080 / myproxy.domain.lan:8080)"
                        if ($ProxyAddress -notmatch $RegexIP -and $ProxyAddress -notmatch $RegexFQDN) {
                            Write-Log -Message "Invalid proxy: $ProxyAddress" -Source "Init" -MessageType Warning
                            Write-Host "Invalid proxy (expecting IP/FQDN and port)" -ForegroundColor Red
                        }
                    }
                    Write-Log -Message "Provided proxy: '$ProxyAddress'" -Source "Init" -MessageType Info
                    $Message = "Do you confirm that the following proxy is correct?`r`n`r`n"
                    $Message += "$ProxyAddress`r`n"
                    $UserAnswer = New-Popup -Title "Proxy confirmation" -Message $Message -Buttons "YesNo" -Icon Exclamation
                    if ($UserAnswer -eq 6) {
                        Write-Log -Message "User confirmed provided proxy" -Source "Init" -MessageType Info
                    } else {
                        Write-Log -Message "User cancelled provided proxy, prompting again" -Source "Init" -MessageType Warning
                        $ProxyAddress = $null
                    }
                }
                Write-Log -Message "Setting 'ProxyEnable' registry key to '1'" -Source "Init" -MessageType Info
                Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyEnable" -Value 1
                Write-Log -Message "Setting 'ProxyServer' registry key to '$ProxyAddress'" -Source "Init" -MessageType Info
                Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyServer" -Value $ProxyAddress
                Write-Log -Message "Removing registry key 'AutoConfigURL'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "AutoConfigURL" -ErrorAction SilentlyContinue

                while ($null -eq $ProxyExclusions) {
                    $ProxyExclusions = Read-Host "Enter proxy exclusions (example: <local>;domain.lan;domain.com) or leave blank"
                    if ($ProxyExclusions -like "") {
                        Write-Log -Message "No proxy exclusion set" -Source "Init" -MessageType Warning
                        $Message = "Do you confirm that there are no poxy exclusions?`r`n"
                    } else {
                        Write-Log -Message "Proxy exclusion list: $ProxyExclusions" -Source "Init" -MessageType Warning
                        $Message = "Do you confirm that the following proxy exclusions are correct?`r`n`r`n"
                        $Message += "$ProxyExclusions`r`n"
                    }
                    $UserAnswer = New-Popup -Title "Proxy exclusion confirmation" -Message $Message -Buttons "YesNo" -Icon Exclamation
                    if ($UserAnswer -eq 6) {
                        Write-Log -Message "User confirmed provided proxy exclusions" -Source "Init" -MessageType Info
                    } else {
                        Write-Log -Message "User cancelled provided proxy exclusions, prompting again" -Source "Init" -MessageType Warning
                        $ProxyExclusions = $null
                    }
                }
                Write-Log -Message "Setting 'ProxyOverride' registry key to '$ProxyExclusions'" -Source "Init" -MessageType Info
                Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyOverride" -Value $ProxyExclusions

                $PACFilePath = ""
                # Value for proxy enabled + PAC disabled
                $ProxyOptions = "03"
            } else {
                Write-Log -Message "Clearing proxy configuration" -Source "Init" -MessageType Info
                if ($CurrentSettings.ProxyConfiguration -eq "Direct") {
                    Write-Log -Message "There is already no proxy configured, no action to take" -Source "Init" -MessageType Info
                    Write-Host "Proxy configuration cancelled (already no proxy configured)" -ForegroundColor Red
                    return
                }
                $Message = "Do you confirm that you want to clear the proxy configuration?`r`n"
                $UserAnswer = New-Popup -Title "Clearing proxy confirmation" -Message $Message -Buttons "YesNo" -Icon Exclamation
                if ($UserAnswer -eq 6) {
                    Write-Log -Message "User confirmed clearing of proxy" -Source "Init" -MessageType Info
                } else {
                    Write-Log -Message "User cancelled clearing of proxy, no action to take" -Source "Init" -MessageType Warning
                    Write-Host "Proxy configuration cancelled (user choice)" -ForegroundColor Red
                    return
                }
                Write-Log -Message "Removing registry key 'AutoConfigURL'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "AutoConfigURL" -ErrorAction SilentlyContinue
                Write-Log -Message "Removing registry key 'ProxyEnable'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyEnable" -ErrorAction SilentlyContinue
                Write-Log -Message "Removing registry key 'ProxyServer'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyServer" -ErrorAction SilentlyContinue
                Write-Log -Message "Removing registry key 'ProxyOverride'" -Source "Init" -MessageType Info
                Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" -Name "ProxyOverride" -ErrorAction SilentlyContinue
                $PACFilePath = ""
                $ProxyAddress = ""
                $ProxyExclusions = ""
                # Value for PAC disabled + proxy disabled
                $ProxyOptions = "1"
            }

            # https://www.spad.uk/posts/how-does-proxysettingsperuser-work/
            Write-Log -Message "Setting proper values in the registry key 'DefaultConnectionSettings'" -Source "Init" -MessageType Info
            $PacBytes = [system.Text.Encoding]::ASCII.GetBytes($PACFilePath)
            $ProxyBytes = [system.Text.Encoding]::ASCII.GetBytes($ProxyAddress)
            $BypassBytes = [system.Text.Encoding]::ASCII.GetBytes($ProxyExclusions)
            $DefaultConnectionSettings = [byte[]]@(@(70, 0, 0, 0) + @("02", 0, 0, 0) + @($ProxyOptions, 0, 0, 0) + @($ProxyBytes.Length, 0, 0, 0) + $ProxyBytes + @($BypassBytes.Length, 0, 0, 0) + $BypassBytes + @($PacBytes.Length, 0, 0, 0) + $PacBytes + @(1..32 | ForEach-Object { 0 }))
            Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections" -Name "DefaultConnectionSettings" -Value $DefaultConnectionSettings

            Get-ProxyConfiguration -LogType "Init"

        } catch {
            Write-Log -Message "Error while setting proxy configuration: $($_.Exception.Message)" -Source "Init" -MessageType Error
        }
    } else {
        Write-Log -Message "User cancelled the manual proxy override request" -Source "Init" -MessageType Info
    }
}

function Test-Proxy {
    param (
        [String]$Uri
    )

    Write-Log -Message "Checking for proxy authentication with '$Uri'" -Source "Init" -MessageType Info
    $ConnectionSuccess = $false
    while ($ConnectionSuccess -ne $true) {
        try {
            Get-ProxyCredentials
            Invoke-WebRequest -Uri $Uri -UserAgent (Get-UserAgent) -UseBasicParsing | Out-Null
            Write-Log -Message "No issue with proxy authentication" -Source "Init" -MessageType Info
            $ConnectionSuccess = $true
        } catch {
            if ($_.Exception.Response.StatusCode -eq "ProxyAuthenticationRequired") {
                $ProxyCredentialsPath = "$env:NPAPath\ProxyCredentials.xml"
                if (Test-Path $ProxyCredentialsPath) {
                    $ProxyCredentials = Import-Clixml -Path $ProxyCredentialsPath
                    Write-Log -Message "Proxy credentials provided for user account '$($ProxyCredentials.UserName)' have been rejected by proxy" -Source "Init" -MessageType Warning
                } else {
                    Write-Log -Message "Proxy requires authentication" -Source "Init" -MessageType Warning
                }
                Write-Log -Message "Requesting new proxy credentials" -Source "Init" -MessageType Info
                Set-ProxyCredentials (Get-Credential -Message "Please type the credentials to use for proxy authentication")
            } else {
                Write-Log -Message "Connection failed but not due to proxy authentication: $($_.Exception.Message)" -Source "Init" -MessageType Error
                break
            }
        }
    }
    return $ConnectionSuccess
}

function Get-UserAgent {
    $EdgeVersion = (Get-Item "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" -ErrorAction SilentlyContinue).VersionInfo.ProductVersion -replace '^(\d+)\..*','$1.0.0.0'
    if ($EdgeVersion -notmatch '\d+\.0\.0\.0') {
        # Using version 134.0.0.0 (current as of 2025-02) if no proper match is made
        $EdgeVersion = "134.0.0.0"
    }
    $UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/$EdgeVersion Safari/537.36 Edg/$EdgeVersion"

    return $UserAgent
}

function Get-FrontDoorFromHTTPResponse {
    param (
        $HTTPResponse
    )

    $FrontDoor = $HTTPResponse.Headers.'X-Endpoint'
    if ($FrontDoor -match "_Content" -or $FrontDoor -like "") {
        if ($HTTPResponse.Headers.'X-MSEdge-Ref' -match "Ref B:") {
            $FrontDoor = $HTTPResponse.Headers.'X-MSEdge-Ref' -replace '.*Ref B: (.*?) Ref.*','$1'
            if ($FrontDoor -match "^(.*?)-.{4}-.{9}-.{5}$") {
                $FrontDoor = $FrontDoor -replace "^(.*?)-.{4}-.{9}-.{5}$",'$1'
            } elseif ($FrontDoor -match "^(.{2,6}(R\d([a-z])\d?)).*") {
                $FrontDoor = $FrontDoor -replace "^(.{2,6}(R\d([a-z])\d?)).*",'$1'
            } elseif ($FrontDoor -match "^\d{8}T\d{6}z-.*?S1(.{2,6}?R).*") {
                $FrontDoor = $FrontDoor -replace "^\d{8}T\d{6}z-.*?S1(.{2,6}?R).*",'$1'
            }
        } elseif ($HTTPResponse.Headers.'X-MS-Edge-Ref' -match "MIRA:") {
            $FrontDoor = $HTTPResponse.Headers.'X-MSEdge-Ref' -replace 'MIRA: .*? (.*?) .*','$1'
        }
    }
    if ($FrontDoor -like "") {
        $FrontDoor = $HTTPResponse.Headers.'x-ms-ests-server' -replace '.*- (.*?) .*','$1'
    }
    if ($FrontDoor -like "") {
        $FrontDoor = $HTTPResponse.Headers.'X-FirstHopCafeEFZ'
    }
    if ($FrontDoor -like "") {
        $FrontDoor = $HTTPResponse.Headers.'X-FEEFZInfo'
    }
    if ($FrontDoor -like "") {
        $FrontDoor = $HTTPResponse.Headers.'X-FEProxyInfo'
    }
    if ($FrontDoor -like "") {
        $FrontDoor = $HTTPResponse.Headers.'X-BEPartition'
    }
    if ($FrontDoor -like "") {
        $FrontDoor = $HTTPResponse.Headers.'X-CalculatedBETarget' -replace '.SUBSTRATE.COSMIC.OFFICE.NET',''
    }
    return $FrontDoor
}

function Get-IPConfig {
    # Fetching settings
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $OutputPath = $CurrentSettings.OutputPath

    Write-Log -Message "Starting to gather IPConfig information" -Source "IPConfig" -MessageType Info

    $TestStartTime = Get-Date
    $ErrorDetails = @()

    $Timestamp = Get-DateInFile
    $IPConfigFileOutput = Join-Path -Path $OutputPath -ChildPath "IPCONFIG_$(Get-DateInFileName).log"

    # Checking paths
    if ((Test-Path $IPConfigFileOutput) -eq $false) {
        ' ' | Set-Content -Path $IPConfigFileOutput -Encoding UTF8
    }

    Add-Content -Path $IPConfigFileOutput -Value "$Timestamp"
    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| Interface Configuration Information'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "Get-NetIPConfiguration -All -Detailed" -Source "IPConfig" -MessageType Info
    Get-NetIPConfiguration -All -Detailed | Out-String | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append

    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| IPCONFIG'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "ipconfig.exe /all" -Source "IPConfig" -MessageType Info
    ipconfig.exe /all | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append
    
    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| ROUTE PRINT'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '
    
    Write-Log -Message "route print" -Source "IPConfig" -MessageType Info
    route.exe print | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append

    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| NETSH TCP GLOBAL SETTINGS'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "netsh int tcp show global" -Source "IPConfig" -MessageType Info
    netsh.exe int tcp show global | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append

    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| TCPIPv4 REGISTRY'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "reg export" -Source "IPConfig" -MessageType Info

    reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters /s | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append

    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| TCP Heuristics'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "netsh int tcp show heuristics" -Source "IPConfig" -MessageType Info

    NETSH int tcp show heuristics | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append

    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| NETSH IPv4 Sub Interfaces'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "netsh int ipv4 show subinterfaces" -Source "IPConfig" -MessageType Info

    NETSH int ipv4 show subinterfaces | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append
   
    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| Interfaces speed and status'
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "netsh int ipv4 show subinterfaces" -Source "IPConfig" -MessageType Info

    Get-NetAdapter | Sort-Object | Format-Table ifIndex,Name,InterfaceDescription, Status, LinkSpeed | Out-File -Encoding UTF8 $IPConfigFileOutput -Append

<#
    Add-Content -Path $IPConfigFileOutput -Value ' '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value '| NETSH Wifi interfaces and BSSID                 '
    Add-Content -Path $IPConfigFileOutput -Value '************************************'
    Add-Content -Path $IPConfigFileOutput -Value ' '

    Write-Log -Message "netsh wlan show networks mode=bssid" -Source "IPConfig" -MessageType Info

    NETSH wlan show networks mode=bssid | Out-File -FilePath $IPConfigFileOutput -Encoding UTF8 -Append
#>

    Write-Log -Message "Done gathering IPConfig information" -Source "IPConfig" -MessageType Info
    Write-TestStatus -StartTime $TestStartTime -Type "IPConfig" -ErrorDetails $ErrorDetails
}

function Invoke-Tracert {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RemoteHost
        ,
        [Parameter(Mandatory = $false)]
        [string]$TCPPort
    )
    #strip off ports
    $ConsecutiveFailures = 0
    if ($RemoteHost -match ':') { $RemoteHost,$TCPPort = $RemoteHost.ToString().Split(':') }

    try {
        Write-Log -Message "Starting traceroute to '$RemoteHost'" -Source "Tracert" -MessageType Info

        $RegexIP = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(:\d{1,5})?$"
        if ($RemoteHost -notmatch $RegexIP) {
            $DNSResult = Resolve-DnsName $RemoteHost -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Where-Object {$_.Type -eq "A"} | Select-Object -First 1
            $TargetFQDN = $DNSResult.Name
            $TargetIP = $DNSResult.IPAddress
            if (-not $TargetIP) {
                Write-Log -Message "Failed to resolve hostname, unable to proceed with traceroute" -Source "Tracert" -MessageType Error
                return
            }
        } else {
            $TargetFQDN = (Resolve-DnsName $RemoteHost -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue).NameHost
            $TargetIP = $RemoteHost
        }

        if ($TargetFQDN -notlike "") {
            Write-Log -Message "Target is '$TargetIP' ($TargetFQDN)" -Source "Tracert" -MessageType Info
        } else {
            Write-Log -Message "Target is '$TargetIP'" -Source "Tracert" -MessageType Info
        }
        
        Write-Log -Message "Checking network connectivity" -Source "Tracert" -MessageType Info
        $ICMPPingSucceeded = $null
        $ICMPPing = $null
        $TestCount = 0
        while ($ICMPPingSucceeded -ne $true -and $TestCount -le 4) {
            try { $ICMPPing = (New-Object system.Net.NetworkInformation.Ping).Send($TargetIP,500) } catch {}
            if ($ICMPPing.Status -eq "Success") { $ICMPPingSucceeded = $true } else { $ICMPPingSucceeded = $false }
            $TestCount++
        }
        $TCPPingSucceeded = $null
        if ($TCPPort -match '\d+') {try { $TCPPingSucceeded = [System.Net.Sockets.TcpClient]::new().ConnectAsync($TargetIP,$TCPPort).Wait(500) } catch {} }
        
        # Only attempt Tracetcp if ICMP is blocked + destination reachable over TCP + Tracetcp is available
        if ($ICMPPingSucceeded -ne $true -and $TCPPingSucceeded -eq $true -and (Test-Path "$env:NPAPath\Scripts\tracetcp.exe") -and (Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\npcap\Parameters -ErrorAction SilentlyContinue).WinPcapCompatible) {
            Write-Log -Message "Target is not reachable over ICMP but is reachable using TCP, attempting traceroute over TCP (port $TCPPort)" -Source "Tracert" -MessageType Info
            $TracerouteOutput = @()
            & "$env:NPAPath\Scripts\tracetcp.exe" "$($TargetIP):$TCPPort" -t 500 -m 40 -n | ForEach-Object {
                $CurrentLine = $_
                
                $CurrentHop = New-Object PSObject -Property ([ordered]@{
                    Hop         = ""
                    First       = ""
                    Second      = ""
                    Third       = ""
                    IPAddress   = ""
                    FQDN        = ""
                    Protocol    = "TCP"
                    Latency     = ""
                })

                # Match only lines that match a hop (start with a hop number, followed by latencies or *)
                if ($CurrentLine -match '^\s*(\d+)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*)') {
                    $Hop,$First,$Second,$Third,$Node = ($CurrentLine -replace '^\s*(\d+)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*)','$1;$2;$3;$4;$5') -split ';'

                    $CurrentHop.Hop = $Hop
                    $CurrentHop.First = $First
                    $CurrentHop.Second = $Second
                    $CurrentHop.Third = $Third

                    if ($First -eq "*" -and $Second -eq "*" -and $Third -eq "*") {
                        $ConsecutiveFailures++
                    } else {
                        $ConsecutiveFailures = 0
                        if ($Node -match '\[.*\]') {
                            $CurrentHop.IPAddress = $Node -replace '.*?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s*.*','$1'
                            $CurrentHop.FQDN = (Resolve-DnsName $CurrentHop.IPAddress -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue).NameHost
                        } else {
                            $CurrentHop.IPAddress = $Node -replace '\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s*','$1'
                            $CurrentHop.FQDN = (Resolve-DnsName $CurrentHop.IPAddress -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue).NameHost
                        }
                        $CurrentHop.IPAddress = $CurrentHop.IPAddress -replace '\s',''
                    }

                    Write-Log -Message "Hop: $($CurrentHop.PSObject.Properties.Value -join ' - ')" -Source "Tracert" -MessageType Info

                    if ($ConsecutiveFailures -eq 15) {
                        Write-Log -Message "Maximum of 15 hops timeouts reached" -Source "Tracert" -MessageType Info
                        $CurrentHop.FQDN = $TargetFQDN
                        $CurrentHop.IPAddress = $TargetIP
                        $CurrentHop.Latency = "Timeout"
                        $TracerouteOutput += $CurrentHop
                        break
                    } else {
                        $TracerouteOutput += $CurrentHop
                    }
                }

                # Match the last line when reaching destination
                if ($CurrentLine -match '^\s*(\d+)(\s+\*\s+)*\s+Destination Reached in (.*?) ms. Connection established to (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})') {
                    $Hop,$First,$Node = ($CurrentLine -replace '^\s*(\d+)(\s+\*\s+)*\s+Destination Reached in (.*? ms). Connection established to (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})','$1;$3;$4') -split ';'

                    $CurrentHop.Hop = $Hop
                    $CurrentHop.First = $First
                    $CurrentHop.Second = "*"
                    $CurrentHop.Third = "*"
                    $CurrentHop.IPAddress = $Node -replace '\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s*','$1'
                    $CurrentHop.FQDN = (Resolve-DnsName $CurrentHop.IPAddress -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue).NameHost
                    if ($CurrentHop.FQDN -like "") {
                        $CurrentHop.FQDN = $TargetFQDN
                    }

                    Write-Log -Message "Hop: $($CurrentHop.PSObject.Properties.Value -join ' - ')" -Source "Tracert" -MessageType Info
                    $TracerouteOutput += $CurrentHop
                }
            }
        } else {
            if ($ICMPPingSucceeded -ne $true) {
                if ($TCPPort -match '\d+') {
                    if ($TCPPingSucceeded -ne $true) {
                        Write-Log -Message "Target is not reachable over ICMP nor TCP, attempting traceroute over ICMP anyway" -Source "Tracert" -MessageType Warning
                    } else {
                        Write-Log -Message "Target is not reachable over ICMP and is reachable using TCP, but Tracetcp is not available, attempting traceroute over ICMP anyway" -Source "Tracert" -MessageType Info
                    }
                } else {
                    Write-Log -Message "Target is not reachable over ICMP and no TCP port has been provided, attempting traceroute over ICMP anyway" -Source "Tracert" -MessageType Warning
                }
            } else {
                Write-Log -Message "Attempting traceroute over ICMP" -Source "Tracert" -MessageType Info
            }

            $TracerouteOutput = @() 
            tracert -4 -w 500 -h 40 -d $TargetIP | ForEach-Object {
                $CurrentLine = $_
                
                $CurrentHop = New-Object PSObject -Property ([ordered]@{
                    Hop         = ""
                    First       = ""
                    Second      = ""
                    Third       = ""
                    IPAddress   = ""
                    FQDN        = ""
                    Protocol    = "ICMP"
                    Latency     = ""
                })
    
                # Match only lines that match a hop (start with a hop number, followed by latencies or *)
                if ($CurrentLine -match '^\s+(\d+)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*)') {
                    $Hop,$First,$Second,$Third,$Node = ($CurrentLine -replace '^\s+(\d+)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*? ms|\*)\s+(.*)','$1;$2;$3;$4;$5') -split ';'
    
                    $CurrentHop.Hop = $Hop
                    $CurrentHop.First = $First
                    $CurrentHop.Second = $Second
                    $CurrentHop.Third = $Third
    
                    if ($First -eq "*" -and $Second -eq "*" -and $Third -eq "*") {
                        $ConsecutiveFailures++
                    } else {
                        $ConsecutiveFailures = 0
                        if ($Node -match '\[\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\]') {
                            $CurrentHop.IPAddress = $Node -replace '.*\[(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s*\]','$1'
                            $CurrentHop.FQDN = (Resolve-DnsName $CurrentHop.IPAddress -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue).NameHost
                        } else {
                            $CurrentHop.IPAddress = $Node -replace '\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s*','$1'
                            $CurrentHop.FQDN = (Resolve-DnsName $CurrentHop.IPAddress -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue).NameHost
                        }
                        if ($CurrentHop.FQDN -like "" -and $CurrentHop.IPAddress -eq $TargetIP) {
                            $CurrentHop.FQDN = $TargetFQDN
                        }
                        $CurrentHop.IPAddress = $CurrentHop.IPAddress -replace '\s',''
                    }
    
                    Write-Log -Message "Hop: $($CurrentHop.PSObject.Properties.Value -join ' - ')" -Source "Tracert" -MessageType Info
    
                    if ($ConsecutiveFailures -eq 15) {
                        Write-Log -Message "Maximum of 15 hops timeouts reached" -Source "Tracert" -MessageType Info
                        $CurrentHop.FQDN = $TargetFQDN
                        $CurrentHop.IPAddress = $TargetIP
                        $CurrentHop.Latency = "Timeout"
                        $TracerouteOutput += $CurrentHop
                        break
                    } else {
                        $TracerouteOutput += $CurrentHop
                    }
                }

                # Match only lines that match a hop followed directly by an IP address (indicating a ping error)
                if ($CurrentLine -match '^\s+(\d+)\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*') {
                    $Hop,$Node = ($CurrentLine -replace '^\s+(\d+)\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}).*','$1;$2') -split ';'
    
                    $CurrentHop.Hop = $Hop
                    $CurrentHop.IPAddress = $Node
                    if ($CurrentHop.IPAddress -eq $TargetIP) {
                        $CurrentHop.FQDN = $TargetFQDN
                    } else {
                        $CurrentHop.FQDN = (Resolve-DnsName $CurrentHop.IPAddress -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue).NameHost
                    }
                    $CurrentHop.First = "*"
                    $CurrentHop.Second = "*"
                    $CurrentHop.Third = "*"
                    $CurrentHop.Latency = "Timeout"
                    $TracerouteOutput += $CurrentHop
                    Write-Log -Message "Hop: $($CurrentHop.PSObject.Properties.Value -join ' - ')" -Source "Tracert" -MessageType Info
                }
            }
        }
        if ($null -ne $TracerouteOutput -and $TracerouteOutput.count -gt 0) {
            $LastHop = $TracerouteOutput | Select-Object -Last 1
            if ($LastHop.FQDN -like "") {
                $LastHop.FQDN = $TargetFQDN
            }
            Write-Log -Message "Traceroute to '$RemoteHost' completed" -Source "Tracert" -MessageType Info
            $TracerouteOutput
        } else {
            Write-Log -Message "Traceroute to '$RemoteHost' failed (empty output)" -Source "Tracert" -MessageType Error
        }
    } catch {
        if ($null -ne $TracerouteOutput) {
            if ($TracerouteOutput.Latency -match "Timeout") {
                Write-Log -Message "Traceroute to '$RemoteHost' completed with timeout" -Source "Tracert" -MessageType Info
            } else {
                Write-Log -Message "Traceroute to '$RemoteHost' generated an output but failed with an error: $($_.Exception.Message)" -Source "Tracert" -MessageType Error
            }
            $TracerouteOutput
        } else {
            Write-Log -Message "Traceroute to '$RemoteHost' failed: $($_.Exception.Message)" -Source "Tracert" -MessageType Error
        }
    }
}

function Start-TracerouteProcess {

    Param (
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $RemoteHost
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
        [String] $TCPPort
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $Service
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [string] $TracertFileOutput
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [string] $TracerouteResults
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [ref] $ErrorDetailsReference
    )

    try {
        $TracerouteOutput = ""
        Add-Content -Path $TracertFileOutput -Value "$RemoteHost"
        $TracerouteOutput = Invoke-Tracert -RemoteHost $RemoteHost -TCPPort $TCPPort
        $TracerouteOutput | Format-Table Hop, First, Second, Third, IPAddress, FQDN, Protocol -AutoSize | Out-File -FilePath $TracertFileOutput -Encoding UTF8 -Append
        Add-Content -Path $TracertFileOutput -Value ' '
        $Timestamp = Get-DateInFile

        if ($null -eq $TracerouteOutput) {
            $ErrorDetailsReference.Value += "Traceroute to '$RemoteHost' failed"
        } else {

            # Get MS entry point information
            if ($TracerouteOutput | Where-Object {$_.FQDN -match '\.msn\.net$'}) {
                $MSEntry = ($TracerouteOutput | Where-Object {$_.FQDN -match '\.msn\.net$'} | Select-Object -First 1)
                Write-Log -Message "Checking latency to entry point '$($MSEntry.IPAddress) - $($MSEntry.FQDN)'" -Source "Tracert" -MessageType Info
                $Latencies = @()
                $PingTests = @()
                $PingCount = 0
                while ($PingCount -lt 10) {
                    $PingCount++
                    $PingTests += Get-WmiObject -Class Win32_PingStatus -Filter "(Address='$($MSEntry.IPAddress)') and timeout=500"					
                }
                $PingTests.ResponseTime | ForEach-Object { $Latencies += $_ }
                if ($MSEntry.First -match ' ms') { $Latencies += [int]($MSEntry.First -replace ' ms','') }
                if ($MSEntry.Second -match ' ms') { $Latencies += [int]($MSEntry.Second -replace ' ms','') }
                if ($MSEntry.Third -match ' ms') { $Latencies += [int]($MSEntry.Third -replace ' ms','') }
                $Latencies = $Latencies | Where-Object {$_ -match '\d+'} | Sort-Object
                if ($Latencies) {
                    # Calculate median value
                    if ($Latencies.count -eq 1) {
                        $MSEntryLatency = $Latencies[0]
                    } elseif ($Latencies.count % 2 -eq 0) {
                        $MSEntryLatency = [int](($Latencies[$Latencies.count/2-1] + $Latencies[$Latencies.count/2]) / 2)
                    } else {
                        $MSEntryLatency = $Latencies[[math]::floor($Latencies.count/2)]
                    }
                } else {
                    $MSEntryLatency = ""
                }
                ($TracerouteOutput | Where-Object {$_.FQDN -match '\.msn\.net$'} | Select-Object -First 1).Latency = $MSEntryLatency
            }

            # Get target information
            $LastHop = $TracerouteOutput | Select-Object -Last 1
            if ($LastHop.Latency -match "Timeout" -or $null -eq $LastHop) {
                ($TracerouteOutput | Select-Object -Last 1).Latency = ""
            } else {
                Write-Log -Message "Checking latency to target '$($LastHop.IPAddress) - $($LastHop.FQDN)'" -Source "Tracert" -MessageType Info
                $Latencies = @()
                $PingTests = @()
                $PingCount = 0
                while ($PingCount -lt 10) {
                    $PingCount++
                    $PingTests += Get-WmiObject -Class Win32_PingStatus -Filter "(Address='$($LastHop.IPAddress)') and timeout=500"					
                }
                $PingTests.ResponseTime | ForEach-Object { $Latencies += $_ }
                if ($LastHop.First -match ' ms') { $Latencies += [int]($LastHop.First -replace '<| ms','') }
                if ($LastHop.Second -match ' ms') { $Latencies += [int]($LastHop.Second -replace '<| ms','') }
                if ($LastHop.Third -match ' ms') { $Latencies += [int]($LastHop.Third -replace '<| ms','') }
                $Latencies = $Latencies | Where-Object {$_ -match '\d+'} | Sort-Object
                if ($Latencies) {
                    # Calculate median value
                    if ($Latencies.count -eq 1) {
                        $TargetLatency = $Latencies[0]
                    } elseif ($Latencies.count % 2 -eq 0) {
                        $TargetLatency = [int](($Latencies[$Latencies.count/2-1] + $Latencies[$Latencies.count/2]) / 2)
                    } else {
                        $TargetLatency = $Latencies[[math]::floor($Latencies.count/2)]
                    }
                } else {
                    $TargetLatency = ""
                }
                ($TracerouteOutput | Select-Object -Last 1).Latency = $TargetLatency
            }
            
            $ProcessedTracerouteOutput = $TracerouteOutput | Select-Object -Property @{Name="Timestamp";Expression={$Timestamp}},@{Name="Service";Expression={$Service}},@{Name="Target";Expression={$RemoteHost}},Hop,First,Second,Third,IPAddress,FQDN,Protocol,Latency
            if (-not (Test-Path $TracerouteResults)) {
                #If it is first time we need create file with following structure
                $Headers = ( "Timestamp" , "Service" , "Target" , "Hop" , "First" , "Second" , "Third" , "IPAddress" , "FQDN" , "Protocol" , "Latency" ) -join "`t"
                Add-Content -Value $Headers -Path $TracerouteResults
            }
            Foreach ($Line in $ProcessedTracerouteOutput) {
                # Add each line to the results file
                $Values = ($Line.Timestamp , $Line.Service , $Line.Target , $Line.Hop , $Line.First , $Line.Second , $Line.Third , $Line.IPAddress , $Line.FQDN , $Line.Protocol , $Line.Latency) -join "`t"
                Add-Content -Value $Values -Path $TracerouteResults
            }
        }
    } catch {
        Write-Log -Message "Traceroute to '$RemoteHost' failed with exception: $($_.Exception.Message)" -Source "Tracert" -MessageType Error
        Write-Log -Message "Unhandled error: $($_ | Format-List * -Force | Out-String)" -Source "Tracert" -MessageType Error
        $ErrorDetailsReference.Value += "Traceroute to '$RemoteHost' failed with exception: $($_.Exception.Message)"
    }
}

function Invoke-DNSQuery {
    Param (
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $Name
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $DNSServer
    )

    Write-Log -Message "Running DNS lookup for '$Name' with server '$DNSServer'" -Source "DNSLookup" -MessageType Info
    try {
        $DNSResponse = Resolve-DnsName -Name "$Name." -Type A -Server $DNSServer -DnsOnly -QuickTimeout -ErrorAction Stop | Where-Object {$_.Type -eq "A"} | Select-Object -First 1
        Write-Log -Message "DNS answer: $($DNSResponse.Name) - $($DNSResponse.IPAddress)" -Source "DNSLookup" -MessageType Info
    } catch {
        Write-Log -Message "DNS request failed with exception: $($_.Exception.Message)" -Source "DNSLookup" -MessageType Error
        return "DNS request failed with exception: $($_.Exception.Message)"
    }
}

function Write-DiagLogs {

    Write-Log -Message "Gathering diagnostic logs" -Source "Main - DiagLogs" -MessageType Info -DisplayInGui
    $DiagPath = "$env:NPAPath\Diags"

    if (Test-Path $DiagPath) {
        Write-Log -Message "Removing previous temporary diagnostic logs folder '$DiagPath'" -Source "Main - DiagLogs" -MessageType Info
        Remove-Item -Path $DiagPath -Force -Recurse
        Start-Sleep -Seconds 1
    }

    Write-Log -Message "Creating temporary diagnostic logs folder '$DiagPath'" -Source "Main - DiagLogs" -MessageType Info
    New-Item $DiagPath -type directory | Out-Null

    if (Test-Path "C:\Program Files (x86)\Microsoft Teams Network Assessment Tool\NetworkAssessmentTool.exe.config") {
        $TeamsNATConfig = "C:\Program Files (x86)\Microsoft Teams Network Assessment Tool\NetworkAssessmentTool.exe.config"
    } elseif (Test-Path "C:\Program Files\Microsoft Teams Network Assessment Tool\NetworkAssessmentTool.exe.config") {
        $TeamsNATConfig = "C:\Program Files\Microsoft Teams Network Assessment Tool\NetworkAssessmentTool.exe.config"
    }

    Write-Log -Message "Collecting Teams NAT configuration file" -Source "Main - DiagLogs" -MessageType Info
    Copy-Item $TeamsNATConfig "$DiagPath\NetworkAssessmentTool.exe.config"
    Write-Log -Message "Collecting NPA configuration file" -Source "Main - DiagLogs" -MessageType Info
    Copy-Item "$env:NPAPath\Settings.json" "$DiagPath\Settings.json"
    Write-Log -Message "Collecting runlog file" -Source "Main - DiagLogs" -MessageType Info
    Copy-Item "$env:NPAPath\NPARunlog.log" "$DiagPath\NPARunlog.log"

    $FileTimestamp = Get-DateInFileName

    $ZipFileName = "$env:NPAPath\DiagFiles_$FileTimestamp.zip"

    Write-Log -Message "Compressing diagnostic logs to file '$ZipFileName'" -Source "Main - DiagLogs" -MessageType Info
    Add-Type -Assembly System.IO.Compression.FileSystem
    $compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
    [System.IO.Compression.ZipFile]::CreateFromDirectory($DiagPath, $ZipFileName, $compressionLevel, $false)

    Remove-Item -Path $DiagPath -Force -Recurse

    Write-Log -Message "Diagnostic logs have been saved to '$ZipFileName'" -Source "Main - DiagLogs" -MessageType Info -DisplayInGui
    explorer.exe /select,"$ZipFilename"
}

function Get-SPOAccessToken ($clientid, $clientsecret, $tenantid, $targetURL) {

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $TenantType = $CurrentSettings.TenantType[1]

    $siteURL = ($targetURL -split "/")[2]

    if ($TenantType -eq "Worldwide") {
        $tenantauth2 = "https://accounts.accesscontrol.windows.net/$tenantid/tokens/OAuth/2"
    } elseif ($TenantType -eq "GCCH") {
        $tenantauth2 = "https://login.microsoftonline.us/$tenantid/tokens/OAuth/2"
    } elseif ($TenantType -eq "DOD") {
        $tenantauth2 = "https://login.microsoftonline.us/$tenantid/tokens/OAuth/2"
    }

    $header = @{
        "Content-Type" = "application/x-www-form-urlencoded"
    }

    #URL encode client secret to prevent errors
    Add-Type -Assembly System.web
    $clientsecret = [System.Web.HTTPUtility]::urlencode($clientsecret)

    $body = "grant_type=client_credentials
    &resource=00000003-0000-0ff1-ce00-000000000000/$siteURL@$tenantid
    &client_id= $clientid@$tenantid
    &client_secret= $clientsecret"

    try {
        Write-Log -Message "Requesting access token to '$tenantauth2'" -Source "FileTransfer" -MessageType Info
        $Tokenresult = Invoke-RestMethod -Uri $tenantauth2 -Headers $header -Method POST -Body $body -UseBasicParsing -UserAgent (Get-UserAgent)
    }
    catch {
        Write-Log -Message "Request for access token failed with exception: $($_.Exception.Message)" -Source "FileTransfer" -MessageType Error
        if ($_.Exception.Response) {
            $ErrorResponse = $_
            Write-Log -Message "Known headers in response:" -Source "FileTransfer" -MessageType Error
            $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer" -MessageType Error
            }
        }
        $Tokenresult = $null
    }

    return $Tokenresult
}

function Get-SPODocumentFolder ($token, $targetURL) {

    $url = "$targeturl/_api/web/GetFolderByServerRelativeUrl('')"

    $header = @{
        "Authorization" = "Bearer " + $token
        "Accept"        = "application/json;odata=verbose"
    }

    try {
        Write-Log -Message "Sending query to '$url'" -Source "FileTransfer" -MessageType Info
        $DocList = Invoke-RestMethod -Uri $url -Headers $header -Method GET -UseBasicParsing -UserAgent (Get-UserAgent)
        $DocumentFolder = ($doclist.d.WelcomePage -split "/")[0]
    }
    catch {
        Write-Log -Message "Request for Documents folder name failed with exception: $($_.Exception.Message)" -Source "FileTransfer" -MessageType Error
        if ($_.Exception.Response) {
            $ErrorResponse = $_
            Write-Log -Message "Known headers in response:" -Source "FileTransfer" -MessageType Error
            $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer" -MessageType Error
            }
        }
        $DocumentFolder = $null
    }
    return $DocumentFolder
}

function New-SPOFileUpload ($targeturl, $targetfolder, $token, [byte[]]$content, $filename) {

    $InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
    # Set TCP idle timeout to 5 seconds
    [System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

    $httpresult = $null
    $FileType = $filename -replace '.*?(\d+MB)UP\..*','$1UP'
    $ContentLength = $content.Length

    if ($token) {
        $header = @{
            "Authorization"  = "Bearer " + $token
            "Content-Length" = "$ContentLength"
        }

        try {
            $uri = "$targeturl/_api/web/GetFolderByServerRelativeUrl('$targetfolder')/Files/add(url='$filename',overwrite=true)"
            Write-Log -Message "Uploading file with token to URI '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Info
            $httpresult = Invoke-WebRequest -Method POST -Uri $uri -Headers $header -Body $content -UseBasicParsing -UserAgent (Get-UserAgent)
            $result = $httpresult.statusdescription
        }
        catch {
            Write-Log -Message "File upload failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
            if ($_.Exception.Response) {
                $ErrorResponse = $_
                Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
                $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                    Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
                }
            }
            $result = $_.Exception.Message
        }
    } else {
        
        [System.Net.ServicePointManager]::MaxServicePointIdleTime = 1900
        $ValidResponse = $false
        $Tries = 1
        While ($ValidResponse -ne $true -and $Tries -le 10) {
            try {
                #$uri = "$($targeturl)TransferTest.aspx?op=up&length=1"
                $uri = "$($targeturl)transfertestfootprint.aspx?op=up&length=1"
                $httpresult = Invoke-WebRequest -Method POST -Uri $uri -UseBasicParsing -UserAgent (Get-UserAgent)
                if ($httpresult.Content -match "denied") {throw "Access denied to SPO page"}
                $ValidResponse = $true
                #$uri = "$($targeturl)TransferTest.aspx?op=up&length=$ContentLength"
                $uri = "$($targeturl)transfertestfootprint.aspx?op=up&length=$ContentLength"
            } catch {
                if ($_.Exception.Message -match '\(404\)') {
                    Write-Log -Message "Got a 404 from service with URI '$uri', retrying" -Source "FileTransfer - SPO $FileType" -MessageType Warning
                    ipconfig /flushdns | out-null
                    $Tries++
                    Start-Sleep -Milliseconds 2000
                } else {
                    Write-Log -Message "File upload failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
                    if ($_.Exception.Response) {
                        $ErrorResponse = $_
                        Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
                        $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                            Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
                        }
                    }
                    $result = $_.Exception.Message
                    break
                }
            }
        }
        [System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

        if ($ValidResponse -ne $true) {
            Write-Log -Message "Unable to get a valid response from service after $Tries tries with URI '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Warning
            $uri = "https://spo-ring.msedge.net/transfertest?op=up&length=$ContentLength"
        }

        try {
            Write-Log -Message "Uploading file without token to URI '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Info
            $httpresult = Invoke-WebRequest -Method POST -Uri $uri -Body $content -UseBasicParsing -UserAgent (Get-UserAgent)
            $result = $httpresult.statusdescription
        }
        catch {
            Write-Log -Message "File upload failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
            if ($_.Exception.Response) {
                $ErrorResponse = $_
                Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
                $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                    Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
                }
            }
            $result = $_.Exception.Message
        }
    }

    # Reset TCP idle timeout to its initial value
    [System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout
    return $result
}

function Remove-SPOFile ($targetURL, $targetfolder, $token, $filename) {
	
    $httpresult = $null
    $FileType = $filename -replace '.*?(\d+MB)UP\..*','$1DOWN'
    $ContentLength = $content.Length

    $header = @{
        "Authorization"  = "Bearer " + $token
        "Content-Length" = "$ContentLength"
        "X-HTTP-Method"  = "DELETE"
        "If-Match"       = "{etag or *}"
    }

    try {
        $uri = "$targeturl/_api/web/GetFolderByServerRelativeUrl('$targetfolder/$filename')"
        Write-Log -Message "Removing file with URI '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Info
        $httpresult = Invoke-WebRequest -Method POST -Uri $uri -Headers $header -UseBasicParsing -UserAgent (Get-UserAgent)
        $result = $httpresult.statusdescription
    }
    catch {
        Write-Log -Message "File removal failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
        if ($_.Exception.Response) {
            $ErrorResponse = $_
            Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
            $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
            }
        }
        $result = $_.Exception.Message
    }
    return $result
}

function New-SPOFileDownload ($token, $targetURL, $targetfolder, $filename) {

    $InitialTCPIdleTimeout = [System.Net.ServicePointManager]::MaxServicePointIdleTime
    # Set TCP idle timeout to 5 seconds
    [System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

    $httpresult = $null
    $FileType = $filename -replace '.*?(\d+MB)UP\..*','$1DOWN'
    $ProgressPreference = "SilentlyContinue"

    if ($token) {
        $header = @{
            "Authorization" = "Bearer " + $token
        }

        try {
            $relativeurl = ($targeturl -split "/" | Select-Object -Skip 3) -join "/"
            $uri = "$targetURL/_api/web/GetFileByServerRelativeUrl('/$relativeurl/$targetfolder/$filename')/`$value/"
            Write-Log -Message "Downloading file with token from URI '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Info
            $httpresult = Invoke-WebRequest -Method GET -Uri $uri -Headers $header -UseBasicParsing -UserAgent (Get-UserAgent)
        }
        catch {
            Write-Log -Message "File download failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
            if ($_.Exception.Response) {
                $ErrorResponse = $_
                Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
                $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                    Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
                }
            }
            $result = $_.Exception.Message
        }
    } else {

        $ContentLength = [int]($FileType -replace '^(\d+)MB(UP|DOWN)','$1') * 1MB

        [System.Net.ServicePointManager]::MaxServicePointIdleTime = 1900
        $ValidResponse = $false
        $Tries = 1
        While ($ValidResponse -ne $true -and $Tries -lt 10) {
            try {
                #$uri = "$($targeturl)transfertest/transfertest?op=down&length=1"
                $uri = "$($targeturl)transfertestfootprint.aspx?op=down&length=1"
                $httpresult = Invoke-WebRequest -Method GET -Uri $uri -UseBasicParsing -UserAgent (Get-UserAgent)
                if ($httpresult.Content -match "denied") {throw "Access denied to SPO page"}
                $ValidResponse = $true
                #$uri = "$($targeturl)transfertest/transfertest?op=down&length=$ContentLength"
                $uri = "$($targeturl)transfertestfootprint.aspx?op=down&length=$ContentLength"
            } catch {
                if ($_.Exception.Message -match '\(404\)') {
                    Write-Log -Message "Got a 404 from service with URI '$uri', retrying" -Source "FileTransfer - SPO $FileType" -MessageType Warning
                    ipconfig /flushdns | out-null
                    $Tries++
                    Start-Sleep -Milliseconds 2000
                } else {
                    Write-Log -Message "File upload failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
                    if ($_.Exception.Response) {
                        $ErrorResponse = $_
                        Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
                        $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                            Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
                        }
                    }
                    $result = $_.Exception.Message
                    break
                }
            }
        }
        [System.Net.ServicePointManager]::MaxServicePointIdleTime = 5000

        if ($ValidResponse -ne $true) {
            Write-Log -Message "Unable to get a valid response from service after $Tries tries with URI '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Warning
            $uri = "https://spo-ring.msedge.net/transfertest?op=down&length=$ContentLength"
        }

        try {
            Write-Log -Message "Downloading file without token from URI '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Info
            $httpresult = Invoke-WebRequest -Method GET -Uri $uri -UseBasicParsing -UserAgent (Get-UserAgent)
        }
        catch {
            Write-Log -Message "File download failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
            if ($_.Exception.Response) {
                $ErrorResponse = $_
                Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
                $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                    Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
                }
            }
            $result = $_.Exception.Message
        }
    }

    if ($httpresult.StatusCode -eq 200) {
        $ExpectedFileSizeInMB = $FileType -replace '^(\d+)MB(UP|DOWN)','$1'
        $DownloadedFileSizeInMB = [math]::Round(($httpresult.Content.Length/1MB),4)
        if ($DownloadedFileSizeInMB -eq $ExpectedFileSizeInMB) {
            Write-Log -Message "Downloaded file match the expected size" -Source "FileTransfer - SPO $FileType" -MessageType Info
            $result = $httpresult.statusdescription
        } else {
            Write-Log -Message "Downloaded file does not match the expected size" -Source "FileTransfer - SPO $FileType" -MessageType Warning
            $result = "Expected $($ExpectedFileSizeInMB)MB - Downloaded $($DownloadedFileSizeInMB)MB"
        }
    }

    # Reset TCP idle timeout to its initial value
    [System.Net.ServicePointManager]::MaxServicePointIdleTime = $InitialTCPIdleTimeout
    return $result
}

function Test-SPOFileExists ($targeturl, $targetfolder, $token, $filename) {
	
    $httpresult = $null
    $FileType = $filename -replace '.*?(\d+MB)UP\..*','$1UP'
	
    $header = @{
        "Authorization"  = "Bearer " + $token
    }

    try {
        $uri = "$targeturl/_api/web/GetFolderByServerRelativeUrl('$targetfolder')/Files/"
        Write-Log -Message "Checking if file '$filename' exists at URL '$uri'" -Source "FileTransfer - SPO $FileType" -MessageType Info
        $httpresult = Invoke-WebRequest -Method GET -Uri $uri -Headers $header -UseBasicParsing -UserAgent (Get-UserAgent)
        if ($httpresult.StatusCode -eq 200) {
            if ( ([xml]$httpresult.Content).feed.entry.content.properties.Name | Where-Object {$_ -eq $Filename} ) {
                $result = $true
            } else {
                $result = $false
            }
        } else {
            Write-Log -Message "File check failed" -Source "FileTransfer - SPO $FileType" -MessageType Error
            $result = $httpresult.statusdescription
        }   
    }
    catch {
        Write-Log -Message "File check failed with exception: $($_.Exception.Message)" -Source "FileTransfer - SPO $FileType" -MessageType Error
        if ($_.Exception.Response) {
            $ErrorResponse = $_
            Write-Log -Message "Known headers in response:" -Source "FileTransfer - SPO $FileType" -MessageType Error
            $_.Exception.Response.Headers | Where-Object { $_ -match "X-(FrontEnd|MachineName|EndPoint|UserHostAddress|Powered-By|MSEdge|ms-ests-server|FirstHopCafeEFZ|FEEFZInfo|FEProxyInfo|BEPartition|CalculatedBETarget)|Proxy|Server" } | Sort-Object | ForEach-Object {
                Write-Log -Message "$_ = $($ErrorResponse.Exception.Response.GetResponseHeader($_))" -Source "FileTransfer - SPO $FileType" -MessageType Error
            }
        }
        $result = $_.Exception.Message
    }
    return $result
}

function Get-Secret ($path) {
    [void] [Reflection.Assembly]::LoadWithPartialName("System.Security")
    $scope = [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    $data = Get-Content $path
    $ciphertext = [System.Convert]::FromBase64String($data)
    $plaintext = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $ciphertext, $null, $scope )
    return [System.Text.UTF8Encoding]::UTF8.GetString($plaintext)
}

function Set-Secret ($secret, $path) {
    [void] [Reflection.Assembly]::LoadWithPartialName("System.Security")
    $scope = [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    $plaintext = [System.Text.UTF8Encoding]::UTF8.GetBytes($secret)
    $ciphertext = [System.Security.Cryptography.ProtectedData]::Protect(
        $plaintext, $null, $scope )
    [System.Convert]::ToBase64String($ciphertext) >$path
}

function New-SettingsFile ($Version) {
    $NewSettings = "" | Select-Object Version, IsFirstRun, EgressIP, OutputPath, OneDriveURL, OneDriveClientID, TenantType, SiteName, Location, OneDriveFQDN, Tenantid, WiresharkPath, NetmonPath, TeamsNATpath, TenantName, AppRegistration, ProxyConfiguration, CaptureTool, CaptureScenario, DebugMode
    $NewSettings.version = $Version
    $NewSettings.OutputPath = "$env:NPAPath\Output"
    $NewSettings.IsFirstRun = "True"
    $NewSettings.CaptureTool = @(0, "Wireshark")
    $NewSettings.CaptureScenario = @(0, "Default")
    $NewSettings.DebugMode = "False"
    $NewSettings | ConvertTo-Json | Out-File -FilePath $env:NPAPath\Settings.json -Encoding UTF8 -Force
}

function Stop-RunningProcess {
    Param(
        [Parameter(Mandatory=$false)]
        [string]$ProcessName
        ,
        [Parameter(Mandatory=$false)]
        [string[]]$ProcessID
    )

    if ($ProcessName) {
        $ProcessesList = Get-Process | Where-Object {$_.Name -match $ProcessName}
    } else {
        $ProcessesList = Get-Process | Where-Object {$_.Id -in $ProcessID}
    }

    if ($ProcessesList -notlike "") {
        while ($ProcessesList.HasExited -ne $true) {
            $ProcessesList | Stop-Process -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 100
        }
    }

}

function Set-TeamsConfigFile {
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $TenantType = $CurrentSettings.TenantType[1]
    $TeamsNATpath = $CurrentSettings.TeamsNATpath
    $TeamsNATConfigFilePath = "$TeamsNATpath\NetworkAssessmentTool.exe.config"

    $ConnectivityResultsFileName = "service_connectivity_check_results.txt"
    $PerformanceResultsFileName = "quality_check_results.csv"
    $MediaDuration = 45
    $MediaPortRangeStart = "50000"
    $MediaPortRangeEnd = "50019"

    $RunningAsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    try {
        $fileStream = [System.IO.File]::Open($TeamsNATConfigFilePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Write)
        $fileStream.Close()
        $WriteAccessToConfigFile = $true
    } catch {
        $WriteAccessToConfigFile = $false
    }

    try {
        # Update TeamsNAT QoS rules if needed
        $CurrentQoSRules = Get-ItemProperty HKLM:\SOFTWARE\Policies\Microsoft\Windows\QoS\* -ErrorAction SilentlyContinue
        $TeamsAudioQoSRule = $CurrentQoSRules | Where-Object {($_.AppName -match "Teams.exe|ms-teams.exe" -or $_.'Application Name' -match "Teams.exe|ms-teams.exe") -and $_.PSChildName -match "Audio"} | Select-Object -First 1
        $TeamsNATAudioQoSRule = $CurrentQoSRules | Where-Object {($_.AppName -eq "NetworkAssessmentTool.exe" -or $_.'Application Name' -eq "NetworkAssessmentTool.exe") -and $_.PSChildName -match "TeamsNAT Audio"} | Select-Object -First 1
        if ($TeamsAudioQoSRule) {
            if ($TeamsAudioQoSRule.'SrcPortLow') {
                $MediaPortRangeStart = $TeamsAudioQoSRule.SrcPortLow
                $MediaPortRangeEnd = $TeamsAudioQoSRule.SrcPortHigh
                $DSCPValue = $TeamsAudioQoSRule.DSCP
            } else {
                $MediaPortRangeStart = ($TeamsAudioQoSRule.'Local Port' -split ':')[0]
                $MediaPortRangeEnd = ($TeamsAudioQoSRule.'Local Port' -split ':')[-1]
                $DSCPValue = $TeamsAudioQoSRule.'DSCP Value'
            }
        }
        if ($TeamsAudioQoSRule -and -not ($TeamsNATAudioQoSRule)) {
            if ($RunningAsAdmin) {
                Write-Log -Message "Detected QoS rule for Teams audio, applying a QoS rule for TeamsNAT audio" -Source "TeamsNAT" -MessageType Info
                $CreatedTeamsNATAudioQoSRule = New-NetQosPolicy -Name 'TeamsNAT Audio' -AppPathNameMatchCondition 'NetworkAssessmentTool.exe' -IPProtocolMatchCondition Both -IPSrcPortStartMatchCondition $MediaPortRangeStart -IPSrcPortEndMatchCondition $MediaPortRangeEnd -DSCPAction $DSCPValue -NetworkProfile All -Precedence 1 -ErrorAction Stop
                if ($CreatedTeamsNATAudioQoSRule) {
                    Write-Log -Message "QoS rule for TeamsNAT audio created successfully" -Source "TeamsNAT" -MessageType Info
                } else {
                    Write-Log -Message "Failed to create QoS rule for TeamsNAT audio" -Source "TeamsNAT" -MessageType Error
                    Write-Log -Message "Configure the QoS rule manually using the following command:" -Source "TeamsNAT" -MessageType Error
                    Write-Log -Message "New-NetQosPolicy -Name 'TeamsNAT Audio' -AppPathNameMatchCondition 'NetworkAssessmentTool.exe' -IPProtocolMatchCondition Both -IPSrcPortStartMatchCondition $MediaPortRangeStart -IPSrcPortEndMatchCondition $MediaPortRangeEnd -DSCPAction $DSCPValue -NetworkProfile All -Precedence 1 -ErrorAction Stop" -Source "TeamsNAT" -MessageType Error
                }
            } else {
                Write-Log -Message "Script is not running as administrator, unable to create QoS rule for TeamsNAT audio" -Source "TeamsNAT" -MessageType Warning
                Write-Log -Message "Configure the QoS rule manually using the following command:" -Source "TeamsNAT" -MessageType Warning
                Write-Log -Message "New-NetQosPolicy -Name 'TeamsNAT Audio' -AppPathNameMatchCondition 'NetworkAssessmentTool.exe' -IPProtocolMatchCondition Both -IPSrcPortStartMatchCondition $MediaPortRangeStart -IPSrcPortEndMatchCondition $MediaPortRangeEnd -DSCPAction $DSCPValue -NetworkProfile All -Precedence 1 -ErrorAction Stop" -Source "TeamsNAT" -MessageType Warning
            }
        }
    } catch {
        Write-Log -Message "Failed to create QoS rule for TeamsNAT audio: $($_.Exception.Message)" -Source "TeamsNAT" -MessageType Error
    }

    try {
        # Update TeamsNAT config file if needed
        [xml]$configfile = Get-Content $TeamsNATConfigFilePath

        $ConfiguredMediaDuration = ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "MediaDuration" }).value
        $ConfiguredOutputFileName = ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "OutputFileName" }).value
        $ConfiguredResultsFileName = ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "ResultsFileName" }).value
        $ConfiguredRelayFqdn = ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "Relay.FQDN" }).value
        $ConfiguredMinimumSourcePort = ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "MinimumSourcePort" }).value
        $ConfiguredMaximumSourcePort = ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "MaximumSourcePort" }).value

        Switch($TenantType) {
            "Worldwide" { $RelayFqdn = "worldaz.tr.teams.microsoft.com" }
            "GCCH" { $RelayFqdn = "tr.gov.teams.microsoft.us" }
            "DOD" { $RelayFqdn = "tr.dod.teams.microsoft.us" }
        }

        if ($ConfiguredMediaDuration -ne $MediaDuration -or $ConfiguredOutputFileName -ne $ConnectivityResultsFileName -or $ConfiguredResultsFileName -ne $PerformanceResultsFileName -or $ConfiguredRelayFqdn -ne $RelayFqdn -or $ConfiguredMinimumSourcePort -ne $MediaPortRangeStart -or $ConfiguredMaximumSourcePort -ne $MediaPortRangeEnd) {
            if ($WriteAccessToConfigFile) {
                ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "MediaDuration" }).value = "$MediaDuration"
                ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "OutputFileName" }).value = "$ConnectivityResultsFileName"
                ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "ResultsFileName" }).value = "$PerformanceResultsFileName"
                ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "Relay.FQDN" }).value = "$RelayFqdn"
                ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "MinimumSourcePort" }).value = "$MediaPortRangeStart"
                ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "MaximumSourcePort" }).value = "$MediaPortRangeEnd"
                $configfile.save($TeamsNATConfigFilePath)
    
                Write-Log -Message "The config file has been updated" -Source "TeamsNAT" -MessageType Info
                Write-Log -Message "MediaDuration = $MediaDuration" -Source "TeamsNAT" -MessageType Info
                Write-Log -Message "OutputFileName = '$ConnectivityResultsFileName'" -Source "TeamsNAT" -MessageType Info
                Write-Log -Message "ResultsFileName = '$PerformanceResultsFileName'" -Source "TeamsNAT" -MessageType Info
                Write-Log -Message "Relay.Fqdn = '$RelayFqdn'" -Source "TeamsNAT" -MessageType Info
                Write-Log -Message "MinimumSourcePort = '$MediaPortRangeStart'" -Source "TeamsNAT" -MessageType Info
                Write-Log -Message "MaximumSourcePort = '$MediaPortRangeEnd'" -Source "TeamsNAT" -MessageType Info
            } else {
                Write-Log -Message "Script does not have write access to TeamsNAT config file$(if (-not $RunningAsAdmin) {" (script is not running as administrator)"}), unable to edit the TeamsNAT config file to the expected values" -Source "TeamsNAT" -MessageType Error
                Write-Log -Message "Ensure that the configuration file has the following values:" -Source "TeamsNAT" -MessageType Error
                Write-Log -Message "MediaDuration = $MediaDuration" -Source "TeamsNAT" -MessageType Error
                Write-Log -Message "OutputFileName = '$ConnectivityResultsFileName'" -Source "TeamsNAT" -MessageType Error
                Write-Log -Message "ResultsFileName = '$PerformanceResultsFileName'" -Source "TeamsNAT" -MessageType Error
                Write-Log -Message "Relay.Fqdn = '$RelayFqdn'" -Source "TeamsNAT" -MessageType Error
                Write-Log -Message "MinimumSourcePort = '$MediaPortRangeStart'" -Source "TeamsNAT" -MessageType Error
                Write-Log -Message "MaximumSourcePort = '$MediaPortRangeEnd'" -Source "TeamsNAT" -MessageType Error
            }
        }
    } catch {
        Write-Log -Message "Failed to modify configuration file: $($_.Exception.Message)" -Source "TeamsNAT" -MessageType Error
    }

    try {
        # Update TeamsNAT config file if there is no DNS resolution
        [xml]$configfile = Get-Content $TeamsNATConfigFilePath

        $ConfiguredRelayIP = ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "Relay.IP" }).value

        Switch($TenantType) {
            "Worldwide" { $RelayFqdn = "worldaz.tr.teams.microsoft.com" }
            "GCCH" { $RelayFqdn = "tr.gov.teams.microsoft.us" }
            "DOD" { $RelayFqdn = "tr.dod.teams.microsoft.us" }
        }

        if ((Resolve-DnsName $RelayFqdn -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Where-Object {$_.Type -eq "A"} | Select-Object -First 1).IPAddress) {
            if ($ConfiguredRelayIP -notlike "") {
                if ($WriteAccessToConfigFile) {
                    Write-Log -Message "Removing previous relay IP from configuration file" -Source "TeamsNAT" -MessageType Info
                    ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "Relay.IP" }).value = ""
                    $configfile.save($TeamsNATConfigFilePath)
                } else {
                    Write-Log -Message "Script does not have write access to TeamsNAT config file$(if (-not $RunningAsAdmin) {" (script is not running as administrator)"}), unable to remove previous relay IP (Relay.IP) in the TeamsNAT config file" -Source "TeamsNAT" -MessageType Error
                }
            }
        } else {
            if ($WriteAccessToConfigFile) {
                Write-Log -Message "Cannot resolve relay FQDN '$RelayFQDN', attempting to get relay IP from HTTPS" -Source "TeamsNAT" -MessageType Info
                [Byte[]]$Payload = 0x02, 0x00, 0x00, 0x3C, 0x00, 0x03, 0x00, 0x28, 0x21, 0x12, 0xA4, 0x42, 0x67, 0xE6, 0x40, 0x0F, 0xEF, 0xC6, 0x28, 0xDA, 0x82, 0x7D, 0x28, 0x9F, 0x00, 0x0F, 0x00, 0x04, 0x72, 0xC6, 0x4B, 0xC6, 0x80, 0x08, 0x00, 0x04, 0x00, 0x00, 0x00, 0x06, 0x80, 0x06, 0x00, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x10, 0x00, 0x04, 0x00, 0x00, 0x01, 0x5E, 0x80, 0x55, 0x00, 0x04, 0x00, 0x00, 0x00, 0x02
                $ServiceResponse = Invoke-WebRequest -Uri "https://$RelayFQDN" -Method POST -ContentType "application/octet-stream" -Body $Payload -UserAgent (Get-UserAgent) -UseBasicParsing
                $LineWithRelayIP = ($ServiceResponse.RawContent -split "`n") | Where-Object {$_ -match '.*?(\d{1,3})-(\d{1,3})-(\d{1,3})-(\d{1,3})\.relay\.teams\.microsoft\.com.*'}
                if ($LineWithRelayIP) {
                    $RelayIP = $LineWithRelayIP -replace '.*?(\d{1,3})-(\d{1,3})-(\d{1,3})-(\d{1,3})\.relay\.teams\.microsoft\.com.*','$1.$2.$3.$4'
                    Write-Log -Message "Configuring TeamsNAT to use relay IP '$RelayIP'" -Source "TeamsNAT" -MessageType Info
                    ($configfile.configuration.appSettings.ChildNodes | Where-Object { $_.key -eq "Relay.IP" }).value = "$RelayIP"
                    $configfile.save($TeamsNATConfigFilePath)
                } else {
                    throw "Unable to get a valid relay IP from HTTPS"
                }
            } else {
                Write-Log -Message "Script does not have write access to TeamsNAT config file$(if (-not $RunningAsAdmin) {" (script is not running as administrator)"}), unable to set specific relay IP in the TeamsNAT config file" -Source "TeamsNAT" -MessageType Warning
                Write-Log -Message "Test calls will be carried over TCP even if UDP flows are allowed when no external DNS resolution is possible" -Source "TeamsNAT" -MessageType Warning
            }
        }
    } catch {
        Write-Log -Message "Failed to update the relay IP: $($_.Exception.Message)" -Source "TeamsNAT" -MessageType Error
        if ($ConfiguredRelayIP -notlike "") {
            Write-Log -Message "TeamsNAT will attempt to reuse previous IP '$ConfiguredRelayIP'" -Source "TeamsNAT" -MessageType Warning
        } else {
            Write-Log -Message "TeamsNAT will attempt to use '$RelayFQDN'" -Source "TeamsNAT" -MessageType Warning
        }
    }
}

function Get-LocalTime ($UTCTime, $Format) {
    # Identifies if in DST or not and adjusts the timestamp accordingly
    if ((Get-Date).IsDaylightSavingTime()) {
        $DSTOffset = 1
    } else {
        $DSTOffset = 0
    }
    $LocalTime = (Get-Date $UTCTime).AddHours((Get-TimeZone).BaseUtcOffset.TotalHours + $DSTOffset)
    $LocalTime = ($LocalTime).ToString($Format)
    return $LocalTime
}

function Set-WiresharkSettings {
    $Global:ErrorActionPreference = 'stop'
    try {
        $WiresharkConfigFolder = Join-Path -Path $env:APPDATA -ChildPath "Wireshark"
        if (-not (Test-Path $WiresharkConfigFolder)) {
            Write-Log -Message "Wireshark configuration folder not found, creating it" -Source "Init" -MessageType Info
            New-Item $WiresharkConfigFolder -type directory | Out-Null
        }

        ### Disabled protocols
        Write-Log -Message "Configuring Wireshark disabled protocols" -Source "Init" -MessageType Info
        $WiresharkDisabledProtocolsFile = Join-Path -Path $WiresharkConfigFolder -ChildPath "disabled_protos"
        $WiresharkDisabledProtocols = Get-Content -Path $WiresharkDisabledProtocolsFile -ErrorAction SilentlyContinue
        if ($null -eq $WiresharkDisabledProtocols) {
            $WiresharkDisabledProtocols = @()
        }
        if (-not ($WiresharkDisabledProtocols -match '^http$')) { $WiresharkDisabledProtocols += "http" }
        if (-not ($WiresharkDisabledProtocols -match '^http2$')) { $WiresharkDisabledProtocols += "http2" }
        if (-not ($WiresharkDisabledProtocols -match '^http3$')) { $WiresharkDisabledProtocols += "http3" }
        $WiresharkDisabledProtocols | Sort-Object | Set-Content -Path $WiresharkDisabledProtocolsFile

        ### Preferences
        Write-Log -Message "Configuring Wireshark preferences" -Source "Init" -MessageType Info
        $WiresharkPreferencesFile = Join-Path -Path $WiresharkConfigFolder -ChildPath "preferences"
        $WiresharkPreferences = Get-Content -Path $WiresharkPreferencesFile -ErrorAction SilentlyContinue
        if ($null -eq $WiresharkPreferences) {
            $WiresharkPreferences = @()
            $WiresharkPreferences += 'tcp.desegment_tcp_streams: TRUE'
            $WiresharkPreferences += 'tcp.reassemble_out_of_order: TRUE'
            $WiresharkPreferences += 'tcp.try_heuristic_first: TRUE'
            $WiresharkPreferences += 'tls.desegment_ssl_records: TRUE'
            $WiresharkPreferences += 'tls.desegment_ssl_application_data: TRUE'
        } else {
            $WiresharkPreferences = $WiresharkPreferences | ForEach-Object {
               if ($_ -match 'tcp.desegment_tcp_streams') { $_ -replace '.*tcp.desegment_tcp_streams.*','tcp.desegment_tcp_streams: TRUE' }
               elseif ($_ -match 'tcp.reassemble_out_of_order') { $_ -replace '.*tcp.reassemble_out_of_order.*','tcp.reassemble_out_of_order: TRUE' }
               elseif ($_ -match 'tcp.try_heuristic_first') { $_ -replace '.*tcp.try_heuristic_first.*','tcp.try_heuristic_first: TRUE' }
               elseif ($_ -match 'tls.desegment_ssl_records') { $_ -replace '.*tls.desegment_ssl_records.*','tls.desegment_ssl_records: TRUE' }
               elseif ($_ -match 'tls.desegment_ssl_application_data') { $_ -replace '.*tls.desegment_ssl_application_data.*','tls.desegment_ssl_application_data: TRUE' }
               else { $_ }
            }
        }
        $WiresharkPreferences | Set-Content -Path $WiresharkPreferencesFile
    } catch {
        Write-Log -Message "Error configuring Wireshark settings ($($_.Exception.Message))" -Source "Init" -MessageType Error
    }
    $Global:ErrorActionPreference = 'continue'
}

function Start-NetworkTrace {
    Param(
        [parameter(mandatory = $true)]
        [ValidateSet("DNSLookup", "EXO", "Teams", "SPO", "Viva", "Copilot", "MicrosoftDomain", "FileTransfer")]
        $Workload,
        [parameter(mandatory = $true)]
        $OutputFile,
        [parameter(mandatory = $false)]
        $Port,
        [parameter(mandatory = $false)]
        $TargetInterface
    )

    $ErrorActionPreference = 'SilentlyContinue'
    $ProgressPreference = "SilentlyContinue"

    Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null

    # Fetching settings
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $WiresharkPath = $CurrentSettings.WiresharkPath
    $CaptureTool = $CurrentSettings.CaptureTool[1]
    $CaptureScenario = $CurrentSettings.CaptureScenario[1]
    $DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}
    $WindowStyle = if ($DebugMode) { "Normal" } else { "Hidden" }

    $LogType = Switch ($Workload) {
        "FileTransfer" {"FileTransfer - SPO $($OutputFile -replace '.*-(.*)\..*','$1')"}
        "DNSLookup" {"DNSLookup"}
        "EXO" {"EXO"}
        "Teams" {"Teams"}
        "SPO" {"SPO"}
        "Viva" {"Viva"}
        "Copilot" {"Copilot - $($OutputFile -replace '.*-Copilot(.*)\..*','$1')"}
        "MicrosoftDomain" {"MicrosoftDomain - $($OutputFile -replace '.*-(.*Microsoft)\..*','$1')"}
    }

    Stop-AllNetworkTraces -LogType $LogType
    
    if (-not $TargetInterface -or $Workload -eq "DNSLookup" -or $CaptureTool -eq "Netsh") {
        if (-not $TargetInterface) {
        $Reason = "No interface specified"
        } elseif ($Workload -eq "DNSLookup") {
            $Reason = "DNS Trace"
        } elseif ($CaptureTool -eq "Netsh") {
            $Reason = "Netsh capture"
        } elseif ($DebugMode) {
            $Reason = "Debug mode"
        } else {
            $Reason = "Default"
        }
        $CaptureOnAllInterfaces = $true
    } else {
        if (-not (Test-Path "$WiresharkPath\tshark.exe")) {
            # Avoid collecting traces on all interfaces if filtering will not be possible (tshark.exe is not found)
            $CaptureOnAllInterfaces = $false
        } else {
            $Reason = "Default"
            $CaptureOnAllInterfaces = $true
        }
    }

    if ($CaptureOnAllInterfaces) {
        Write-Log -Message "Collecting traces on all available interfaces ($Reason)" -Source "$LogType" -MessageType Info
        switch ($CaptureTool) {
            "Wireshark" {
                $DumpcapAdapters = & "$WiresharkPath\dumpcap.exe" -D | Where-Object {$_ -match "\\Device\\NPF"}
                [array]$TAdapters = @()
                foreach ($Adapter in $DumpcapAdapters) { $TAdapters += $Adapter.split(".")[0] } # Capture on all available interfaces
                [string]$Interfaces = $null
                for ($TAdapt = 0; $TAdapt -lt $TAdapters.count; $TAdapt++) {
                    if ($TAdapt -gt 0) { $Interfaces = $Interfaces + ' ' }
                    $Interfaces = $Interfaces + '-i ' + $TAdapters[$TAdapt]
                }
            }
            "Netmon" { $Interfaces  = "*" }
            "Netsh" { $Interfaces = "" }
        }
    } else {
        Write-Log -Message "Collecting traces on the following interface: (id - type - name - description)" -Source "$LogType" -MessageType Info
        # Gathering interfaces list
        $NetworkInterfaces = [System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()
        $NicToUse = $NetworkInterfaces | Where-Object { $_.Name -like $TargetInterface }
        Write-Log -Message "$($NicToUse.Id) - $($NicToUse.NetworkInterfaceType) - $($NicToUse.Name) - $($NicToUse.Description)" -Source "$LogType" -MessageType Info
        switch ($CaptureTool) {
            "Wireshark" {
                $DumpcapAdapters = & "$WiresharkPath\dumpcap.exe" -D | Where-Object {$_ -match "\\Device\\NPF"}
                $InterfaceToUse = $DumpcapAdapters | Select-String -Pattern $NicToUse.id | Select-Object -ExpandProperty Line
                if ($InterfaceToUse) {
                    $Interfaces = "-i " + $InterfaceToUse.split(".")[0]
                } else {
                    Write-Log -Message "Unable to find the corresponding interface in Wireshark" -Source "$LogType" -MessageType Warning
                    Write-Log -Message "Falling back to collecting traces on all available interfaces" -Source "$LogType" -MessageType Warning
                    $DumpcapAdapters = & "$WiresharkPath\dumpcap.exe" -D | Where-Object {$_ -match "\\Device\\NPF"}
                    [array]$TAdapters = @()
                    foreach ($Adapter in $DumpcapAdapters) { $TAdapters += $Adapter.split(".")[0] } # Capture on all available interfaces
                    [string]$Interfaces = $null
                    for ($TAdapt = 0; $TAdapt -lt $TAdapters.count; $TAdapt++) {
                        if ($TAdapt -gt 0) { $Interfaces = $Interfaces + ' ' }
                        $Interfaces = $Interfaces + '-i ' + $TAdapters[$TAdapt]
                    }
                }
            }
            "Netmon" {$Interfaces  = '"' + $TargetInterface + '"'}
            "Netsh" { $Interfaces = 'CaptureInterface="' + $TargetInterface + '"' }
        }
    }

    if ($CaptureTool -eq "Netsh") { $OutputFile = $OutputFile -replace '\.pcapng','.etl' }

    switch ($CaptureScenario) {
        "Netskope" {
            if ((Get-Service | Where-Object { $_.DisplayName -match "Netskope Client" }).Status -eq "Running") {
                Write-Log -Message "Starting Netskope trace with line: nsdiag.exe -c start -o $((Split-Path -Path $OutputFile -Leaf) -replace '\.pcapng','.pcap')" -Source "$LogType" -MessageType Info
                Start-Process "C:\Program Files (x86)\netskope\stagent\nsdiag.exe" -ArgumentList " -c start -o $((Split-Path -Path $OutputFile -Leaf) -replace '\.pcapng','.pcap')" -NoNewWindow
            } else {
                Write-Log -Message "Unable to start Netskope trace as the Netskope client is not running" -Source "$LogType" -MessageType Warning
            }
        }
        "Zscaler - encrypted tunnel" {
            Write-Log -Message "Removing previous Zscaler network capture files" -Source "$LogType" -MessageType Info
            Get-ChildItem -Path "$env:ProgramData\Zscaler" -Recurse | Where-Object { $_.Name -match "\.pcap" } | Remove-Item -Force -ErrorAction SilentlyContinue
            Write-Log -Message "Prompting user to manually start the Zscaler network capture" -Source "$LogType" -MessageType Info
            $Message = "Please manually start a network capture within Zscaler application:`r`n`r`n"
            $Message += "1. In Zscaler Client Connector, click 'More'`r`n"
            $Message += "2. In the 'Troubleshoot' menu, click 'Start Packet Capture'`r`n"
            $Message += "3. Click 'OK' when the packet capture has been started`r`n"
            $UserAnswer = New-Popup -Title "Zscaler Manual Network Trace" -Message $Message -Buttons "Ok" -Icon Information -Time 120
            if ($UserAnswer -eq 1) {
                Write-Log -Message "User comfirmed that Zscaler packet capture has been started" -Source "$LogType" -MessageType Info
            } else {
                Write-Log -Message "User did NOT comfirm that Zscaler packet capture has been started" -Source "$LogType" -MessageType Warning
            }
        }
    }
    
    switch ($Workload) {
        "FileTransfer" {
            Write-Log -Message "Collecting file transfer trace" -Source "$LogType" -MessageType Info
            switch ($CaptureTool) {
                "Wireshark" { $ArgumentList = '-a duration:600 -a filesize:200000 -p -f "tcp or udp" -s 250 -B 16384 -w "' + $OutputFile + '" ' + $Interfaces }
                "Netmon" { $ArgumentList = '/TerminateWhen /Timeafter 600 sec /Capture "tcp or udp" /MaxFrameLength 250 /File "' + $OutputFile + '":200M /Network ' + "$Interfaces" +  ' /TerminateWhen /Frame (DNS.QRecord.QuestionName.Contains('+ "'stopnetmontrace')) /DisableConversations" }
                "Netsh" { $ArgumentList = 'PacketTruncateBytes=250 traceFile="' + $OutputFile + '" ' + $Interfaces }
            }
        }
        "DNSLookup" {
            Write-Log -Message "Collecting DNS lookup trace" -Source "$LogType" -MessageType Info
            switch ($CaptureTool) {
                "Wireshark" { $ArgumentList = '-a duration:120 -a filesize:50000 -p -f "port 53" -w "' + $OutputFile + '" ' + $Interfaces }
                "Netmon" { $ArgumentList = '/TerminateWhen /Timeafter 120 sec /Capture "dns" /File "' + $OutputFile + '":50M /Network ' + "$Interfaces" +  ' /TerminateWhen /Frame (DNS.QRecord.QuestionName.Contains('+ "'stopnetmontrace')) /DisableConversations" }
                "Netsh" { $ArgumentList = 'PacketTruncateBytes=65535 traceFile="' + $OutputFile + '" ' + $Interfaces }
            }
        }
        {$_ -in "EXO","Teams","SPO","Viva","Copilot","MicrosoftDomain"} {
            Write-Log -Message "Collecting $_ trace" -Source "$LogType" -MessageType Info
            switch ($CaptureTool) {
                "Wireshark" { $ArgumentList = '-a duration:120 -a filesize:50000 -p -f "port 53 or tcp" -w "' + $OutputFile + '" ' + $Interfaces }
                "Netmon" { $ArgumentList = '/TerminateWhen /Timeafter 120 sec /Capture "dns or tcp" /File "' + $OutputFile + '":50M /Network ' + "$Interfaces" +  ' /TerminateWhen /Frame (DNS.QRecord.QuestionName.Contains('+ "'stopnetmontrace')) /DisableConversations" }
                "Netsh" { $ArgumentList = 'PacketTruncateBytes=65535 traceFile="' + $OutputFile + '" ' + $Interfaces }
            }
        }
    }
    
    switch ($CaptureTool) {
        "Wireshark" {
            Write-Log -Message "Starting Wireshark trace with line: dumpcap.exe $ArgumentList" -Source "$LogType" -MessageType Info
            Start-Process "$WiresharkPath\dumpcap.exe" -ArgumentList $ArgumentList -WindowStyle $WindowStyle
        }
        "Netmon" {
            Write-Log -Message "Starting Netmon trace with line: nmcap $ArgumentList" -Source "$LogType" -MessageType Info
            Start-Process nmcap -ArgumentList $ArgumentList -WindowStyle $WindowStyle
        }
        "Netsh" {
            $HyperVStatus = Get-WindowsOptionalFeature -FeatureName Microsoft-Hyper-V-All -Online
            if ($HyperVStatus.State -ne "Enabled") {
                Write-Log -Message "Starting Netsh trace with line: Netsh trace start capture=yes captureType=physical Ethernet.Type=IPv4 Protocol=`"(TCP,UDP)`" $ArgumentList" -Source "$LogType" -MessageType Info
                Invoke-Expression ('Netsh trace start capture=yes captureType=physical Ethernet.Type=IPv4 Protocol="(TCP,UDP)" ' + $ArgumentList) | Out-Null
            } else {
                Write-Log -Message "Starting Netsh trace with line: Netsh trace start capture=yes captureType=both Ethernet.Type=IPv4 Protocol=`"(TCP,UDP)`" $ArgumentList" -Source "$LogType" -MessageType Info
                Invoke-Expression ('Netsh trace start capture=yes captureType=both Ethernet.Type=IPv4 Protocol="(TCP,UDP)" ' + $ArgumentList) | Out-Null
            }
        }
    }
    
    Write-Log -Message "Waiting for network trace to start" -Source "$LogType" -MessageType Info
    $TimeoutTimestamp = (Get-Date).AddMinutes(1)
    switch ($CaptureTool) {
        "Wireshark" { do { Start-Sleep -Seconds 1 } while ( (Get-Process dumpcap -ErrorAction SilentlyContinue | Measure-Object).count -eq 0 -and ((Get-Date) -lt $TimeoutTimestamp) ) }
        "Netmon" { do { Start-Sleep -Seconds 1 } while ( (Get-Process nmcap -ErrorAction SilentlyContinue | Measure-Object).count -eq 0 -and ((Get-Date) -lt $TimeoutTimestamp) ) }
        "Netsh" { do { Start-Sleep -Seconds 1 } while ( (Netsh trace show status | Measure-Object).count -lt 4 -and ((Get-Date) -lt $TimeoutTimestamp) ) }
    }

    if ((Get-Date) -ge $TimeoutTimestamp) {
        throw "Failed to start network trace"
    }
    Write-Log -Message "Network trace has been started, sleeping to capture some initial traffic" -Source "$LogType" -MessageType Info
    Start-Sleep -Seconds 5

}

function Stop-NetworkTrace {
    Param(
        [parameter(mandatory = $true)]
        [ValidateSet("DNSLookup", "EXO", "Teams", "SPO", "Viva", "Copilot", "MicrosoftDomain", "FileTransfer")]
        $Workload,
        [parameter(mandatory = $true)]
        $OutputFile
    )

    $ErrorActionPreference = 'SilentlyContinue'
    $ProgressPreference = "SilentlyContinue"

    Import-Module $env:NPAPath\Scripts\DataCollection.psm1 -Force -DisableNameChecking | Out-Null

    # Fetching settings
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $Outputpath = $CurrentSettings.OutputPath
    $OutputPathUnfilteredTraces = Join-Path -Path $OutputPath -ChildPath "UnfilteredTraces"
    $WiresharkPath = $CurrentSettings.WiresharkPath
    $CaptureTool = $CurrentSettings.CaptureTool[1]
    $CaptureScenario = $CurrentSettings.CaptureScenario[1]
    $DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}

    $LogType = Switch ($Workload) {
        "FileTransfer" {"FileTransfer - SPO $($OutputFile -replace '.*-(.*)\..*','$1')"}
        "DNSLookup" {"DNSLookup"}
        "EXO" {"EXO"}
        "Teams" {"Teams"}
        "SPO" {"SPO"}
        "Viva" {"Viva"}
        "Copilot" {"Copilot - $($OutputFile -replace '.*-Copilot(.*)\..*','$1')"}
        "MicrosoftDomain" {"MicrosoftDomain - $($OutputFile -replace '.*-(.*Microsoft)\..*','$1')"}
    }

    Write-Log -Message "Waiting a few seconds and stopping network trace" -Source "$LogType" -MessageType Info
    Start-Sleep -seconds 5
    switch ($CaptureTool) {
        "Wireshark" {
            Stop-RunningProcess -ProcessName "wireshark|dumpcap|tshark"
        }
        "Netmon" {
            Resolve-DnsName -Name "stopnetmontrace.microsoft.com" -Type A -DnsOnly -QuickTimeout -ErrorAction SilentlyContinue | Out-Null
            do { Start-Sleep -Seconds 1 } while ( (Get-Process nmcap -ErrorAction SilentlyContinue | Measure-Object).count -ne 0 )
            Start-Sleep -Seconds 1
            Write-Log -Message "Changing file extension from '.cap' to '.pcapng'" -Source "$LogType" -MessageType Info
            Move-Item -Path ($OutputFile -replace '\.pcapng','.cap') -Destination $OutputFile
        }
        "Netsh" {
            try { netsh trace stop  | ForEach-Object { break } } catch {}
            Start-Sleep -Seconds 2
            Write-Log -Message "Converting file from '.etl' to '.pcapng'" -Source "$LogType" -MessageType Info
            $Process = Start-Process "$env:NPAPath\Scripts\etl2pcapng.exe" -ArgumentList "`"$($OutputFile -replace '\.pcapng','.etl')`" `"$OutputFile`"" -PassThru
            while ($Process.HasExited -ne $true) { Start-Sleep -Seconds 1 }
            if (Test-Path $OutputFile) {
                Write-Log -Message "Removing '.etl' file" -Source "$LogType" -MessageType Info
                Remove-Item -Path ($OutputFile -replace '\.pcapng','.etl') -Force -ErrorAction SilentlyContinue
            } else {
                Write-Log -Message "Failed to convert file (pcapng file not found)" -Source "$LogType" -MessageType Error
            }
        }
    }

    switch ($CaptureScenario) {
        "Netskope" {
            if ((Get-Service | Where-Object { $_.DisplayName -match "Netskope Client" }).Status -eq "Running") {
                Write-Log -Message "Stopping Netskope packet trace" -Source "$LogType" -MessageType Info
                Start-Process "C:\Program Files (x86)\netskope\stagent\nsdiag.exe" -ArgumentList " -c stop" -NoNewWindow
                Start-Sleep -Seconds 2
                $NetskopeTraceFilePath = Get-ChildItem -Path "C:\ProgramData\netskope\stagent\Logs" | Where-Object { $_.Name -eq ((Split-Path -Path $OutputFile -Leaf) -replace '\.pcapng','.pcap') } | Select-Object -ExpandProperty FullName
                # Attempt to find Netskope trace file in the old location
                if (-not $NetskopeTraceFilePath) {$NetskopeTraceFilePath = Get-ChildItem -Path "C:\Users\*\netSkope\*" | Where-Object { $_.Name -eq ((Split-Path -Path $OutputFile -Leaf) -replace '\.pcapng','.pcap') } | Select-Object -ExpandProperty FullName }
                if ($NetskopeTraceFilePath) {
                    Write-Log -Message "Netskope packet capture file found, starting to process file: '$NetskopeTraceFilePath'" -Source "$LogType" -MessageType Info
                    $NetskopeTraceRawFilePath = $OutputFile -replace '\.pcapng','-netskope-raw.pcap'
                    Copy-Item -Path $NetskopeTraceFilePath -Destination $NetskopeTraceRawFilePath -Force
                    Write-Log -Message "Converting pcap file to pcapng" -Source "$LogType" -MessageType Info
                    $NetskopeTraceProcessedFilePath = $OutputFile -replace '\.pcapng','-netskope-processed.pcapng'
                    Start-Process "$WiresharkPath\editcap.exe" -ArgumentList ($NetskopeTraceRawFilePath,$NetskopeTraceProcessedFilePath,"-F pcapng") -NoNewWindow
                    Start-Sleep -Milliseconds 200
                    $NetskopeTraceProcessedFileSizeBeforeProcessing = [math]::Round((Get-Item -Path $NetskopeTraceProcessedFilePath).Length/1KB)
                    Write-Log -Message "Identifying packets to add comments on" -Source "$LogType" -MessageType Info
                    $Filter = 'dns || tcp.flags.syn == 1 || tcp.flags.fin == 1 || tcp.flags.reset == 1 || tcp.payload matches \"\x16\x03(\x01|\x02|\x03)[\x00-\xFF]{2}(\x01|\x02)\"'
                    $Packets = & "$WiresharkPath\tshark.exe" -r "$NetskopeTraceProcessedFilePath" -Y $Filter -T fields -e frame.time_epoch -e frame.number -e frame.interface_name -e frame.interface_description -e ip.src -e ip.dst `
                        -e tcp.srcport -e tcp.dstport -e udp.srcport -e udp.dstport -e dns.flags.response -e dns.qry.name -e tcp.payload `
                        -o tcp.analyze_sequence_numbers:FALSE -o tls.keylog_file:null -E separator=';' -2 | `
                        Sort-Object | ConvertFrom-Csv -Delimiter ';' -Header "AbsoluteTime","PacketNumber","InterfaceID","InterfaceName","SourceIP","DestinationIP" `
                        ,"TCPSourcePort","TCPDestinationPort","UDPSourcePort","UDPDestinationPort","DnsFlagResponse","DnsQueryName","TCPPayload","TCPPayloadASCII"
                    $NumberOfPackets = ($Packets | Measure-Object).count
                    if ($NumberOfPackets -gt 0) {
                        Write-Log -Message "Adding comment to $NumberOfPackets packets" -Source "$LogType" -MessageType Info
                        foreach ($PacketNumber in $Packets.PacketNumber) {
                            Write-Log -Message "Processing packet $PacketNumber" -Source "$LogType" -MessageType Info
                            Start-Process "$WiresharkPath\editcap.exe" -ArgumentList ($NetskopeTraceProcessedFilePath,$NetskopeTraceProcessedFilePath,"-a $($PacketNumber):NetskopeTunnel") -NoNewWindow
                            Start-Sleep -Milliseconds 200
                        }
                    } else {
                        Write-Log -Message "Found no packets to add comments on" -Source "$LogType" -MessageType Warning
                    }
                    $NetskopeTraceProcessedFileSizeAfterProcessing = [math]::Round((Get-Item -Path $NetskopeTraceProcessedFilePath).Length/1KB)
                    if ($NetskopeTraceProcessedFileSizeAfterProcessing -lt $NetskopeTraceProcessedFileSizeBeforeProcessing) {
                        Write-Log -Message "Processed file is smaller ($($NetskopeTraceProcessedFileSizeAfterProcessing)kb) than the unprocessed file ($($NetskopeTraceProcessedFileSizeBeforeProcessing)kb), discarding the processed file for merging" -Source "$LogType" -MessageType Warning
                        Start-Process "$WiresharkPath\editcap.exe" -ArgumentList ($NetskopeTraceRawFilePath,$NetskopeTraceProcessedFilePath,"-F pcapng") -NoNewWindow
                        Start-Sleep -Milliseconds 200
                    }
                    $MergedFilePath = $OutputFile -replace '\.pcapng','-merged.pcapng'
                    if ($Workload -match "FileTransfer") {
                        Write-Log -Message "Merging original and Netskope processed trace files (and limiting packet size)" -Source "$LogType" -MessageType Info
                        $Process = Start-Process "$WiresharkPath\mergecap.exe" -ArgumentList (' -s 250 -w "' + $MergedFilePath + '" "' + $OutputFile + '" "' + $NetskopeTraceProcessedFilePath + '"') -PassThru
                    } else {
                        Write-Log -Message "Merging original and Netskope processed trace files" -Source "$LogType" -MessageType Info
                        $Process = Start-Process "$WiresharkPath\mergecap.exe" -ArgumentList (' -w "' + $MergedFilePath + '" "' + $OutputFile + '" "' + $NetskopeTraceProcessedFilePath + '"') -PassThru
                    }
                    while ($Process.HasExited -ne $true) { Start-Sleep -Seconds 1 }
                    Write-Log -Message "Removing Netskope original trace file" -Source "$LogType" -MessageType Info
                    Remove-Item -Path $NetskopeTraceFilePath -Force -ErrorAction SilentlyContinue
                    if ($DebugMode) {
                        Write-Log -Message "Moving Netskope unprocessed trace file to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Info
                        Move-Item -Path $NetskopeTraceRawFilePath -Destination $OutputPathUnfilteredTraces
                        Write-Log -Message "Moving Netskope processed trace file to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Info
                        Move-Item -Path $NetskopeTraceProcessedFilePath -Destination $OutputPathUnfilteredTraces
                    } else {
                        Write-Log -Message "Removing Netskope unprocessed trace file" -Source "$LogType" -MessageType Info
                        Remove-Item -Path $NetskopeTraceRawFilePath -Force
                        Write-Log -Message "Removing Netskope processed trace file" -Source "$LogType" -MessageType Info
                        Remove-Item -Path $NetskopeTraceProcessedFilePath -Force
                    }
                    if (Test-Path $MergedFilePath) {
                        $OutputFileSize = [math]::Round((Get-Item -Path $OutputFile).Length/1KB)
                        $MergedFileSize = [math]::Round((Get-Item -Path $MergedFilePath).Length/1KB)
                        if ($MergedFileSize -lt $OutputFileSize) {
                            Write-Log -Message "Merged file is smaller ($($MergedFileSize)kb) than the original output file ($($OutputFileSize)kb), discarding the merged file" -Source "$LogType" -MessageType Error
                            if ($DebugMode) {
                                Write-Log -Message "Moving bogus merged trace file to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Error
                                Move-Item -Path $MergedFilePath -Destination $OutputPathUnfilteredTraces
                            } else {
                                Write-Log -Message "Removing bogus merged trace file" -Source "$LogType" -MessageType Error
                                Remove-Item -Path $MergedFilePath -Force
                            }
                        } else {
                            if ($DebugMode) {
                                Write-Log -Message "Renaming original trace file and moving it to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Info
                                $RenamedFilePath = $OutputFile -replace '\.pcapng','-original.pcapng'
                                Move-Item -Path $OutputFile -Destination $RenamedFilePath
                                Move-Item -Path $RenamedFilePath -Destination $OutputPathUnfilteredTraces
                            } else {
                                Write-Log -Message "Removing original trace file" -Source "$LogType" -MessageType Info
                                Remove-Item -Path $OutputFile -Force
                            }
                            Write-Log -Message "Renaming merged trace file to original name" -Source "$LogType" -MessageType Info
                            Move-Item -Path $MergedFilePath -Destination $OutputFile                            
                        }
                    } else {
                        Write-Log -Message "Merged trace not found, skipping further trace manipulation" -Source "$LogType" -MessageType Error
                    }
                } else {
                    Write-Log -Message "No Netskope packet capture file has been found, skipping trace merge" -Source "$LogType" -MessageType Error
                }
            } else {
                Write-Log -Message "Unable to merge original and Netskope traces as the Netskope client is not running" -Source "$LogType" -MessageType Warning
            }
        }
        "Zscaler - encrypted tunnel" {
            Write-Log -Message "Prompting user to manually stop the Zscaler network capture" -Source "$LogType" -MessageType Info
            $Message = "Please manually stop the network capture within Zscaler application:`r`n`r`n"
            $Message += "1. In Zscaler Client Connector, click 'More'.`r`n"
            $Message += "2. In the 'Troubleshoot' menu, click 'Stop Packet Capture'.`r`n"
            $Message += "3. Click 'OK' when the packet capture has been stopped`r`n"
            $UserAnswer = New-Popup -Title "Zscaler Manual Network Trace" -Message $Message -Buttons "Ok" -Icon Information -Time 120
            if ($UserAnswer -eq 1) {
                Write-Log -Message "User comfirmed that Zscaler packet capture has been stopped" -Source "$LogType" -MessageType Info
                $ZscalerTraceFilePath = Get-ChildItem -Path "$env:ProgramData\Zscaler" -Recurse | Where-Object { $_.Name -match "CaptureLWF.*\.pcap" } | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName
                if ($ZscalerTraceFilePath) {
                    Write-Log -Message "Zscaler packet capture file found, starting to process file: $ZscalerTraceFilePath" -Source "$LogType" -MessageType Info
                    $ZscalerTraceRawFilePath = $OutputFile -replace '\.pcapng','-zscaler-raw.pcapng'
                    Copy-Item -Path $ZscalerTraceFilePath -Destination $ZscalerTraceRawFilePath -Force
                    $ZscalerTraceProcessedFilePath = $OutputFile -replace '\.pcapng','-zscaler-processed.pcapng'
                    $Process = Start-Process "$WiresharkPath\tshark.exe" -ArgumentList ('-r "' + $ZscalerTraceFilePath + '" -q -Y "!(frame.comment == "ORIGINAL_PACKET")" -w "' + $ZscalerTraceProcessedFilePath + '" -o tls.keylog_file:null') -PassThru
                    while ($Process.HasExited -ne $true) { Start-Sleep -Seconds 1 }
                    $MergedFilePath = $OutputFile -replace '\.pcapng','-merged.pcapng'
                    if ($Workload -match "FileTransfer") {
                        Write-Log -Message "Merging original and Zscaler processed trace files (and limiting packet size)" -Source "$LogType" -MessageType Info
                        $Process = Start-Process "$WiresharkPath\mergecap.exe" -ArgumentList (' -s 250 -w "' + $MergedFilePath + '" "' + $OutputFile + '" "' + $ZscalerTraceProcessedFilePath + '"') -PassThru
                    } else {
                        Write-Log -Message "Merging original and Zscaler processed trace files" -Source "$LogType" -MessageType Info
                        $Process = Start-Process "$WiresharkPath\mergecap.exe" -ArgumentList (' -w "' + $MergedFilePath + '" "' + $OutputFile + '" "' + $ZscalerTraceProcessedFilePath + '"') -PassThru
                    }
                    while ($Process.HasExited -ne $true) { Start-Sleep -Seconds 1 }
                    Write-Log -Message "Removing Zscaler original trace file" -Source "$LogType" -MessageType Info
                    Remove-Item -Path $ZscalerTraceFilePath -Force -ErrorAction SilentlyContinue
                    if ($DebugMode) {
                        Write-Log -Message "Moving Zscaler unprocessed trace file to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Info
                        Move-Item -Path $ZscalerTraceRawFilePath -Destination $OutputPathUnfilteredTraces
                        Write-Log -Message "Moving Zscaler processed trace file to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Info
                        Move-Item -Path $ZscalerTraceProcessedFilePath -Destination $OutputPathUnfilteredTraces
                    } else {
                        Write-Log -Message "Removing Zscaler unprocessed trace file" -Source "$LogType" -MessageType Info
                        Remove-Item -Path $ZscalerTraceRawFilePath -Force
                        Write-Log -Message "Removing Zscaler processed trace file" -Source "$LogType" -MessageType Info
                        Remove-Item -Path $ZscalerTraceProcessedFilePath -Force
                    }
                    if (Test-Path $MergedFilePath) {
                        $OutputFileSize = [math]::Round((Get-Item -Path $OutputFile).Length/1KB)
                        $MergedFileSize = [math]::Round((Get-Item -Path $MergedFilePath).Length/1KB)
                        if ($MergedFileSize -lt $OutputFileSize) {
                            Write-Log -Message "Merged file is smaller ($($MergedFileSize)kb) than the original output file ($($OutputFileSize)kb), discarding the merged file" -Source "$LogType" -MessageType Error
                            if ($DebugMode) {
                                Write-Log -Message "Moving bogus merged trace file to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Error
                                Move-Item -Path $MergedFilePath -Destination $OutputPathUnfilteredTraces
                            } else {
                                Write-Log -Message "Removing bogus merged trace file" -Source "$LogType" -MessageType Error
                                Remove-Item -Path $MergedFilePath -Force
                            }
                        } else {
                            if ($DebugMode) {
                                Write-Log -Message "Renaming original trace file and moving it to UnfilteredTraces sub-folder" -Source "$LogType" -MessageType Info
                                $RenamedFilePath = $OutputFile -replace '\.pcapng','-original.pcapng'
                                Move-Item -Path $OutputFile -Destination $RenamedFilePath
                                Move-Item -Path $RenamedFilePath -Destination $OutputPathUnfilteredTraces
                            } else {
                                Write-Log -Message "Removing original trace file" -Source "$LogType" -MessageType Info
                                Remove-Item -Path $OutputFile -Force
                            }
                            Write-Log -Message "Renaming merged trace file to original name" -Source "$LogType" -MessageType Info
                            Move-Item -Path $MergedFilePath -Destination $OutputFile                            
                        }
                    } else {
                        Write-Log -Message "Merged trace not found, skipping further trace manipulation" -Source "$LogType" -MessageType Error
                    }
                } else {
                    Write-Log -Message "No Zscaler packet capture file has been found, skipping trace merge" -Source "$LogType" -MessageType Error
                }
            } else {
                Write-Log -Message "User did NOT comfirm that Zscaler packet capture has been stopped, skipping trace merge" -Source "$LogType" -MessageType Warning
            }
        }
    }
    Write-Log -Message "All network traces have been stopped" -Source "$LogType" -MessageType Info

}

function Stop-AllNetworkTraces {
    Param (
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $LogType
    )

    # Fetching settings
    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $CaptureTool = $CurrentSettings.CaptureTool[1]
    $CaptureScenario = $CurrentSettings.CaptureScenario[1]

    Write-Log -Message "Stopping all network traces" -Source "$LogType" -MessageType Info
    switch ($CaptureTool) {
        "Wireshark" { Stop-RunningProcess -ProcessName "wireshark|dumpcap|tshark" }
        "Netmon" { Stop-RunningProcess -ProcessName "nmcap" }
        "Netsh" { try { netsh trace stop  | ForEach-Object { break } } catch {} }
    }

    switch ($CaptureScenario) {
        "Netskope" {
            if ((Get-Service | Where-Object { $_.DisplayName -match "Netskope Client" }).Status -eq "Running") {
                Start-Process "C:\Program Files (x86)\netskope\stagent\nsdiag.exe" -ArgumentList " -c stop" -NoNewWindow
                Start-Sleep -Seconds 1
            }
        }
    }
    Write-Log -Message "All network traces have been stopped" -Source "$LogType" -MessageType Info

}

function Find-InterfaceUsedForQueries {
    Param (
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [Object[]] $Packets
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [ValidateSet("DNSLookup","EXO","Teams","SPO","Viva","Copilot","MicrosoftDomain")]
        [String] $Workload
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $LogType
    )

    $InterfaceFilter = $null

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $CaptureScenario = $CurrentSettings.CaptureScenario[1]
    $OneDriveFQDN = $CurrentSettings.OneDriveFQDN
    if ($OneDriveFQDN -like "") {
		$OneDriveFQDN = "microsoft-my.sharepoint.com"
	}

    Write-Log -Message "Finding the interface used to send $Workload queries" -Source "$LogType" -MessageType Info

    # Find first non-loopback (127.0.01) / non cloud proxy tunnel (100.64.x.x) query
    switch ($Workload) {
        # Find first DNS query to O365
        "DNSLookup" { $FirstQuery = ($Packets | Where-Object {$_.DnsQueryName -match "outlook|teams|sharepoint|spo-ring.msedge.net|$OneDriveFQDN|yammer|viva|copilot|m365|substrate|augloop|cloud.microsoft|static.microsoft|usercontent.microsoft" -and ($_.DnsFlagResponse -eq 0 -or $_.DnsFlagResponse -eq $false) -and $_.DestinationIP -ne "127.0.0.1" -and $_.DestinationIP -notlike "100.64.*" -and $_.SourceIP -notlike "100.64.*"}) | Select-Object -First 1 }
        # Find first TLS Handshake to the workload
        "EXO" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "outlook" -and $_.DestinationIP -ne "127.0.0.1" -and $_.DestinationIP -notlike "100.64.*" -and $_.SourceIP -notlike "100.64.*"}) | Select-Object -First 1 }
        "Teams" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "teams" -and $_.DestinationIP -ne "127.0.0.1" -and $_.DestinationIP -notlike "100.64.*" -and $_.SourceIP -notlike "100.64.*"}) | Select-Object -First 1 }
        "SPO" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "sharepoint|spo-ring.msedge.net|$OneDriveFQDN" -and $_.DestinationIP -ne "127.0.0.1" -and $_.DestinationIP -notlike "100.64.*" -and $_.SourceIP -notlike "100.64.*"}) | Select-Object -First 1 }
        "Viva" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "yammer|viva" -and $_.DestinationIP -ne "127.0.0.1" -and $_.DestinationIP -notlike "100.64.*" -and $_.SourceIP -notlike "100.64.*"}) | Select-Object -First 1 }
        "Copilot" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "copilot|m365|substrate|augloop" -and $_.DestinationIP -ne "127.0.0.1" -and $_.DestinationIP -notlike "100.64.*" -and $_.SourceIP -notlike "100.64.*"}) | Select-Object -First 1 }
        "MicrosoftDomain" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "cloud.microsoft|static.microsoft|usercontent.microsoft" -and $_.DestinationIP -ne "127.0.0.1" -and $_.DestinationIP -notlike "100.64.*" -and $_.SourceIP -notlike "100.64.*"}) | Select-Object -First 1 }
    }
    if (-not $FirstQuery) {
        Write-Log -Message "No non-loopback / non-cloud proxy tunnel $Workload query found, checking with loopback / cloud proxy tunnel included" -Source "$LogType" -MessageType Info
        switch ($Workload) {
            "DNSLookup" { $FirstQuery = ($Packets | Where-Object {$_.DnsQueryName -match "outlook|teams|sharepoint|spo-ring.msedge.net|$OneDriveFQDN|yammer|viva|copilot|m365|substrate|augloop|cloud.microsoft|static.microsoft|usercontent.microsoft" -and ($_.DnsFlagResponse -eq 0 -or $_.DnsFlagResponse -eq $false)}) | Select-Object -First 1 }
            "EXO" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "outlook"}) | Select-Object -First 1 }
            "Teams" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "teams"}) | Select-Object -First 1 }
            "SPO" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "sharepoint|spo-ring.msedge.net|$OneDriveFQDN"}) | Select-Object -First 1 }
            "Viva" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "yammer|viva"}) | Select-Object -First 1 }
            "Copilot" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "copilot|m365|substrate|augloop"}) | Select-Object -First 1 }
            "MicrosoftDomain" { $FirstQuery = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "cloud.microsoft|static.microsoft|usercontent.microsoft"}) | Select-Object -First 1 }
        }
    } else {
        Write-Log -Message "At least one non-loopback $Workload query found" -Source "$LogType" -MessageType Info
    }

    if ($FirstQuery) {
        # Find the packets sent by each available interface for this query
        $PacketsForQuery = $null
        switch ($Workload) {
            "DNSLookup" { $PacketsForQuery = $Packets | Where-Object {$_.UDPSourcePort -eq $FirstQuery.UDPSourcePort -or $_.UDPDestinationPort -eq $FirstQuery.UDPSourcePort} }
            {$_ -in "EXO","Teams","SPO","Viva","Copilot","MicrosoftDomain"} { $PacketsForQuery = $Packets | Where-Object {($_.TCPSourcePort -eq $FirstQuery.TCPSourcePort -or $_.TCPDestinationPort -eq $FirstQuery.TCPSourcePort) -and $_.TCPPayload -match "^1603(01|02|03)....01" } }
        }
        $AvailableInterfaces = $PacketsForQuery | Group-Object -Property InterfaceID
        # Use the interface seen last (used to effectively send the packet on the network)
        $InterfaceUsedLast = ($AvailableInterfaces | Select-Object -last 1)
        if ($InterfaceUsedLast.Name -notmatch "\\\\") {
            # Escape the backslashes (needed to pass the filter to Wireshark)
            $InterfaceID = $InterfaceUsedLast.Name -replace '\\','\\'
        } else {
            $InterfaceID = $InterfaceUsedLast.Name
        }
        $InterfaceName = ($InterfaceUsedLast.Group | Select-Object -First 1).InterfaceName
        if ($InterfaceID -notlike "") {
            Write-Log -Message "Interface used to send $Workload queries is '$InterfaceName' ($InterfaceID)" -Source "$LogType" -MessageType Info
            $InterfaceFilter = "frame.interface_name==\`"$InterfaceID\`""
            switch ($CaptureScenario) {
                "Netskope" {
                    Write-Log -Message "Adding filter for queries sent through Netskope tunnel" -Source "$LogType" -MessageType Info
                    $InterfaceFilter = "( $InterfaceFilter || frame.comment contains \`"NetskopeTunnel\`" )"
                }
                "Zscaler - encrypted tunnel" {
                    Write-Log -Message "Adding filter for queries sent through Zscaler tunnel" -Source "$LogType" -MessageType Info
                    $InterfaceFilter = "( $InterfaceFilter || frame.comment contains \`"TUNNEL2\`" )"
                }
            }
        } else {
            Write-Log -Message "Interface ID is empty, not able to filter on interface" -Source "$LogType" -MessageType Warning
            $InterfaceFilter = $null
        }
    } else {
        Write-Log -Message "Found no $Workload query, not able to filter on interface" -Source "$LogType" -MessageType Warning
        $InterfaceFilter = $null
    }

    $InterfaceFilter
}

function Invoke-NetworkTraceFiltering {
    Param (
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [String] $OutputFile
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
        [ValidateSet("DNSLookup", "EXO", "Teams", "SPO", "Viva", "Copilot", "MicrosoftDomain", "FileTransfer")]
        [String] $Workload
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
        [String] $PreviousFilter
    )

    $LogType,$WorkloadDisplayName,$WorkloadNameFilter = Switch ($Workload) {
        "DNSLookup" {"DNSLookup","DNS",$null}
        "EXO" {"EXO","Exchange","outlook"}
        "Teams" {"Teams","Teams","teams"}
        "SPO" {"SPO","Sharepoint","sharepoint|spo-ring.msedge.net|$OneDriveFQDN"}
        "Viva" {"Viva","Viva","yammer|viva"}
        "Copilot" {"Copilot - $($OutputFile -replace '.*-Copilot(.*)\..*','$1')","Copilot","copilot|m365|substrate|augloop"}
        "MicrosoftDomain" {"MicrosoftDomain - $($OutputFile -replace '.*-(.*Microsoft)\..*','$1')","Microsoft Domain","cloud.microsoft|static.microsoft|usercontent.microsoft"}
        "FileTransfer" {"FileTransfer - SPO $($OutputFile -replace '.*-(.*)\..*','$1')","Sharepoint","sharepoint|spo-ring.msedge.net|$OneDriveFQDN"}
    }

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $Outputpath = $CurrentSettings.OutputPath
    $OutputPathUnfilteredTraces = Join-Path -Path $OutputPath -ChildPath "UnfilteredTraces"
    $WiresharkPath = $CurrentSettings.WiresharkPath
    $OneDriveFQDN = $CurrentSettings.OneDriveFQDN
    if ($OneDriveFQDN -like "") {
		$OneDriveFQDN = "microsoft-my.sharepoint.com"
	}
    $DebugMode = if ($CurrentSettings.DebugMode -match "True") {$true} else {$false}

    $FullFilter = $null
    $PortFilter = $null
    $InterfaceFilter_DNS = $null
    $InterfaceFilter = $null

    $FilteredOutputFile = ($OutputFile -replace '\.pcapng','-Filtered.pcapng')

    if (-not (Test-Path $OutputFile)) {
        Write-Log -Message "Output file cannot be found, unable to filter the trace" -Source "$LogType" -MessageType Error
        return
    }

    if (Test-Path "$WiresharkPath\reordercap.exe") {
        Write-Log -Message "Reordering capture if necessary" -Source "$LogType" -MessageType Info
        $ReorderedOutputFile = ($OutputFile -replace '\.pcapng','-Reordered.pcapng')
        & "$WiresharkPath\reordercap.exe" "$OutputFile" "$ReorderedOutputFile" | Out-Null
        if ((Get-Item $ReorderedOutputFile).Length -le 2000) {
            Write-Log -Message "Reordered file is too small, skipping reordering" -Source "$LogType" -MessageType Warning
            Remove-Item $ReorderedOutputFile -Force -ErrorAction SilentlyContinue
        } else {
            Move-Item $ReorderedOutputFile $OutputFile -Force
        }
    } else {
        Write-Log -Message "Reordercap cannot be found, unable to reorder the trace" -Source "$LogType" -MessageType Warning
    }

    if (-not (Test-Path "$WiresharkPath\tshark.exe")) {
        Write-Log -Message "Tshark (Wireshark) cannot be found, unable to filter the trace" -Source "$LogType" -MessageType Warning
        return
    }

    Write-Log -Message "Get packets from capture file" -Source "$LogType" -MessageType Info
    $Filter = 'dns || tcp.flags.syn == 1 || tcp.flags.fin == 1 || tcp.flags.reset == 1 || tcp.payload matches \"\x16\x03(\x01|\x02|\x03)[\x00-\xFF]{2}(\x01|\x02)\"'
    $Packets = & "$WiresharkPath\tshark.exe" -r "$OutputFile" -Y $Filter -T fields -e frame.time_epoch -e frame.interface_name -e frame.interface_description -e ip.src -e ip.dst `
                -e tcp.srcport -e tcp.dstport -e udp.srcport -e udp.dstport -e dns.flags.response -e dns.qry.name -e tcp.payload `
                -o tcp.analyze_sequence_numbers:FALSE -o tls.keylog_file:null -E separator=';' -2 | `
                Sort-Object | ConvertFrom-Csv -Delimiter ';' -Header "AbsoluteTime","InterfaceID","InterfaceName","SourceIP","DestinationIP" `
                ,"TCPSourcePort","TCPDestinationPort","UDPSourcePort","UDPDestinationPort","DnsFlagResponse","DnsQueryName","TCPPayload","TCPPayloadASCII"

    # Convert payload from HEX to ASCII
    $Packets |  Where-Object {$_.TCPPayload -match "^1603(01|02|03)....(01|02)"} | ForEach-Object { $_.TCPPayloadASCII = ($_.TCPPayload -split '(..)' -ne '' | ForEach-Object {[char][byte]"0x$_"}) -join '' }

    if (($Packets | Measure-Object).count -eq 0) {
        Write-Log -Message "Output file doesn't contain useable data, unable to filter the trace" -Source "$LogType" -MessageType Error
        return
    }

    switch ($Workload) {
        "DNSLookup" {
            Write-Log -Message "Cleaning $WorkloadDisplayName capture file to keep only $WorkloadDisplayName streams" -Source "$LogType" -MessageType Info
            $InterfaceFilter_DNS = Find-InterfaceUsedForQueries -Packets $Packets -Workload DNSLookup -LogType $LogType
            if ($InterfaceFilter_DNS) {
                $FullFilter = "dns && $InterfaceFilter_DNS"
            } else {
                $FullFilter = "dns"
            }
	        & "$WiresharkPath\tshark.exe" -r $OutputFile -q -Y $FullFilter -w $FilteredOutputFile -2 -o tls.keylog_file:null | Out-Null
            Write-Log -Message "$WorkloadDisplayName capture file was filtered with the following filter:" -Source "$LogType" -MessageType Info
            Write-Log -Message "$($FullFilter -replace '\\"','"')" -Source "$LogType" -MessageType Info
        }
        {$_ -in "EXO","Teams","SPO","Viva","Copilot","MicrosoftDomain"} {
            Write-Log -Message "Cleaning $WorkloadDisplayName capture file to keep only $WorkloadDisplayName and DNS streams" -Source "$LogType" -MessageType Info
            $InterfaceFilter_DNS = Find-InterfaceUsedForQueries -Packets $Packets -Workload DNSLookup -LogType $LogType
            if ($InterfaceFilter_DNS) {
                $FullFilter = "( dns && $InterfaceFilter_DNS )"
            } else {
                $FullFilter = "( dns )"
            }

            $InterfaceFilter = Find-InterfaceUsedForQueries -Packets $Packets -Workload $Workload -LogType $LogType
            if ($InterfaceFilter) {
                $FullFilter += " || ( $InterfaceFilter && ("
            } else {
                $FullFilter += " || ( "
            }

            # Find TLS Client Hello which contains the workload FQDN
            $ConversationsWithService = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "$WorkloadNameFilter"} | Group-Object -Property TCPSourcePort).Name

            # Generate port filter
            if ($null -eq $ConversationsWithService) {
                Write-Log -Message "No TLS handshake to $WorkloadDisplayName found, keeping all TCP streams" -Source "$LogType" -MessageType Info
                $PortFilter = "tcp"
            } elseif ($ConversationsWithService.count -eq 1) {
                $PortFilter = "tcp.port==$ConversationsWithService"
                Write-Log -Message "Found 1 TLS handshake to $WorkloadDisplayName - $PortFilter" -Source "$LogType" -MessageType Info
            } else {
                foreach ($Conversation in $ConversationsWithService) {
                    if ($null -eq $PortFilter) {
                        $PortFilter = "tcp.port==$Conversation"
                    } else {
                        $PortFilter += " || tcp.port==$Conversation"
                    }
                }
                Write-Log -Message "Found multiple TLS handshakes to $WorkloadDisplayName - $PortFilter" -Source "$LogType" -MessageType Info
            }

            if ($InterfaceFilter) {
                $FullFilter += "$PortFilter ) )"
            } else {
                $FullFilter += "$PortFilter )"
            }

            if ($FullFilter) {
                Write-Log -Message "Attempting to filter $WorkloadDisplayName capture file with the following filter:" -Source "$LogType" -MessageType Info
                Write-Log -Message "$($FullFilter -replace '\\"','"')" -Source "$LogType" -MessageType Info
                & "$WiresharkPath\tshark.exe" -r $OutputFile -q -Y "$FullFilter" -w $FilteredOutputFile -2 -o tls.keylog_file:null | Out-Null
                Write-Log -Message "Filtered $WorkloadDisplayName capture file" -Source "$LogType" -MessageType Info
            } else {
                Write-Log -Message "Trace will NOT be filtered" -Source "$LogType" -MessageType Warning
            }
        }
        "FileTransfer" {
            Write-Log -Message "Cleaning $WorkloadDisplayName file transfer capture file to keep only $WorkloadDisplayName streams" -Source "$LogType" -MessageType Info
            if ($PreviousFilter) {
                Write-Log -Message "A previous filter was provided and will be reused:" -Source "$LogType" -MessageType Info
                Write-Log -Message "$($PreviousFilter -replace '\\"','"')" -Source "$LogType" -MessageType Info
            } else {
                Write-Log -Message "No previous filter was provided" -Source "$LogType" -MessageType Info
            }

            $InterfaceFilter = Find-InterfaceUsedForQueries -Packets $Packets -Workload SPO -LogType $LogType
            
            # Find TLS Client Hello which contains the workload FQDN
            $ConversationsWithService = ($Packets | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TCPPayloadASCII -match "$WorkloadNameFilter"} | Group-Object -Property TCPSourcePort).Name

            # Generate port filter
            if ($null -eq $ConversationsWithService) {
                if ($PreviousFilter) {
                    Write-Log -Message "No new TLS handshake to $WorkloadDisplayName found" -Source "$LogType" -MessageType Info
                } else {
                    Write-Log -Message "No TLS handshake to $WorkloadDisplayName found, keeping all TCP streams" -Source "$LogType" -MessageType Warning
                }
            } elseif ($ConversationsWithService.count -eq 1) {
                $PortFilter = "tcp.port==$ConversationsWithService"
                if ($PreviousFilter) {
                    Write-Log -Message "Found 1 additional TLS handshake to $WorkloadDisplayName - $PortFilter" -Source "$LogType" -MessageType Info
                } else {
                    Write-Log -Message "Found 1 TLS handshake to $WorkloadDisplayName - $PortFilter" -Source "$LogType" -MessageType Info
                }
            } else {
                foreach ($Conversation in $ConversationsWithService) {
                    if ($null -eq $PortFilter) {
                        $PortFilter = "tcp.port==$Conversation"
                    } else {
                        $PortFilter += " || tcp.port==$Conversation"
                    }
                }
                if ($PreviousFilter) {
                    Write-Log -Message "Found multiple additional TLS handshakes to $WorkloadDisplayName - $PortFilter" -Source "$LogType" -MessageType Info
                } else {
                    Write-Log -Message "Found multiple TLS handshakes to $WorkloadDisplayName - $PortFilter" -Source "$LogType" -MessageType Info
                }
            }
            
            if ($PreviousFilter) {
                if ($InterfaceFilter) {
                    if ($PortFilter) {
                        $FullFilter = "$PreviousFilter || ( $InterfaceFilter && ( $PortFilter ) )"
                    } else {
                        $FullFilter = "$PreviousFilter"
                    }
                } else {
                    if ($PortFilter) {
                        $FullFilter = "$PreviousFilter || ( $PortFilter )"
                    } else {
                        $FullFilter = "$PreviousFilter"
                    }
                }
            } else {
                if ($InterfaceFilter) {
                    if ($PortFilter) {
                        $FullFilter = "( $InterfaceFilter && ( $PortFilter ) )"
                    } else {
                        $FullFilter = "( $InterfaceFilter )"
                    }
                } else {
                    if ($PortFilter) {
                        $FullFilter = "( $PortFilter )"
                    } else {
                        $FullFilter = "tcp"
                    }
                }
            }

            if ($FullFilter) {
                Write-Log -Message "Attempting to filter $WorkloadDisplayName file transfer capture file with the following filter:" -Source "$LogType" -MessageType Info
                Write-Log -Message "$($FullFilter -replace '\\"','"')" -Source "$LogType" -MessageType Info
                & "$WiresharkPath\tshark.exe" -r $OutputFile -q -Y "$FullFilter" -w $FilteredOutputFile -2 -o tls.keylog_file:null | Out-Null
                Write-Log -Message "Filtered $WorkloadDisplayName file transfer capture file" -Source "$LogType" -MessageType Info
                if ($FullFilter -ne "tcp") {
                    $FullFilter
                }
                if ((Test-Path "$WiresharkPath\editcap.exe") -and (Test-Path "$WiresharkPath\mergecap.exe")) {
                    Write-Log -Message "Processing filtered trace to further reduce size" -Source "$LogType" -MessageType Info
                    $FilteredOutputFileSplit1 = ($FilteredOutputFile -replace '\.pcapng','-Split1.pcapng')
                    $FilteredOutputFileSplit2 = ($FilteredOutputFile -replace '\.pcapng','-Split2.pcapng')
                    $FilteredOutputFileMerged = ($FilteredOutputFile -replace '\.pcapng','-Merged.pcapng')

                    Write-Log -Message "Splitting filtered trace to keep the first 200 packets" -Source "$LogType" -MessageType Info
                    $Process = Start-Process "$WiresharkPath\editcap.exe" -ArgumentList (' -r "' + $FilteredOutputFile + '" "' + $FilteredOutputFileSplit1 + '" 0-200') -PassThru
                    while ($Process.HasExited -ne $true) { Start-Sleep -Seconds 1 }
                    Write-Log -Message "Splitting filtered trace to keep packets after the first 200 packets and truncating further" -Source "$LogType" -MessageType Info
                    $Process = Start-Process "$WiresharkPath\editcap.exe" -ArgumentList (' -s 70 "' + $FilteredOutputFile + '" "' + $FilteredOutputFileSplit2 + '" 0-200') -PassThru
                    while ($Process.HasExited -ne $true) { Start-Sleep -Seconds 1 }
                    Write-Log -Message "Merging the splitted traces" -Source "$LogType" -MessageType Info
                    $Process = Start-Process "$WiresharkPath\mergecap.exe" -ArgumentList (' -a -w "' + $FilteredOutputFileMerged + '" "' + $FilteredOutputFileSplit1 + '" "' + $FilteredOutputFileSplit2 + '"') -PassThru
                    while ($Process.HasExited -ne $true) { Start-Sleep -Seconds 1 }

                    if (Test-Path $FilteredOutputFileMerged) {
                        $FilteredOutputFileSplit1FileSize = [math]::Round((Get-Item -Path $FilteredOutputFileSplit1).Length/1KB)
                        $FilteredOutputFileSplit2FileSize = [math]::Round((Get-Item -Path $FilteredOutputFileSplit2).Length/1KB)
                        $FilteredOutputFileMergedFileSize = [math]::Round((Get-Item -Path $FilteredOutputFileMerged).Length/1KB)
                        if ($FilteredOutputFileMergedFileSize -lt ($FilteredOutputFileSplit1FileSize + $FilteredOutputFileSplit2FileSize)*0.9) {
                            Write-Log -Message "Merged file is significantly smaller ($($FilteredOutputFileMergedFileSize)kb) than the split files ($($FilteredOutputFileSplit1FileSize + $FilteredOutputFileSplit2FileSize)kb), discarding the merged file" -Source "$LogType" -MessageType Error
                            Remove-Item -Path $FilteredOutputFileMerged -Force
                        } else {
                            Write-Log -Message "Removing original filtered trace" -Source "$LogType" -MessageType Info
                            Remove-Item -Path $FilteredOutputFile -Force
                            Write-Log -Message "Renaming merged trace file to original filtered name" -Source "$LogType" -MessageType Info
                            Move-Item -Path $FilteredOutputFileMerged -Destination $FilteredOutputFile
                        }
                    } else {
                        Write-Log -Message "Merged trace not found, skipping further trace manipulation" -Source "$LogType" -MessageType Error
                    }

                    Write-Log -Message "Removing split trace files" -Source "$LogType" -MessageType Info
                    Remove-Item -Path $FilteredOutputFileSplit1 -Force -ErrorAction SilentlyContinue
                    Remove-Item -Path $FilteredOutputFileSplit2 -Force -ErrorAction SilentlyContinue
                } else {
                    Write-Log -Message "Editcap and/or Mergecap is missing, unable to process the trace for further size reduction" -Source "$LogType" -MessageType Warning
                }
            } else {
                Write-Log -Message "Trace will NOT be filtered" -Source "$LogType" -MessageType Warning
            }
        }
    }

    if (Test-Path $FilteredOutputFile) {
        if ($DebugMode) {
            Write-Log -Message "Moving unfiltered trace file to UnfilteredTraces sub-folder and appending '-Unfiltered'" -Source "$LogType" -MessageType Info
            Move-Item -Path $OutputFile -Destination (Join-Path -Path $OutputPathUnfilteredTraces -ChildPath ((Split-Path -Path $OutputFile -Leaf) -replace '\.pcapng','-Unfiltered.pcapng'))
        } else {
            Write-Log -Message "Removing unfiltered trace file" -Source "$LogType" -MessageType Info
            Remove-Item -Path $OutputFile -Force
        }
        Write-Log -Message "Renaming filtered trace file to original name" -Source "$LogType" -MessageType Info
		Move-Item -Path $FilteredOutputFile -Destination $OutputFile
	}
}

function Test-OutputFile {
    Param(
        [parameter(mandatory = $true)]
        [ValidateSet("IPConfig", "Tracert", "DNSLookup", "EXO", "Teams", "SPO", "Viva", "Copilot", "MicrosoftDomain", "FileTransfer", "TeamsMediaQuality")]
        $Workload
    )

    $CurrentTestValidation = New-Object PSObject -Property ([ordered]@{
        Timestamp = Get-DateInFile
        Service = $Workload
        Result = ""
        OutputValid = $false
        OutputWarning = $false
        OutputError = $false
        ErrorDetails = ""
    })

    $CurrentSettings = Get-Content $env:NPAPath\Settings.json | ConvertFrom-Json
    $Outputpath = $CurrentSettings.OutputPath
    $OutputPathUnfilteredTraces = Join-Path -Path $OutputPath -ChildPath "UnfilteredTraces"
    $OutputCheckResultFile = Join-Path -Path $OutputPath -ChildPath "OutputCheckResult.csv"
    $WiresharkPath = $CurrentSettings.WiresharkPath
    $OneDriveFQDN = $CurrentSettings.OneDriveFQDN

    Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "Black"
    Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property Content -Value "-"

    $FileNameFilters = Switch ($Workload) {
        "IPConfig" {"IPCONFIG.*\.log"}
        "Tracert" {"TracerouteResults\.csv"}
        "DNSLookup" {"DNSLookup-.*(-Unfiltered)?\.pcapng"}
        "EXO" {"EXO(-Unfiltered)?\.pcapng"}
        "Teams" {"Teams(-Unfiltered)?\.pcapng"}
        "SPO" {"SPO(-Unfiltered)?\.pcapng"}
        "Viva" {"Viva(-Unfiltered)?\.pcapng"}
        "Copilot" {("CopilotWork(-Unfiltered)?\.pcapng","CopilotWeb(-Unfiltered)?\.pcapng","CopilotOffice(-Unfiltered)?\.pcapng","websocket\.csv")}
        "MicrosoftDomain" {("CloudMicrosoft(-Unfiltered)?\.pcapng","StaticMicrosoft(-Unfiltered)?\.pcapng","UsercontentMicrosoft(-Unfiltered)?\.pcapng")}
        "FileTransfer" {("3MBUP(-Unfiltered)?\.pcapng","3MBDOWN(-Unfiltered)?\.pcapng")}
        "TeamsMediaQuality" {"TeamsMediaQuality\.csv"}
    }

    if ($FileNameFilters -match "\.pcapng") {

        if (-not (Test-Path "$WiresharkPath\tshark.exe")) {
            Write-Log -Message "Tshark (Wireshark) cannot be found, unable to proceed with network trace validation" -Source "Main - OutputCheck - $Workload" -MessageType Warning
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "DarkOrange"
            $CheckResult = "-?-"
            Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property Content -Value $CheckResult
            $CurrentTestValidation.Result = "Unknown"
            $CurrentTestValidation.ErrorDetails = "Tshark (Wireshark) cannot be found, unable to proceed with network trace validation"
            $Values = ($CurrentTestValidation.Timestamp , $CurrentTestValidation.Service , $CurrentTestValidation.Result , $CurrentTestValidation.ErrorDetails) -join "`t"
            if (-not (Test-Path $OutputCheckResultFile)) {
                #If it is first time we need create file with following structure
                $Headers = ( "Timestamp" , "Service" , "Result" , "ErrorDetails" ) -join "`t"
                Add-Content -Value $Headers -Path $OutputCheckResultFile
            }
            Add-Content -Value $Values -Path $OutputCheckResultFile
            return
        }

        switch ($Workload) {
            "DNSLookup" {
                $FQDNList = @(
                    "outlook.com",
                    "outlook.office365.com",
                    "outlook-dod.office365.us",
                    "outlook.office365.us",
                    "webmail.apps.mil",
                    "pod51501.office365.us",
                    "teams.microsoft.com",
                    "gov.teams.microsoft.us",
                    "dod.teams.microsoft.us",
                    "sharepoint.com",
                    "sharepoint-mil.us",
                    "dps.mil",
                    "sharepoint.us",
                    "spo-ring.msedge.net",
                    "web.yammer.com",
                    "m365.cloud.microsoft",
                    "substrate.svc.cloud.microsoft",
                    "augloop.svc.cloud.microsoft",
                    "connectivity-test.cloud.microsoft",
                    "connectivity-test.static.microsoft",
                    "connectivity-test.usercontent.microsoft"
                )
                if ($OneDriveFQDN -notlike "") {
                    $FQDNList += $OneDriveFQDN
                }
            }
            "EXO" {
                $FQDNList = @(
                    "outlook.com",
                    "outlook.office365.com",
                    "outlook-dod.office365.us",
                    "outlook.office365.us",
                    "webmail.apps.mil",
                    "pod51501.office365.us"
                )
            }
            "Teams" {
                $FQDNList = @(
                    "teams.microsoft.com",
                    "gov.teams.microsoft.us",
                    "dod.teams.microsoft.us"
                )
            }
            "SPO" {
                $FQDNList = @(
                    "sharepoint.com",
                    "sharepoint-mil.us",
                    "dps.mil",
                    "sharepoint.us",
                    "spo-ring.msedge.net"
                )
                if ($OneDriveFQDN -notlike "") {
                    $FQDNList += $OneDriveFQDN
                }
            }
            "Viva" {
                $FQDNList = @(
                    "web.yammer.com"
                )
            }
            "Copilot" {
                $FQDNList = @(
                    "m365.cloud.microsoft",
                    "substrate.svc.cloud.microsoft",
                    "augloop.svc.cloud.microsoft"
                )
            }
            "MicrosoftDomain" {
                $FQDNList = @(
                    "connectivity-test.cloud.microsoft",
                    "connectivity-test.static.microsoft",
                    "connectivity-test.usercontent.microsoft"
                )
            }
            "FileTransfer" {
                $FQDNList = @(
                    "sharepoint.com",
                    "sharepoint-mil.us",
                    "dps.mil",
                    "sharepoint.us",
                    "spo-ring.msedge.net"
                )
                if ($OneDriveFQDN -notlike "") {
                    $FQDNList += $OneDriveFQDN
                }
            }
        }

        if ($Workload -eq "DNSLookup") {
            $FQDNFilter = ""
            foreach ($FQDN in $FQDNList) {
                if ($FQDNFilter -like "") {
                    $FQDNFilter +=  '(dns.qry.name contains \"' + $FQDN + '\")'
                } else {
                    $FQDNFilter +=  ' or (dns.qry.name contains \"' + $FQDN + '\")'
                }
            }
        } else {
            $FQDNFilter = ""
            foreach ($FQDN in $FQDNList) {
                if ($FQDNFilter -like "") {
                    $FQDNFilter +=  '(frame contains \"' + $FQDN + '\")'
                } else {
                    $FQDNFilter +=  ' or (frame contains \"' + $FQDN + '\")'
                }
            }
        }
    }

    Write-Log -Message "Starting output file check" -Source "Main - OutputCheck - $Workload" -MessageType Info

    foreach ($FileNameFilter in $FileNameFilters) {
        $FileToCheck = Get-ChildItem -Path $Outputpath | Where-Object {$_.Name -match $FileNameFilter} | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1

        if ($FileToCheck -notlike "") {

            Write-Log -Message "Analyzing file '$($FileToCheck.Name)'" -Source "Main - OutputCheck - $Workload" -MessageType Info

            if ($Workload -eq "IPConfig") {

                Write-Log -Message "Getting content of IPConfig output" -Source "Main - OutputCheck - $Workload" -MessageType Info
                $IPConfigContent = Get-Content $FileToCheck.FullName
                if ($IPConfigContent -match 'IPCONFIG') {
                    Write-Log -Message "Output file has expected content" -Source "Main - OutputCheck - $Workload" -MessageType Info
                    $CurrentTestValidation.OutputValid = $true
                } else {
                    Write-Log -Message "Output file does NOT have expected content" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                    $CurrentTestValidation.OutputError = $true
                    $CurrentTestValidation.ErrorDetails = "Output file does NOT have expected content"
                }

            } elseif ($Workload -eq "Tracert") {

                Write-Log -Message "Getting content of traceroute output" -Source "Main - OutputCheck - $Workload" -MessageType Info
                $TracerouteResults = Import-Csv -Path $FileToCheck.FullName -Delimiter "`t"
                if ($TracerouteResults | Where-Object {$_.FQDN -match "ntwk\.msn\.net" -and $_.Latency -match "\d+"}) {
                    Write-Log -Message "Traceroute succeeded for at least one Microsoft endpoint" -Source "Main - OutputCheck - $Workload" -MessageType Info
                    $CurrentTestValidation.OutputValid = $true
                } else {
                    Write-Log -Message "No traceroute succeeded for any Microsoft endpoint" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                    $CurrentTestValidation.OutputWarning = $true
                    $CurrentTestValidation.ErrorDetails = "No traceroute succeeded for any Microsoft endpoint"
                }

            } elseif ($Workload -eq "DNSLookup") {

                $Filter = 'dns && ( ' + $FQDNFilter + ' )'
                
                Write-Log -Message "Attempting to find expected packets in network trace" -Source "Main - OutputCheck - $Workload" -MessageType Info
                $MatchingPackets = & "$WiresharkPath\tshark.exe" -r ('"'+ $FileToCheck.FullName + '"') -Y $Filter -T fields -e frame.time_relative -e frame.interface_id `
                                        -e ip.src -e ip.dst -e dns.flags.response -e dns.qry.name -e dns.cname -e dns.flags.rcode -e dns.id `
                                        -o tls.keylog_file:null -E separator=';' | ConvertFrom-Csv -Delimiter ';' -Header "TimeRelative","InterfaceID" `
                                        ,"SourceIP","DestinationIP","DnsFlagResponse","DnsQueryName","DNSResponseName","DNSResponseCode","DNSTransactionID"
                $DNSQueries = $MatchingPackets | Where-Object {$_.DNSFlagResponse -eq 0 -or $_.DNSFlagResponse -eq $false}
                if ($DNSQueries) {
                    Write-Log -Message "Found DNS queries for Microsoft endpoints" -Source "Main - OutputCheck - $Workload" -MessageType Info
                    $DNSResponses = $MatchingPackets | Where-Object {$_.DNSTransactionID -in $DNSQueries.DNSTransactionID -and ($_.DNSFlagResponse -eq 1 -or $_.DNSFlagResponse -eq $true) -and $_.DNSResponseName -notlike ""}
                        if ($DNSResponses) {
                            Write-Log -Message "Found at least one corresponding DNS response" -Source "Main - OutputCheck - $Workload" -MessageType Info
                            $CurrentTestValidation.OutputValid = $true
                        } else {
                            Write-Log -Message "No corresponding DNS response found" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                            $CurrentTestValidation.OutputWarning = $true
                            $CurrentTestValidation.ErrorDetails = "No corresponding DNS response found"
                        }
                } else {
                    Write-Log -Message "No DNS queries for Microsoft endpoints found" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                    $CurrentTestValidation.OutputError = $true
                    $CurrentTestValidation.ErrorDetails = "No DNS queries for Microsoft endpoints found"
                }

            } elseif ($Workload -match '^(EXO|Teams|SPO|Viva|Copilot|MicrosoftDomain|FileTransfer)$') {

                if ($FileToCheck.Name -match "websocket\.csv") {

                    Write-Log -Message "Getting content of websocket connections output" -Source "Main - OutputCheck - $Workload" -MessageType Info
                    $WebsocketResults = Import-Csv -Path $FileToCheck.FullName -Delimiter "`t"
                    if ($WebsocketResults | Where-Object {$_.WSSExpectedResponse -eq $true}) {
                        Write-Log -Message "Websocket connection succeeded for at least one Microsoft endpoint" -Source "Main - OutputCheck - $Workload" -MessageType Info
                        $CurrentTestValidation.OutputValid = $true
                    } else {
                        Write-Log -Message "No websocket connection succeeded for any Microsoft endpoint" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                        $CurrentTestValidation.OutputWarning = $true
                        $ErrorDetails = "No websocket connection succeeded for any Microsoft endpoint"
                        if ($CurrentTestValidation.ErrorDetails -notlike "") {
                            $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                        } else {
                            $CurrentTestValidation.ErrorDetails = $ErrorDetails
                        }
                    }

                } else {

                    $Filter = '(((tcp.payload matches \"\x16\x03(\x01|\x02|\x03)[\x00-\xFF]{2}\x01\") && ( ' + $FQDNFilter + ' )) || (tcp.payload matches \"\x16\x03(\x01|\x02|\x03)[\x00-\xFF]{2}\x02\"))'
                    if ($Workload -eq "FileTransfer") {
                        $Filter += ' || ( tcp.seq >= ' + (3 * 1MB) + ' && tcp.seq <= ' + (3 * 1MB + 100KB) + ' ) '
                    }

                    Write-Log -Message "Attempting to find expected packets in network trace" -Source "Main - OutputCheck - $Workload" -MessageType Info
                    $MatchingPackets = & "$WiresharkPath\tshark.exe" -r ('"'+ $FileToCheck.FullName + '"') -Y $Filter -T fields -e frame.time_relative -e frame.interface_id -e tcp.stream `
                                            -e ip.src -e tcp.srcport -e ip.dst -e tcp.dstport -e tcp.seq -e tcp.payload `
                                            -o tls.keylog_file:null -E separator=';' | ConvertFrom-Csv -Delimiter ';' -Header "TimeRelative","InterfaceID","TCPStream" `
                                            ,"SourceIP","SourcePort","DestinationIP","DestinationPort","TCPSequenceNumber","TCPPayload"

                    $TLSClientHello = $MatchingPackets | Where-Object {$_.TCPPayload -match '1603(01|02|03)....01'}
                    if ($TLSClientHello) {
                        Write-Log -Message "Found a TLS Client Hello" -Source "Main - OutputCheck - $Workload" -MessageType Info
                        if ($Workload -eq "FileTransfer") {
                            $FileTransferPackets = $MatchingPackets | Where-Object {$_.TCPStream -in $TLSClientHello.TCPStream -and $_.TCPSequenceNumber -gt (3 * 1MB)}
                            if ($FileTransferPackets) {
                                Write-Log -Message "Found a complete 3MB file transfer" -Source "Main - OutputCheck - $Workload" -MessageType Info
                                $CurrentTestValidation.OutputValid = $true
                            } else {
                                Write-Log -Message "Complete 3MB file transfer not found" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                                $CurrentTestValidation.OutputWarning = $true
                                $ErrorDetails = "Complete 3MB file transfer not found"
                                if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                    $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                                } else {
                                    $CurrentTestValidation.ErrorDetails = $ErrorDetails
                                }
                            }
                        } else {
                            $TLSServerHello = $MatchingPackets | Where-Object {$_.TCPStream -in $TLSClientHello.TCPStream -and $_.TCPPayload -match '1603(01|02|03)....02'}
                            if ($TLSServerHello) {
                                Write-Log -Message "Found a corresponding TLS Server Hello" -Source "Main - OutputCheck - $Workload" -MessageType Info
                                $CurrentTestValidation.OutputValid = $true
                            } else {
                                Write-Log -Message "No corresponding TLS Server Hello found" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                                $CurrentTestValidation.OutputWarning = $true
                                $ErrorDetails = "No corresponding TLS Server Hello found"
                                if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                    $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                                } else {
                                    $CurrentTestValidation.ErrorDetails = $ErrorDetails
                                }
                            }
                        }
                    } else {
                        Write-Log -Message "No TLS Client Hello found" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                        Write-Log -Message "Retrying with a file from 'UnfilteredTraces' subfolder" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                        $UnfilteredFileToCheck = Get-ChildItem -Path $OutputPathUnfilteredTraces | Where-Object {$_.Name -match $FileNameFilter} | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1
                        if ($UnfilteredFileToCheck -notlike "") {
                            Write-Log -Message "Analyzing file '$($UnfilteredFileToCheck.Name)' from 'UnfilteredTraces' subfolder" -Source "Main - OutputCheck - $Workload" -MessageType Info
                            Write-Log -Message "Attempting to find expected packets in unfiltered network trace" -Source "Main - OutputCheck - $Workload" -MessageType Info
                            $MatchingPackets = & "$WiresharkPath\tshark.exe" -r ('"'+ $UnfilteredFileToCheck.FullName + '"') -Y $Filter -T fields -e frame.time_relative -e frame.interface_id -e tcp.stream `
                                                    -e ip.src -e tcp.srcport -e ip.dst -e tcp.dstport -e tcp.seq -e tcp.payload `
                                                    -o tls.keylog_file:null -E separator=';' | ConvertFrom-Csv -Delimiter ';' -Header "TimeRelative","InterfaceID","TCPStream" `
                                                    ,"SourceIP","SourcePort","DestinationIP","DestinationPort","TCPSequenceNumber","TCPPayload"

                            $TLSClientHello = $MatchingPackets | Where-Object {$_.TCPPayload -match '1603(01|02|03)....01'}
                            if ($TLSClientHello) {
                                Write-Log -Message "Found a TLS Client Hello in unfiltered trace" -Source "Main - OutputCheck - $Workload" -MessageType Info
                                if ($Workload -eq "FileTransfer") {
                                    $FileTransferPackets = $MatchingPackets | Where-Object {$_.TCPStream -in $TLSClientHello.TCPStream -and $_.TCPSequenceNumber -gt (3 * 1MB)}
                                    if ($FileTransferPackets) {
                                        Write-Log -Message "Found a complete 3MB file transfer in unfiltered trace" -Source "Main - OutputCheck - $Workload" -MessageType Info
                                        $CurrentTestValidation.OutputWarning = $true
                                        $ErrorDetails = "Found a complete 3MB file transfer in unfiltered trace"
                                        if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                            $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                                        } else {
                                            $CurrentTestValidation.ErrorDetails = $ErrorDetails
                                        }
                                    } else {
                                        Write-Log -Message "Complete 3MB file transfer not found in unfiltered trace" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                                        $CurrentTestValidation.OutputWarning = $true
                                        $ErrorDetails = "Complete 3MB file transfer not found in filtered and unfiltered trace"
                                        if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                            $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                                        } else {
                                            $CurrentTestValidation.ErrorDetails = $ErrorDetails
                                        }
                                    }
                                } else {
                                    $TLSServerHello = $MatchingPackets | Where-Object {$_.TCPStream -in $TLSClientHello.TCPStream -and $_.TCPPayload -match '1603(01|02|03)....02'}
                                    if ($TLSServerHello) {
                                        Write-Log -Message "Found a corresponding TLS Server Hello in unfiltered trace" -Source "Main - OutputCheck - $Workload" -MessageType Info
                                        $CurrentTestValidation.OutputWarning = $true
                                        $ErrorDetails = "Found a corresponding TLS Server Hello in unfiltered trace"
                                        if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                            $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                                        } else {
                                            $CurrentTestValidation.ErrorDetails = $ErrorDetails
                                        }
                                    } else {
                                        Write-Log -Message "No corresponding TLS Server Hello found in unfiltered trace" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                                        $CurrentTestValidation.OutputWarning = $true
                                        $ErrorDetails = "No TLS Client Hello found in filtered trace and no corresponding TLS Server Hello found in filtered trace"
                                        if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                            $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                                        } else {
                                            $CurrentTestValidation.ErrorDetails = $ErrorDetails
                                        }
                                    }
                                }
                                Write-Log -Message "Test will be flagged as warning due to data being found only in unfiltered trace" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                            } else {
                                Write-Log -Message "No TLS Client Hello found in unfiltered trace" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                                $CurrentTestValidation.OutputError = $true
                                $ErrorDetails = "No TLS Client Hello found in filtered and unfiltered trace"
                                if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                    $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                                } else {
                                    $CurrentTestValidation.ErrorDetails = $ErrorDetails
                                }
                            }
                        } else {
                            Write-Log -Message "No file found matching pattern '$FileNameFilter' in 'UnfilteredTraces' subfolder" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                            $CurrentTestValidation.OutputError = $true
                            $ErrorDetails = "No TLS Client Hello found in filtered trace and no corresponding unfiltered trace found"
                            if ($CurrentTestValidation.ErrorDetails -notlike "") {
                                $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
                            } else {
                                $CurrentTestValidation.ErrorDetails = $ErrorDetails
                            }
                        }
                    }
                }

            } elseif ($Workload -eq "TeamsMediaQuality") {

                Write-Log -Message "Getting content of Teams test calls output" -Source "Main - OutputCheck - $Workload" -MessageType Info
                $TeamsMediaQualityResults = Import-Csv -Path $FileToCheck.FullName -Delimiter "`t"
                if ($TeamsMediaQualityResults | Where-Object {$_.RemoteIP -notlike ""}) {
                    if ($TeamsMediaQualityResults | Where-Object {$_.Protocol -eq "UDP"}) {
                        Write-Log -Message "Teams test calls succeeded at least once over UDP" -Source "Main - OutputCheck - $Workload" -MessageType Info
                        $CurrentTestValidation.OutputValid = $true
                    } else {
                        Write-Log -Message "Teams test calls succeeded at least once but never over UDP" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                        $CurrentTestValidation.OutputWarning = $true
                        $CurrentTestValidation.ErrorDetails = "Teams test calls succeeded at least once but never over UDP"
                    }
                } else {
                    Write-Log -Message "No Teams test call succeeded" -Source "Main - OutputCheck - $Workload" -MessageType Warning
                    $CurrentTestValidation.OutputError = $true
                    $CurrentTestValidation.ErrorDetails = "No Teams test call succeeded"
                }

            }
        } else {
            Write-Log -Message "No file found matching pattern '$FileNameFilter'" -Source "Main - OutputCheck - $Workload" -MessageType Warning
            $CurrentTestValidation.OutputError = $true
            $ErrorDetails = "No file found matching pattern '$FileNameFilter'"
            if ($CurrentTestValidation.ErrorDetails -notlike "") {
                $CurrentTestValidation.ErrorDetails = ($CurrentTestValidation.ErrorDetails,$ErrorDetails) -join " / "
            } else {
                $CurrentTestValidation.ErrorDetails = $ErrorDetails
            }
        }
    }
    
    if ($CurrentTestValidation.OutputError -eq $true) {
        Write-Log -Message "Test output flagged as 'error'" -Source "Main - OutputCheck - $Workload" -MessageType Info
        $CurrentTestValidation.Result = "Error"
        $CheckResult = "X"
        Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "Red"
    } elseif ($CurrentTestValidation.OutputWarning -eq $true) {
        Write-Log -Message "Test output flagged as 'warning'" -Source "Main - OutputCheck - $Workload" -MessageType Info
        $CurrentTestValidation.Result = "Warning"
        $CheckResult = "/!\"
        Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "DarkOrange"
    } elseif ($CurrentTestValidation.OutputValid -eq $true) {
        Write-Log -Message "Test output flagged as 'valid'" -Source "Main - OutputCheck - $Workload" -MessageType Info
        $CurrentTestValidation.Result = "Valid"
        $CheckResult = "V"
        Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "DarkGreen"
    } else {
        Write-Log -Message "Unknown output check result" -Source "Main - OutputCheck - $Workload" -MessageType Warning
        $CurrentTestValidation.Result = "Unknown"
        $CheckResult = "-?-"
        Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property foreground -Value "DarkOrange"
    }
    Update-Control -SyncHash $SyncHash -Control "lbl_Network_$($Workload)_CheckResult" -Property Content -Value $CheckResult
    $Values = ($CurrentTestValidation.Timestamp , $CurrentTestValidation.Service , $CurrentTestValidation.Result , $CurrentTestValidation.ErrorDetails) -join "`t"
    if (-not (Test-Path $OutputCheckResultFile)) {
        #If it is first time we need create file with following structure
        $Headers = ( "Timestamp" , "Service" , "Result" , "ErrorDetails" ) -join "`t"
        Add-Content -Value $Headers -Path $OutputCheckResultFile
    }
    Add-Content -Value $Values -Path $OutputCheckResultFile
}

function Get-OutputFileCheckResult {
    if ($SyncHash.TenantType.SelectedIndex -ne 0) {
        $TestsList = "IPConfig","Tracert","DNSLookup","EXO","Teams","SPO","FileTransfer","TeamsMediaQuality"
    } else {
        $TestsList = "IPConfig","Tracert","DNSLookup","EXO","Teams","SPO","Viva","Copilot","FileTransfer","TeamsMediaQuality"
    }

    $OutputFileCheckResults = @()
    foreach ($Test in $TestsList) {
        $OutputFileCheckResults += New-Object PSObject -Property ([ordered]@{ TestName = $Test ; CheckResult = $SyncHash."lbl_Network_$($Test)_CheckResult".Content })
    }
    return $OutputFileCheckResults
}