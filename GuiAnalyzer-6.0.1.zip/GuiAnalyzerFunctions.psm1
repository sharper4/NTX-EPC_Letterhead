Function Write-Log {
	Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[ValidateSet("Info","Warning","Error")]
		[string]$MessageType = ""
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Message
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[string]$Source
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[switch]$DisplayInGui
	)

    try {
        ## Mutex is required to allow parallel writting to logfile
        $Mutex = $null
        $MutexAcquired = $false
        $Mutex = New-Object System.Threading.Mutex($false, "DataCollectionLogFile")
        $MutexAcquired = $Mutex.WaitOne(200)
        if (-not $MutexAcquired) {
            Write-Host "Failed to acquire mutex in time"
        }

        if ($Source) {
            if ($Source -match ' - ') {
                $SourceWithPID = $Source -replace '^(.*?) - ',('$1 (PID:'+$PID+') - ')
            } else {
                $SourceWithPID = "$Source (PID:$($PID))"
            }
            $MessageInLogs = "$SourceWithPID - $Message"
            $Message = "$Source - $Message"
        } else {
            $MessageInLogs = $Message
        }

        if ($MessageType -eq "Error") {
            $LogLine = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - ERROR - $MessageInLogs"
            $LogLineForDisplay = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - ERROR - $Message"
            $BackgroundColor = "Black"
            $ForegroundColor = "Red"
        } elseif ($MessageType -eq "Warning") {
            $LogLine = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - WARN  - $MessageInLogs"
            $LogLineForDisplay = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - WARN  - $Message"
            $BackgroundColor = "Black"
            $ForegroundColor = "Yellow"
        } elseif ($MessageType -eq "Info") {
            $LogLine = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - INFO  - $MessageInLogs"
            $LogLineForDisplay = "$(Get-Date -Format 'yyyyMMdd-HH:mm:ss.fff') - INFO    - $Message"
            $BackgroundColor = "Black"
            $ForegroundColor = "White"
        } else {
            $LogLine = $MessageInLogs
            $LogLineForDisplay = $Message
            $BackgroundColor = "Black"
            $ForegroundColor = "White"
        }

        Write-Host -BackgroundColor $BackgroundColor -ForegroundColor $ForegroundColor $LogLine
	
        $LogLine | Out-File $SyncHash.RunLog -Append -Encoding UTF8
        if ($SyncHash.RunLogCurrentFolder) {
            $LogLine | Out-File $SyncHash.RunLogCurrentFolder -Append -Encoding UTF8
        }
    } catch {
        Write-Host "Failed to write to log file"
        Write-Host $_
    } finally {
        if ($MutexAcquired) {
            $Mutex.ReleaseMutex()
        }
        if ($Mutex) {
            $Mutex.Dispose()
        }
    }

    if ($DisplayInGui -and $null -ne $SyncHash.ListBox) { 
        Write-Display -Message $LogLineForDisplay
    }
}

function Write-Display {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Message
	)
    try {
        $SyncHash.ListBox.Items.Add($Message) | Out-Null
        $SyncHash.ListBox.SelectedIndex = $SyncHash.ListBox.Items.Count - 1
    } catch {
        
    }
}

function Write-FileAnalysisResultsFile {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$FileName
        ,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$SiteName
        ,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$DateTime
        ,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Type
        ,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[DateTime]$AnalysisStartTime
        ,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Result
        ,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $false)]
		[string]$Reason
	)

    try {
        ## Mutex is required to allow parallel writting to result file
        $Mutex = $null
        $MutexAcquired = $false
        $Mutex = New-Object System.Threading.Mutex($false, "GuiAnalyzerFileAnalysisResultsFile")
        $MutexAcquired = $Mutex.WaitOne(200)

        $TimeTaken = [math]::Round((New-TimeSpan $AnalysisStartTime (Get-Date)).TotalSeconds,2) -replace ',','.'
        Add-Content -Encoding UTF8 -Path $SyncHash.FileAnalysisResultsFile -Value (($FileName, $SiteName, $DateTime, $Type, $TimeTaken, $Result, $Reason) -join $SyncHash.ListSeparator)
    } catch {
        Write-Log -Message "Failed to write analysis to result file" -Source "Main" -MessageType Error
        Write-Log -Message "$_" -Source "Main" -MessageType Error
    } finally {
        if ($MutexAcquired) {
            $Mutex.ReleaseMutex()
        }
        if ($Mutex) {
            $Mutex.Dispose()
        }
    }
}

function Set-GuiLock {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[ValidateSet("Enable","DisableAllExceptBrowser","DisableAll")]
		[string]$Action
	)

    if ($Action -eq "Enable") {
        Write-Log -Message "Enabling the GUI" -Source "Main" -MessageType Info
        $SyncHash.CsvBox.Enabled = $true
        $SyncHash.CapBox.Enabled = $true
        $SyncHash.DefaultActionBox.Enabled = $true
        $SyncHash.BrowseButton.Enabled = $true
        $SyncHash.InputFolderBox.Enabled = $true
        $SyncHash.OutputButton.Enabled = $true
        $SyncHash.StartButton.Enabled = $true
    } elseif ($Action -eq "DisableAllExceptBrowser") {
        Write-Log -Message "Disabling the GUI except the '$($SyncHash.BrowseButton.Text)' button" -Source "Main" -MessageType Info
        $SyncHash.CsvBox.Enabled = $false
        $SyncHash.CapBox.Enabled = $false
        $SyncHash.DefaultActionBox.Enabled = $false
        $SyncHash.BrowseButton.Enabled = $true
        $SyncHash.InputFolderBox.Enabled = $true
        $SyncHash.OutputButton.Enabled = $false
        $SyncHash.StartButton.Enabled = $false
    } elseif ($Action -eq "DisableAll") {
        Write-Log -Message "Disabling the GUI" -Source "Main" -MessageType Info
        $SyncHash.CsvBox.Enabled = $false
        $SyncHash.CapBox.Enabled = $false
        $SyncHash.DefaultActionBox.Enabled = $false
        $SyncHash.BrowseButton.Enabled = $false
        $SyncHash.InputFolderBox.Enabled = $false
        $SyncHash.OutputButton.Enabled = $false
        $SyncHash.StartButton.Enabled = $false
    }
}

# Creates consistent dates in the logs and files
function Get-DateInFile {
    Param(
        [Parameter(Mandatory=$false)]
        $DateTime = (Get-Date)
    )

    Get-Date $DateTime -Format "yyyyMMdd HH:mm:ss"
}

# Consistent dates in filenames
function Get-DateInFileName {
    Param(
        [Parameter(Mandatory=$false)]
        $DateTime = (Get-Date)
    )

    Get-Date $DateTime -Format "yyyyMMdd-HHmm"
}

function Get-TimestampInfo ($InputObject) {

    if ($InputObject.Name) {
        $FileName = $InputObject.Name
        [string]$DateTime = ""
        # Used with files collected with DataCollection v4+ tool
        if (($FileName -split "-")[0].Length -eq 8) {
            $DateTime = $FileName -replace '^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2}).*','$1.$2.$3 $4:$5'
        # Used with files collected with DataCollection v2 tool (will return the same format like for the files collected with v4+)
        } else {
            $DateTime = "20" + $FileName.Substring(4, 2) + "." + $FileName.Substring(2, 2) + "." + $FileName.Substring(0, 2) + " " + $FileName.Substring(7, 2) + ":" + $FileName.Substring(9, 2)
        }
    } else {
        $Timestamp = $InputObject
        if ($Timestamp -match '^(\d{4})(\d{2})(\d{2}) (\d{2}):(\d{2}).*') {
            $DateTime = $Timestamp -replace '^(\d{4})(\d{2})(\d{2}) (\d{2}):(\d{2}).*','$1.$2.$3 $4:$5'
        } elseif ($Timestamp -match '^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}).*') {
            $DateTime = $Timestamp -replace '^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}).*','$1.$2.$3 $4:$5'
        } else {
            Write-Log -Message "Unknown timestamp format" -Source "Main" -MessageType Error -DisplayInGui
        }
    }

    $Date, $Time = $DateTime -split " "
    $DayIndex = (Get-Date $Date).DayOfWeek.value__ - [Int][DayOfWeek]"Monday"
    if ($DayIndex -eq -1) {$DayIndex = 6}
    $Hour = (Get-Date $DateTime -Format HH:00:00)
    return $DateTime, $Date, $Time, $DayIndex, $Hour
}

function Test-Wireshark {
    Write-Log -Message "Trying to find Wireshark (Tshark) installation path" -Source "Main" -MessageType Info

    $TsharkPath = Get-ChildItem -Path $env:ProgramW6432 -Filter "tshark.exe" -Recurse -Depth 2 -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
    if ($null -eq $TsharkPath) {
        $TsharkPath = Get-ChildItem -Path ${env:ProgramFiles(x86)} -Filter "tshark.exe" -Recurse -Depth 2 -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
    }

    if ($null -ne $TsharkPath) {
        Write-Log -Message "Installation found at path: $TSharkPath" -Source "Main" -MessageType Info
        try {
            Write-Log -Message "Fetching Wireshark version history" -Source "Main" -MessageType Info
            try {
                $WiresharkVersions = ((Invoke-RestMethod -uri "https://www.wireshark.org/download/win64/all-versions/") -split "`n" | Where-Object {$_ -match ">Wireshark.*?\.exe<"}) -replace '.*(Wireshark.*?\.exe).*?(\d{4}-\d{2}-\d{2} \d{2}:\d{2}).*','$1;$2' | ConvertFrom-Csv -Delimiter ';' -Header "File","Date"
            } catch {
                Write-Log -Message "Failed to fetch Wireshark version history: $($_.Exception.Message)" -Source "Main" -MessageType Warning
                $WiresharkVersions = $null
            }
            Write-Log -Message "Checking Wireshark (Tshark) version" -Source "Main" -MessageType Info
            [System.Version] $Version = (Get-Item $TsharkPath).versioninfo.fileversion
            if ($null -ne $WiresharkVersions) {
                $VersionDate = Get-Date ($WiresharkVersions | Where-Object {$_.File -match $version} | Select-Object -Last 1).Date
                Write-Log -Message "Wireshark (Tshark) version: $Version ($(Get-Date $VersionDate -Format "yyyy-MM-dd"))" -Source "Main" -MessageType Info
                if ((New-TimeSpan -Start $VersionDate -End (get-date)).Days -gt 365) {
                    if ($SyncHash.BypassVersionCheck) {
                        Write-Log -Message "Wireshark (Tshark) version '$Version' is older than a year" -Source "Main" -MessageType Warning -DisplayInGui
                    } else {
                        Write-Log -Message "Wireshark (Tshark) version '$Version' is older than a year, update Wireshark and re-run the script" -Source "Main" -MessageType Warning -DisplayInGui
                        return
                    }
                } else {
                    Write-Log -Message "Wireshark (Tshark) version is correct" -Source "Main" -MessageType Info
                }
            } else {
                Write-Log -Message "Wireshark (Tshark) version: $Version (Unable to check version age)" -Source "Main" -MessageType Warning
                Write-Log -Message "Wireshark version age could not be determined" -Source "Main" -MessageType Warning -DisplayInGui
            }
            return $TSharkPath
        } catch {
            Write-Log -Message "Error while checking Wireshark (Tshark) installation" -Source "Main" -MessageType Error -DisplayInGui
            Write-Log -Message "Verify if Tshark runs manually in CMD and rerun the script" -Source "Main" -MessageType Error -DisplayInGui
            return
        }
    } else {
        Write-Log -Message "Wireshark (Tshark) installation not found" -Source "Main" -MessageType Error -DisplayInGui
        Write-Log -Message "Install Wireshark and re-run the script" -Source "Main" -MessageType Error -DisplayInGui
        return
    }
}

function Set-WiresharkSettings {
    $Global:ErrorActionPreference = 'stop'
    try {
        $WiresharkConfigFolder = Join-Path -Path $env:APPDATA -ChildPath "Wireshark"
        if (-not (Test-Path $WiresharkConfigFolder)) {
            Write-Log -Message "Wireshark configuration folder not found, creating it" -Source "Main" -MessageType Info
            New-Item $WiresharkConfigFolder -type directory | Out-Null
        }

        Write-Log -Message "Configuring Wireshark disabled protocols" -Source "Main" -MessageType Info
        $WiresharkDisabledProtocolsFile = Join-Path -Path $WiresharkConfigFolder -ChildPath "disabled_protos"
        $WiresharkDisabledProtocols = Get-Content -Path $WiresharkDisabledProtocolsFile -ErrorAction SilentlyContinue
        if ($null -eq $WiresharkDisabledProtocols) {
            $WiresharkDisabledProtocols = @()
        }
        if (-not ($WiresharkDisabledProtocols -match '^http$')) { $WiresharkDisabledProtocols += "http" }
        if (-not ($WiresharkDisabledProtocols -match '^http2$')) { $WiresharkDisabledProtocols += "http2" }
        if (-not ($WiresharkDisabledProtocols -match '^http3$')) { $WiresharkDisabledProtocols += "http3" }
        $WiresharkDisabledProtocols | Sort-Object | Set-Content -Path $WiresharkDisabledProtocolsFile

        Write-Log -Message "Configuring Wireshark preferences" -Source "Main" -MessageType Info
        $WiresharkPreferencesFile = Join-Path -Path $WiresharkConfigFolder -ChildPath "preferences"
        $WiresharkPreferences = Get-Content -Path $WiresharkPreferencesFile -ErrorAction SilentlyContinue
        if ($null -eq $WiresharkPreferences) {
            $WiresharkPreferences = @()
            $WiresharkPreferences += 'tcp.desegment_tcp_streams: TRUE'
            $WiresharkPreferences += 'tcp.reassemble_out_of_order: TRUE'
            $WiresharkPreferences += 'tcp.try_heuristic_first: TRUE'
            $WiresharkPreferences += 'tls.desegment_ssl_records: TRUE'
            $WiresharkPreferences += 'tls.desegment_ssl_application_data: TRUE'
        } else {
            $WiresharkPreferences = $WiresharkPreferences | ForEach-Object {
                if ($_ -match 'tcp.desegment_tcp_streams') { $_ -replace '.*tcp.desegment_tcp_streams.*','tcp.desegment_tcp_streams: TRUE' }
                elseif ($_ -match 'tcp.reassemble_out_of_order') { $_ -replace '.*tcp.reassemble_out_of_order.*','tcp.reassemble_out_of_order: TRUE' }
                elseif ($_ -match 'tcp.try_heuristic_first') { $_ -replace '.*tcp.try_heuristic_first.*','tcp.try_heuristic_first: TRUE' }
                elseif ($_ -match 'tls.desegment_ssl_records') { $_ -replace '.*tls.desegment_ssl_records.*','tls.desegment_ssl_records: TRUE' }
                elseif ($_ -match 'tls.desegment_ssl_application_data') { $_ -replace '.*tls.desegment_ssl_application_data.*','tls.desegment_ssl_application_data: TRUE' }
                else { $_ }
             }
        }
        $WiresharkPreferences | Set-Content -Path $WiresharkPreferencesFile
    } catch {
        Write-Log -Message "Error configuring Wireshark settings ($($_.Exception.Message))" -Source "Main" -MessageType Error -DisplayInGui
    }
    $Global:ErrorActionPreference = 'continue'
}

function Test-Folder {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$FolderPath
	)

    $SyncHash.FolderValidated = $false

    if ($FolderPath -match "\w:\\?$") {
        Write-Display -Message " "
        Write-Log -Message "Drive root selected, please select a correct folder" -Source "Main" -MessageType Error -DisplayInGui
        Set-GuiLock -Action DisableAllExceptBrowser
        $SyncHash.FolderPath = $null
        $SyncHash.CustomerName = $null
        $SyncHash.SiteFolders = $null
        $SyncHash.OneDriveFQDN = $null
        return
    }
    if ($FolderPath -eq "") {
        Write-Display -Message " "
        Write-Log -Message "No folder selected, please select a correct folder" -Source "Main" -MessageType Error -DisplayInGui
        Set-GuiLock -Action DisableAllExceptBrowser
        $SyncHash.FolderPath = $null
        $SyncHash.CustomerName = $null
        $SyncHash.SiteFolders = $null
        $SyncHash.OneDriveFQDN = $null
        return
    }

    Write-Display -Message " "
    Write-Log -Message "Checking folder structure for path '$FolderPath'" -Source "Main" -MessageType Info -DisplayInGui
    if (-not (Test-Path $FolderPath)) {
        Write-Log -Message "Cannot find folder '$FolderPath'" -Source "Main" -MessageType Error -DisplayInGui
        Set-GuiLock -Action DisableAllExceptBrowser
        $SyncHash.FolderPath = $null
        $SyncHash.CustomerName = $null
        $SyncHash.SiteFolders = $null
        $SyncHash.OneDriveFQDN = $null
        return
    }

    $CustomerName = Split-Path $FolderPath -Leaf

    # Find only folders that contain NPA data
    $SiteFolders = Get-ChildItem $FolderPath | Where-Object { $_.PSIsContainer -and $_.Name -notmatch "!|LegacyOutput|vNextOutput" } | ForEach-Object {
        if (Get-ChildItem -Path $_.FullName -Recurse -Depth 2 | Where-Object { $_.Name -match "((dns|outlook|exo|teams|spo|mbup|mbdown).*\.(cap|pcap|pcapng))|(tracert|TracerouteResults)\.csv|(full-results\.(tsv|csv)|TeamsMediaQuality\.csv|ServiceConnectivity\.csv|websocket\.csv)"} ) { $_ }
    }
    if ($SiteFolders.Count -eq 0) {
        Write-Log -Message "Cannot find any site folder in '$FolderPath'" -Source "Main" -MessageType Error -DisplayInGui
        Write-Log -Message "Create at least one site folder and put data into it" -Source "Main" -MessageType Error -DisplayInGui
        Set-GuiLock -Action DisableAllExceptBrowser
        $SyncHash.FolderPath = $null
        $SyncHash.CustomerName = $null
        $SyncHash.SiteFolders = $null
        $SyncHash.OneDriveFQDN = $null
        return
    } else {
        Write-Log -Message "Following sites folders contain NPA data and will be analyzed:" -Source "Main" -MessageType Info -DisplayInGui
        foreach ($SiteFolder in $SiteFolders) {
            Write-Log -Message "   $($SiteFolder.Name)" -Source "Main" -MessageType Info -DisplayInGui
        }
        Write-Display -Message " "
    }
    Write-Log -Message "Folder path '$FolderPath' is correct" -Source "Main" -MessageType Info
    Set-GuiLock -Action Enable
    if ($SyncHash.GuiAnalyzerPath -ne $FolderPath) {
        Write-Log -Message "Saving path '$FolderPath' for reuse" -Source "Main" -MessageType Info
        [environment]::setEnvironmentVariable("GuiAnalyzerPath", $FolderPath, "User")
        $SyncHash.GuiAnalyzerPath = $FolderPath
        
        Write-Log -Message "Creating folder-specific runlog at path '$(Join-Path -Path $SyncHash.GuiAnalyzerPath -ChildPath "GuiAnalyzerRunlog.log")' and coying content of current runlog since last script start" -Source "Main" -MessageType Info
        $SyncHash.RunLogCurrentFolder = Join-Path -Path $SyncHash.GuiAnalyzerPath -ChildPath "GuiAnalyzerRunlog.log"
        $CurrentRunLogContent = Get-Content $SyncHash.RunLog -Last 50000
        $LastScriptStartLine = ($CurrentRunLogContent | Select-String -Pattern "####################################################################")[-2].LineNumber - 1
        $RunLogContentToCopy = $CurrentRunLogContent[$LastScriptStartLine..$CurrentRunLogContent.count]
        $RunLogContentToCopy | Out-File $SyncHash.RunLogCurrentFolder -Append -Encoding UTF8
        Write-Log -Message "Copied $($RunLogContentToCopy.count) lines" -Source "Main" -MessageType Info
    }
    $SyncHash.FolderValidated = $true
    $SyncHash.FolderPath = $FolderPath
    $SyncHash.CustomerName = $CustomerName
    $SyncHash.SiteFolders = $SiteFolders

    Write-Log -Message "Checking OneDrive FQDN using 'OneDriveFQDN' property from settings files" -Source "Main" -MessageType Info
    $JsonSettingsFiles = $SiteFolders | Get-ChildItem -Filter Settings.json -Recurse
    $XMLSettingsFiles = $SiteFolders | Get-ChildItem -Filter Settings.xml -Recurse
    if (($JsonSettingsFiles.count -gt 0) -or ($XMLSettingsFiles.count -gt 0)) {
        $SettingsFilesContent = @()
        if ($JsonSettingsFiles.count -gt 0) {
            Write-Log -Message "Found at least one json settings file" -Source "Main" -MessageType Info
            $SettingsFilesContent += $JsonSettingsFiles | Get-Content -Raw | ConvertFrom-Json
        }
        if ($XMLSettingsFiles.count -gt 0) {
            Write-Log -Message "Found at least one xml settings file" -Source "Main" -MessageType Info
            $SettingsFilesContent += $XMLSettingsFiles | Import-Clixml
        }
        $SyncHash.OneDriveFQDN = $SettingsFilesContent | Where-Object -Property OneDriveFQDN -NotLike "" | Sort-Object -Property OneDriveFQDN | Select-Object -ExpandProperty OneDriveFQDN -Unique

        if ($SyncHash.OneDriveFQDN -like "") {
            Write-Log -Message "OneDrive FQDN not found, retrying by using 'OneDriveURL' property" -Source "Main" -MessageType Info
            $SyncHash.OneDriveFQDN = $SettingsFilesContent | Where-Object -Property OneDriveURL -NotLike "" | Select-Object -Property @{Name="OneDriveFQDN";Expression={$_.OneDriveURL -replace 'https://(.*?)/.*','$1'}} | Sort-Object | Select-Object -ExpandProperty OneDriveFQDN -Unique
        }
        if ($SyncHash.OneDriveFQDN -notlike "") {
            Write-Log -Message "OneDrive FQDN found: $($SyncHash.OneDriveFQDN -join ',')" -Source "Main" -MessageType Info
        } else {
            Write-Log -Message "OneDrive FQDN not found using settings files" -Source "Main" -MessageType Warning
        }

    } else {
        Write-Log -Message "No settings files found, unable to find OneDrive FQDN" -Source "Main" -MessageType Warning
    }

}

function Test-Settings {
    if ($SyncHash.FolderValidated -ne $true -or $SyncHash.FolderPath -ne $SyncHash.InputFolderBox.Text) {
        Test-Folder -FolderPath $SyncHash.InputFolderBox.Text
    }
    Write-Log -Message "Folder path: $($SyncHash.FolderPath)" -Source "Main" -MessageType Info
    Write-Log -Message "Action: $($SyncHash.Action)" -Source "Main" -MessageType Info
    Write-Log -Message "DNS analysis: $($SyncHash.DNSAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Exchange analysis: $($SyncHash.EXOAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Teams analysis: $($SyncHash.TeamsAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Sharepoint analysis: $($SyncHash.SPOAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Viva analysis: $($SyncHash.VivaAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Copilot analysis: $($SyncHash.CopilotAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Microsoft domain analysis: $($SyncHash.MicrosoftDomainAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "File transfer analysis: $($SyncHash.FileTransferAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Tracert analysis: $($SyncHash.TracertAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Teams media quality analysis: $($SyncHash.TeamsMediaQualityAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "Service connectivity analysis: $($SyncHash.ServiceConnectivityAnalysis.Checked)" -Source "Main" -MessageType Info
    Write-Log -Message "WebSocket analysis: $($SyncHash.WebSocketAnalysis.Checked)" -Source "Main" -MessageType Info
    if ($Null -ne $SyncHash.TsharkPath -and $SyncHash.FolderValidated -eq $true) {
        return $true
    } else {
        return $false
    }
}

function Get-AzureDatacenterList {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$AzureDatacentersPath
	)

    Write-Log -Message "Loading Azure datacenters codes and locations" -Source "Main" -MessageType Info
    $AzureDatacentersList = Get-Content -Path $AzureDatacentersPath | ConvertFrom-Json
    Write-Log -Message "Found $($AzureDatacentersList.count) Azure datacenters codes" -Source "Main" -MessageType Info
    Write-Log -Message "Ordering Azure datacenters codes from longest to shortest" -Source "Main" -MessageType Info
    $AzureDatacenters = $AzureDatacentersList | Where-Object {$_.Code -notlike ""} | Select-Object -Property *,@{Name="Usage";Expression={$null}},@{Name="Length";Expression={$_.code.length}} | Sort-Object -Property Length,Code -Descending | Select-Object -Property Code,Country,Location,Latitude,Longitude,Usage
    return $AzureDatacenters
}

function Get-AzureDatacenterLocation {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Site
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Item
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$LogType
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Code
	)

    switch ($LogType) {
        "DNS" { $Usage = "DNS" }
        "EXO" { $Usage = "Exchange" }
        "Teams" { $Usage = "Teams" }
        "SPO" { $Usage = "Sharepoint" }
        "Viva" { $Usage = "Viva" }
        "Copilot" {
            if ($Item -match "CopilotWeb") { $Usage = "CopilotWeb"}
            if ($Item -match "CopilotWork") { $Usage = "CopilotWork"}
            if ($Item -match "CopilotOffice") { $Usage = "CopilotOffice"}
        }
        "MicrosoftDomain" {
            if ($Item -match "CloudMicrosoft") { $Usage = "CloudMicrosoft"}
            if ($Item -match "StaticMicrosoft") { $Usage = "StaticMicrosoft"}
            if ($Item -match "UsercontentMicrosoft") { $Usage = "UsercontentMicrosoft"}
        }
        "TeamsMediaQuality" { $Usage = "TeamsMedia" }
        "ServiceConnectivity" { $Usage = "ServiceConnectivity" }
        "Tracert" { $Usage = "PeeringPoint" }
        "WebSocket" { $Usage = "WebSocket" }
    }

    # Load Azure datacenters list if it hasn't been loaded yet
    if ($SyncHash.AzureDatacenters.count -eq 0) {
        $SyncHash.AzureDatacenters = Get-AzureDatacenterList -AzureDatacentersPath $SyncHash.AzureDatacentersPath
    }

    Write-Log -Message "[$Site/$($Item.Name)] Finding Azure datacenter location for code '$Code'" -Source "$LogType" -MessageType Info
    $DatacenterFound = $null
    if ($Code -match "^US_\d+_content") {
        Write-Log -Message "[$Site/$($Item.Name)] Generic US response code found" -Source "$LogType" -MessageType Info
        $DatacenterFound = New-Object PSObject -Property ([ordered]@{
            Code	    = "US"
            Country		= "United States"
            Location	= "United States"
            Latitude	= 39.8333333
            Longitude	= -98.585522
            Usage		= $Usage
        })
        return $DatacenterFound
    }

    if ($Code -match "\.farm\..*sharepoint.*") {
        Write-Log -Message "[$Site/$($Item.Name)] Unable to find location based on Sharepoint farm name" -Source "$LogType" -MessageType Warning
        return $null
    }

    if ($Code -match "\d{4}.*msedge\.net") {
        Write-Log -Message "[$Site/$($Item.Name)] Unable to find location based on msedge.net fqdn" -Source "$LogType" -MessageType Warning
        return $null
    }

    if ($Code -match "trafficmanager\.net|\.tm.*\.office\.com") {
        Write-Log -Message "[$Site/$($Item.Name)] Unable to find location based on trafficmanager fqdn" -Source "$LogType" -MessageType Warning
        return $null
    }

    if ($Code -match "acdc.*\.office\.com" -and $Code -notmatch "-efz\.") {
        Write-Log -Message "[$Site/$($Item.Name)] Unable to find location based on anycast DNS on Cafe (ACDC) fqdn" -Source "$LogType" -MessageType Warning
        return $null
    }

    # Looking up with "code*" (left part matching)
    foreach ($Datacenter in $SyncHash.AzureDatacenters) {
        if ($Code -like "$($Datacenter.Code)*") {
            $DatacenterFound = $Datacenter.PsObject.Copy()
            $DatacenterFound.Usage = $Usage
            Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
            return $DatacenterFound
        }
    }
    # Looking up with "*code*" (any part matching)
    foreach ($Datacenter in $SyncHash.AzureDatacenters) {
        if ($Code -like "*$($Datacenter.Code)*") {
            $DatacenterFound = $Datacenter.PsObject.Copy()
            $DatacenterFound.Usage = $Usage
            if ($Code -match "Sharepoint" -and $DatacenterFound.Code -eq "sha") {
                Write-Log -Message "[$Site/$($Item.Name)] Discarding invalid datacenter code found for Sharepoint" -Source "$LogType" -MessageType Warning
                return $null
            } else {
                Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
                return $DatacenterFound
            }
        }
    }
    $ReversedAzureDatacenters = [System.Collections.ArrayList]$Synchash.AzureDatacenters
    $ReversedAzureDatacenters.Reverse()
    # If datacenter code not found yet, apply specific logic for "<code>R\d[a-z]\d?"
    if ($Code -match "^(.*?)(R)(\d)([a-z])\d?") {
        # Looking up with "<code>\dR\d[a-z]"
        foreach ($Datacenter in $ReversedAzureDatacenters) {
            if ($Datacenter.Code -match "^$($matches[1])\d?$($matches[2])$($matches[3])$($matches[4])") {
                $DatacenterFound = $Datacenter.PsObject.Copy()
                $DatacenterFound.Usage = $Usage
                Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
                return $DatacenterFound
            }
        }
    }
    if ($Code -match "^(.*?)(R)(\d)") {
        # Looking up with "<code>\dR\d"
        foreach ($Datacenter in $ReversedAzureDatacenters) {
            if ($Datacenter.Code -match "^$($matches[1])\d?$($matches[2])$($matches[3])") {
                $DatacenterFound = $Datacenter.PsObject.Copy()
                $DatacenterFound.Usage = $Usage
                Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
                return $DatacenterFound
            }
        }
    }
    if ($Code -match "^(.*?)(R)") {
        # Looking up with "<code>"
        foreach ($Datacenter in $ReversedAzureDatacenters) {
            if ($Datacenter.Code -match "^$($matches[1])$") {
                $DatacenterFound = $Datacenter.PsObject.Copy()
                $DatacenterFound.Usage = $Usage
                Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
                return $DatacenterFound
            }
        }
        # Looking up with "<code>\d"
        foreach ($Datacenter in $ReversedAzureDatacenters) {
            if ($Datacenter.Code -match "^$($matches[1])\d?") {
                $DatacenterFound = $Datacenter.PsObject.Copy()
                $DatacenterFound.Usage = $Usage
                Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
                return $DatacenterFound
            }
        }
        # Looking up with "<code>\dR"
        foreach ($Datacenter in $ReversedAzureDatacenters) {
            if ($Datacenter.Code -match "^$($matches[1])\d?$($matches[2])") {
                $DatacenterFound = $Datacenter.PsObject.Copy()
                $DatacenterFound.Usage = $Usage
                Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
                return $DatacenterFound
            }
        }
        # Looking up with "<code>*"
        foreach ($Datacenter in $ReversedAzureDatacenters) {
            if ($Datacenter.Code -match "^$($matches[1])") {
                $DatacenterFound = $Datacenter.PsObject.Copy()
                $DatacenterFound.Usage = $Usage
                Write-Log -Message "[$Site/$($Item.Name)] Datacenter found: Code=$($DatacenterFound.Code) - Country=$($DatacenterFound.Country) - Location=$($DatacenterFound.Location) - Lat=$($DatacenterFound.Latitude) - Lon=$($DatacenterFound.Longitude)" -Source "$LogType" -MessageType Info
                return $DatacenterFound
            }
        }
    }
    Write-Log -Message "[$Site/$($Item.Name)] No Azure datacenter found for code '$Code'" -Source "$LogType" -MessageType Warning
}

function Get-LocationFromIpconfig {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Site
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$LogType
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$IPConfigFile
	)

    $IPConfigContent = $IPConfigFile | Get-Content


    $xml = @()
    $xml += @'
<?xml version="1.0"?>
<PositionByNetwork xmlns="http://inference.location.live.com" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
 <RequestHeader>
  <Timestamp>%Timestamp%</Timestamp>
  <ApplicationId>d414dd4f9db345fa8003e32adc81b362</ApplicationId>
 </RequestHeader>
 <BeaconFingerprint>
  <Detections>
'@

    $BSSID = $null
    foreach ($Line in $IPConfigContent) {
        Write-Host $Line
        Read-Host
        if ($Line -match "\s+BSSID\s+\d+\s+:") {
            $BSSID = ($Line -replace '.*:\s+(.*)$','$1') -replace ':','-'
            $ProcessNextLine = $true
        } else {
            if ($ProcessNextLine) {
                $Strength = $Line -replace '.*:\s+(.*)%.*$','$1'
                [int]$dbm = $Strength/2-100
                $xml += ('   <Wifi7 BssId="'+$BSSID+'" rssi="'+$dbm+'" cf="-2147483648"/>')
            }
            $ProcessNextLine = $false
        }
    }

    $xml += @'
  </Detections>
 </BeaconFingerprint>
</PositionByNetwork>
'@

    if ($BSSID -notlike "") {
        $Timestamp = Get-Date ((Get-Date).ToUniversalTime()) -Format 'yyyy-MM-ddTHH:mm:ss.fffZ'
        $xml = $xml -replace '%Timestamp%',$Timestamp

        Write-Log -Message "[$Site] Sending BSSID data: $xml" -Source "$LogType" -MessageType Info

        $HttpResponse = Invoke-WebRequest -Method Post -Uri "https://inference.location.live.net/inferenceservice/v21/Pox/PositionByNetwork" -Body $xml -ContentType 'application/xml'
        $LocationType = ([xml]$HttpResponse).PositionByNetworkResponse.PositionByNetworkResult.LocationResult.ResolverStatus.Source
        $LocationResult = ([xml]$HttpResponse).PositionByNetworkResponse.PositionByNetworkResult.LocationResult.ResolvedPosition | Select-Object -Property Latitude,Longitude
        $Latitude = $LocationResult.Latitude
        $Longitude = $LocationResult.Longitude
        if ($LocationType -eq "Internal") {
            Write-Log -Message "[$Site] Location service found a location, getting location name" -Source "$LogType" -MessageType Info
            $GeoLookup = ([xml](Invoke-WebRequest -Uri "https://nominatim.openstreetmap.org/reverse?zoom=10&format=xml&accept-language=en-us&lat=$($Latitude)&lon=$($Longitude)").Content).Reversegeocode
            $Location = $GeoLookup.result.'#text'
            $Country = $Location -replace '.*,\s*(.*)','$1'
            Write-Log -Message "[$Site] Location=$Location" -Source "$LogType" -MessageType Info
            Write-Log -Message "[$Site] Country=$Country - Latitude=$Latitude - Longitude=$Longitude" -Source "$LogType" -MessageType Info
            return $Location,$Country,$Latitude,$Longitude
        } else {
            Write-Log -Message "[$Site] Location service could NOT find a location" -Source "$LogType" -MessageType Warning
            return
        }
    } else {
        Write-Log -Message "[$Site] No BSSID data found in IPConfig file" -Source "$LogType" -MessageType Warning
        return
    }
}

function Get-PrimaryDns {

    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Site
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$LogType
	)

    Write-Log -Message "[$Site] Finding primary DNS for site '$Site'" -Source "$LogType" -MessageType Info
    $PrimaryDNS = $null

    $IPConfigFileList = Get-ChildItem $Site.FullName -Recurse | Where-Object { $_.extension -match "\.(txt|log)$" -and $_.Name -match "ipconfig" } | Sort-Object -Property Name -Descending
    if ($IPConfigFileList.Count -ge 1) {
        foreach ($IPConfigFile in $IPConfigFileList) {
            Write-Log -Message "[$Site] Checking in ipconfig file: $($IPConfigFile.FullName)" -Source "$LogType" -MessageType Info
            $IPConfigContent = Get-Content $IPConfigFile.FullName
            $LineWithDNS = $IPConfigContent | Where-Object { $_ -match "npaprimarydns" } | Select-Object -First 1
            if (-not $LineWithDNS) {
                $LineWithDNS = $IPConfigContent | Where-Object { $_ -match "dhcpnameserver" } | Select-Object -First 1
            }
            if (-not $LineWithDNS) {
                $LineWithDNS = $IPConfigContent | Where-Object { $_ -match "nameserver" -and $_ -match "\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b" }
                if ($LineWithDNS.count -ge 1) {
                    $LineWithDNS = ($LineWithDNS | Select-Object -Last 1) -split " " | Select-Object -Last 1
                    $PrimaryDNS = $LineWithDNS -split "," | Select-Object -First 1
                }
            }
            if (-not $LineWithDNS) {
                $LineWithDNS = $IPConfigContent | Where-Object { $_ -match "DNS.* (\. )+.*\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"} | Select-Object -First 1
                if ($LineWithDNS.count -ge 1) {
                    $PrimaryDNS = ($LineWithDNS | Select-Object -Last 1) -split " " | Select-Object -Last 1
                }
            }
            if ($LineWithDNS -and -not $PrimaryDNS) {
                $PrimaryDNS = $LineWithDNS -split '\s' | Where-Object { $_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Select-Object -First 1
            }

            if ($PrimaryDNS) {
                break
            }
        }

        if ($PrimaryDNS) {
            Write-Log -Message "[$Site] Primary DNS found: $PrimaryDNS" -Source "$LogType" -MessageType Info
        } else {
            Write-Log -Message "[$Site] Unable to find a primary DNS" -Source "$LogType" -MessageType Error
            $PrimaryDNS = ""
        }
    } else {
        Write-Log -Message "[$Site] No ipconfig file found, unable to get primary DNS" -Source "$LogType" -MessageType Warning
        $PrimaryDNS = ""
    }

    return $PrimaryDNS
}

function Start-AsyncTask {
    Param(
        $Workload
    )

    $AnalysisType = Switch ($Workload) {
        "Status" {$null}
        "DNS" {"NetworkTrace"}
        "EXO" {"NetworkTrace"}
        "Teams" {"NetworkTrace"}
        "SPO" {"NetworkTrace"}
        "Viva" {"NetworkTrace"}
        "Copilot" {"NetworkTrace"}
        "MicrosoftDomain" {"NetworkTrace"}
        "FileTransfer" {"NetworkTrace"}
        "Tracert" {"Csv"}
        "TeamsMediaQuality" {"Csv"}
        "ServiceConnectivity" {"Csv"}
        "WebSocket" {"Csv"}
        "Sites" {"Csv"}
    }

    # Runspace building for the task
    $newRunspace = [runspacefactory]::CreateRunspace()
    $newRunspace.ApartmentState = "MTA"
    $newRunspace.ThreadOptions = "UseNewThread"
    if ($Workload -eq "Status") {
        $newRunspace.Name = "GuiAnalyzer_Status"
    } else {
        $newRunspace.Name = "GuiAnalyzer_Analysis_$Workload"
    }
    $newRunspace.Open()
    $newRunspace.SessionStateProxy.SetVariable("SyncHash", $SyncHash)
    $newRunspace.SessionStateProxy.SetVariable("Workload", $Workload)
    $newRunspace.SessionStateProxy.SetVariable("AnalysisType", $AnalysisType)

    $powershell_CurrentTask = [PowerShell]::Create().AddScript({

        Import-Module $SyncHash.ModulePath -Force -DisableNameChecking | Out-Null
        
        if ($Workload -eq "Status") {

            while ($SyncHash.TotalFilesProcessed -ne $SyncHash.TotalFilesToProcess) {
                Start-Sleep -Seconds 1
                $SyncHash.TotalFilesProcessed = $SyncHash.DNSFilesProcessed + $SyncHash.EXOFilesProcessed + $SyncHash.TeamsFilesProcessed + $SyncHash.SPOFilesProcessed + $SyncHash.VivaFilesProcessed + $SyncHash.CopilotFilesProcessed + $SyncHash.MicrosoftDomainFilesProcessed + $SyncHash.FileTransferFilesProcessed + $SyncHash.TracertFilesProcessed + $SyncHash.TeamsMediaQualityFilesProcessed + $SyncHash.ServiceConnectivityFilesProcessed + $SyncHash.WebSocketFilesProcessed + $SyncHash.SitesProcessed
                $PercentageCompleted = [math]::Round(($SyncHash.TotalFilesProcessed * 100 / $SyncHash.TotalFilesToProcess),1)
                $SyncHash.progressBar.Value = $PercentageCompleted
                $SyncHash.progressBar.Update()
                
                $ActiveAnalysis = ((Get-Runspace | Where-Object {$_.Name -match "GuiAnalyzer_Analysis_.*" -and $_.RunspaceAvailability -eq "Busy"} | Sort-Object -Property Name).Name -replace 'GuiAnalyzer_Analysis_(.*)','$1') -Join ' / '

                # Calculate time remaining every 5 seconds
                if ((Get-Date).Second % 5 -eq 0) {
                    $TimeElapsed = New-TimeSpan $SyncHash.StartTimeStamp (Get-Date)
                    $HighestTimeRemaining = $null

                    if (($SyncHash.DNSFilesProcessed - $SyncHash.DNSFilesSkipped) -gt 0 -and $SyncHash.DNSFilesToProcess -gt 0 -and $SyncHash.DNSAnalysisStatus.Text -ne "100%") {
                        $DNSTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.DNSFilesProcessed - $SyncHash.DNSFilesSkipped) * ($SyncHash.DNSFilesToProcess - $SyncHash.DNSFilesProcessed)
                        if ($DNSTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $DNSTimeRemaining }
                    }

                    if (($SyncHash.EXOFilesProcessed - $SyncHash.EXOFilesSkipped) -gt 0 -and $SyncHash.EXOFilesToProcess -gt 0 -and $SyncHash.EXOAnalysisStatus.Text -ne "100%") {
                        $EXOTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.EXOFilesProcessed - $SyncHash.EXOFilesSkipped) * ($SyncHash.EXOFilesToProcess - $SyncHash.EXOFilesProcessed)
                        if ($EXOTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $EXOTimeRemaining }
                    }

                    if (($SyncHash.TeamsFilesProcessed - $SyncHash.TeamsFilesSkipped) -gt 0 -and $SyncHash.TeamsFilesToProcess -gt 0 -and $SyncHash.TeamsAnalysisStatus.Text -ne "100%") {
                        $TeamsTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.TeamsFilesProcessed - $SyncHash.TeamsFilesSkipped) * ($SyncHash.TeamsFilesToProcess - $SyncHash.TeamsFilesProcessed)
                        if ($TeamsTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $TeamsTimeRemaining }
                    }

                    if (($SyncHash.SPOFilesProcessed - $SyncHash.SPOFilesSkipped) -gt 0 -and $SyncHash.SPOFilesToProcess -gt 0 -and $SyncHash.SPOAnalysisStatus.Text -ne "100%") {
                        $SPOTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.SPOFilesProcessed - $SyncHash.SPOFilesSkipped) * ($SyncHash.SPOFilesToProcess - $SyncHash.SPOFilesProcessed)
                        if ($SPOTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $SPOTimeRemaining }
                    }

                    if (($SyncHash.VivaFilesProcessed - $SyncHash.VivaFilesSkipped) -gt 0 -and $SyncHash.VivaFilesToProcess -gt 0 -and $SyncHash.VivaAnalysisStatus.Text -ne "100%") {
                        $VivaTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.VivaFilesProcessed - $SyncHash.VivaFilesSkipped) * ($SyncHash.VivaFilesToProcess - $SyncHash.VivaFilesProcessed)
                        if ($VivaTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $VivaTimeRemaining }
                    }

                    if (($SyncHash.CopilotFilesProcessed - $SyncHash.CopilotFilesSkipped) -gt 0 -and $SyncHash.CopilotFilesToProcess -gt 0 -and $SyncHash.CopilotAnalysisStatus.Text -ne "100%") {
                        $CopilotTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.CopilotFilesProcessed - $SyncHash.CopilotFilesSkipped) * ($SyncHash.CopilotFilesToProcess - $SyncHash.CopilotFilesProcessed)
                        if ($CopilotTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $CopilotTimeRemaining }
                    }

                    if (($SyncHash.MicrosoftDomainFilesProcessed - $SyncHash.MicrosoftDomainFilesSkipped) -gt 0 -and $SyncHash.MicrosoftDomainFilesToProcess -gt 0 -and $SyncHash.MicrosoftDomainAnalysisStatus.Text -ne "100%") {
                        $MicrosoftDomainTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.MicrosoftDomainFilesProcessed - $SyncHash.MicrosoftDomainFilesSkipped) * ($SyncHash.MicrosoftDomainFilesToProcess - $SyncHash.MicrosoftDomainFilesProcessed)
                        if ($MicrosoftDomainTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $MicrosoftDomainTimeRemaining }
                    }

                    if (($SyncHash.FileTransferFilesProcessed - $SyncHash.FileTransferFilesSkipped) -gt 0 -and $SyncHash.FileTransferFilesToProcess -gt 0 -and $SyncHash.FileTransferAnalysisStatus.Text -ne "100%") {
                        $FileTransferTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.FileTransferFilesProcessed - $SyncHash.FileTransferFilesSkipped) * ($SyncHash.FileTransferFilesToProcess - $SyncHash.FileTransferFilesProcessed)
                        if ($FileTransferTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $FileTransferTimeRemaining }
                    }

                    if (($SyncHash.TracertFilesProcessed - $SyncHash.TracertFilesSkipped) -gt 0 -and $SyncHash.TracertFilesToProcess -gt 0 -and $SyncHash.TracertAnalysisStatus.Text -ne "100%") {
                        $TracertTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.TracertFilesProcessed - $SyncHash.TracertFilesSkipped) * ($SyncHash.TracertFilesToProcess - $SyncHash.TracertFilesProcessed)
                        if ($TracertTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $TracertTimeRemaining }
                    }

                    if (($SyncHash.TeamsMediaQualityFilesProcessed - $SyncHash.TeamsMediaQualityFilesSkipped) -gt 0 -and $SyncHash.TeamsMediaQualityFilesToProcess -gt 0 -and $SyncHash.TeamsMediaQualityAnalysisStatus.Text -ne "100%") {
                        $TeamsMediaQualityTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.TeamsMediaQualityFilesProcessed - $SyncHash.TeamsMediaQualityFilesSkipped) * ($SyncHash.TeamsMediaQualityFilesToProcess - $SyncHash.TeamsMediaQualityFilesProcessed)
                        if ($TeamsMediaQualityTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $TeamsMediaQualityTimeRemaining }
                    }

                    if (($SyncHash.ServiceConnectivityFilesProcessed - $SyncHash.ServiceConnectivityFilesSkipped) -gt 0 -and $SyncHash.ServiceConnectivityFilesToProcess -gt 0 -and $SyncHash.ServiceConnectivityAnalysisStatus.Text -ne "100%") {
                        $ServiceConnectivityTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.ServiceConnectivityFilesProcessed - $SyncHash.ServiceConnectivityFilesSkipped) * ($SyncHash.ServiceConnectivityFilesToProcess - $SyncHash.ServiceConnectivityFilesProcessed)
                        if ($ServiceConnectivityTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $ServiceConnectivityTimeRemaining }
                    }

                    if (($SyncHash.WebSocketFilesProcessed - $SyncHash.WebSocketFilesSkipped) -gt 0 -and $SyncHash.WebSocketFilesToProcess -gt 0 -and $SyncHash.WebSocketAnalysisStatus.Text -ne "100%") {
                        $WebSocketTimeRemaining = $TimeElapsed.TotalSeconds / ($SyncHash.WebSocketFilesProcessed - $SyncHash.WebSocketFilesSkipped) * ($SyncHash.WebSocketFilesToProcess - $SyncHash.WebSocketFilesProcessed)
                        if ($WebSocketTimeRemaining -gt $HighestTimeRemaining) { $HighestTimeRemaining = $WebSocketTimeRemaining }
                    }
                    
                    $TimeRemaining = [timespan]::FromSeconds([math]::Round($HighestTimeRemaining))
                    $TimeRemainingDisplay = ""
                    if ($TimeRemaining.TotalHours -gt 1) {$TimeRemainingDisplay += "$($TimeRemaining.Hours)h"}
                    if ($TimeRemaining.TotalMinutes -gt 1) {$TimeRemainingDisplay += "$($TimeRemaining.Minutes)m"}
                    if ($TimeRemaining.TotalSeconds -gt 1) {$TimeRemainingDisplay += "$($TimeRemaining.Seconds)s"}

                }

                # Do not update the status if the analysis was manually stopped
                if ($SyncHash.StartButton.Text -ne "Start") {
                    if ($SyncHash.StartButton.Text -eq "Resume") { $AnalysisStatus = "Paused" }
                    if ($SyncHash.StartButton.Text -eq "Pause") { $AnalysisStatus = "Working" }
                    $SyncHash.StatusLabel.Text = "$AnalysisStatus - Files processed: $($SyncHash.TotalFilesProcessed)/$($SyncHash.TotalFilesToProcess) ($PercentageCompleted%) - Time left: $TimeRemainingDisplay - Active analysis: $ActiveAnalysis"
                }
            }
            $SyncHash.EndTimeStamp = Get-Date
            $TotalTimeTaken = New-TimeSpan $SyncHash.StartTimeStamp $SyncHash.EndTimeStamp
            Write-Display -Message " "
            Write-Log -Message "Completed data analysis at: $(Get-DateInFile)" -Source "Main" -MessageType Info -DisplayInGui
            Write-Log -Message "Data analysis done in: $($TotalTimeTaken.Days) days $($TotalTimeTaken.Hours) hours $($TotalTimeTaken.Minutes) minutes $($TotalTimeTaken.Seconds) seconds" -Source "Main" -MessageType Info -DisplayInGui
            $SyncHash.StatusLabel.Text = "Done"

            Set-GuiLock -Action Enable
            $SyncHash.CancelButton.Enabled = $false
            $SyncHash.StartButton.Text = "Start"

            Get-Runspace | Where-Object {$_.Name -match "GuiAnalyzer_Analysis_.*"} | ForEach-Object {$_.Close()}
            Get-Runspace | Where-Object {$_.Name -match "GuiAnalyzer_Analysis_.*"} | ForEach-Object {$_.Dispose()}

        } else {

            if ($AnalysisType -eq "NetworkTrace") {
                Invoke-NetworkTracesAnalysis -Workload $Workload
            } else {
                Invoke-CsvAnalysis -Workload $Workload
            }
            
        }
    })

    $powershell_CurrentTask.Runspace = $newRunspace
    $powershell_CurrentTask.BeginInvoke() | Out-Null

    # Cleanup runspaces whenever the threads close
    $null = Register-ObjectEvent -InputObject $powershell_CurrentTask -EventName InvocationStateChanged -Action {
        param([System.Management.Automation.PowerShell] $ps)
        # NOTE: Use $EventArgs.InvocationStateInfo, not $ps.InvocationStateInfo, 
        #       as the latter is updated in real-time, so for a short-running script
        #       the state may already have changed since the event fired.
        $state = $EventArgs.InvocationStateInfo.State
        if ($state -in 'Completed', 'Failed') {
            $ps.Runspace.Close()
            $ps.Runspace.Dispose()
            # Speed up resource release by calling the garbage collector explicitly.
            # Note that this will pause *all* threads briefly.
            [GC]::Collect()
        }

    }

}

function Invoke-DNSAnalysis {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$ResultsFile
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Site
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Item
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$PrimaryDNS
	)

    Write-Log -Message "[$Site/$($Item.Name)] Trying to analyze DNS requests to O365 for trace '$($item.FullName)'" -Source "DNS" -MessageType Info

    $AnalysisStartTime = Get-Date
    $ExpectedDNSServer = $Item.Name -replace '.*DNS.*?-(\d+\.\d+\.\d+\.\d+).*\.pcapng','$1'

    $Filter = "dns.qry.type == 1"
    
    $DateTime, $Date, $Time, $DayIndex, $Hour = Get-TimestampInfo $item
    try {
        $RawDnsPackets = .$SyncHash.TsharkPath -r ('"'+ $item.FullName + '"') -Y $Filter -T fields -e frame.time_relative -e udp.stream `
            -e dns.flags.response -e ip.src -e ip.dst -e dns.qry.name -e dns.cname -e ip.ttl -e icmp.code -e tcp.stream -e dns.flags.rcode -e dns.id `
            -E separator=';' -o tls.keylog_file:null
    } catch {
        Write-Log -Message "[$Site/$($Item.Name)] Error opening file with Tshark ($($_.Exception.Message))" -Source "DNS" -MessageType Error -DisplayInGui
        if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
            $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
            if ($OriginalTraceFile.FullName) {
                Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "DNS" -MessageType Info -DisplayInGui
                Invoke-DNSAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile -PrimaryDNS $PrimaryDNS
                return
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "DNS" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file with Tshark"
                return
            }
        } else {
            Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "DNS" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file (and unfiltered file) with Tshark"
            return
        }
    }
    
    $DNSPackets = $RawDnsPackets | ConvertFrom-Csv -Delimiter ";" -Header "TimeRelative","UDPStream",
        "DNSFlagResponse","SourceIP","DestinationIP","DNSQueryName","DNSResponseName","DNSTTL","ICMPcode","TCPstream","DNSResponseCode","DNSTransactionID"

    $O365FQDNList = @(
        [pscustomobject]@{FQDNFilter="^outlook.office365.com$";Service="Exchange"},
        [pscustomobject]@{FQDNFilter="^outlook.office365.us$";Service="Exchange"},
        [pscustomobject]@{FQDNFilter="^outlook-dod.office365.us$";Service="Exchange"},
        [pscustomobject]@{FQDNFilter="^teams.microsoft.com$";Service="Teams"},
        [pscustomobject]@{FQDNFilter="^gov.teams.microsoft.us$";Service="Teams"},
        [pscustomobject]@{FQDNFilter="^dod.teams.microsoft.us$";Service="Teams"},
        [pscustomobject]@{FQDNFilter="^worldaz.tr.teams.microsoft.com$";Service="TeamsMedia"},
        [pscustomobject]@{FQDNFilter="^tr.gov.teams.microsoft.us$";Service="TeamsMedia"},
        [pscustomobject]@{FQDNFilter="^tr.dod.teams.microsoft.us$";Service="TeamsMedia"},
        [pscustomobject]@{FQDNFilter="^.*sharepoint.com$";Service="Sharepoint"},
        [pscustomobject]@{FQDNFilter="^.*sharepoint.us$";Service="Sharepoint"},
        [pscustomobject]@{FQDNFilter="^.*sharepoint-mil.us$";Service="Sharepoint"},
        [pscustomobject]@{FQDNFilter="^.*(yammer|viva).*$";Service="Viva"}
        [pscustomobject]@{FQDNFilter="^.*(copilot.cloud.microsoft).*$";Service="CopilotWeb"}
        [pscustomobject]@{FQDNFilter="^.*(m365.cloud.microsoft).*$";Service="CopilotWeb"}
        [pscustomobject]@{FQDNFilter="^.*(substrate.svc.cloud.microsoft).*$";Service="CopilotWork"}
        [pscustomobject]@{FQDNFilter="^.*(augloop.svc.cloud.microsoft).*$";Service="CopilotOffice"}
        [pscustomobject]@{FQDNFilter="^.*(connectivity-test.cloud.microsoft).*$";Service="CloudMicrosoft"}
        [pscustomobject]@{FQDNFilter="^.*(connectivity-test.static.microsoft).*$";Service="StaticMicrosoft"}
        [pscustomobject]@{FQDNFilter="^.*(connectivity-test.usercontent.microsoft).*$";Service="UsercontentMicrosoft"}
    )

    if ($SyncHash.OneDriveFQDN -notlike "") {
        foreach ($OneDriveFQDN in $SyncHash.OneDriveFQDN) {
            $O365FQDNList += [pscustomobject]@{FQDNFilter="^.*$OneDriveFQDN$";Service="Sharepoint"}
        }
    }

    $DNSQueriesO365 = @()
    foreach ($O365FQDN in $O365FQDNList) {
        $DNSQueriesO365 += $DNSPackets | Where-Object {$_.DNSQueryName -match $O365FQDN.FQDNFilter} | ForEach-Object {
            if (-not ($_ | Get-Member -Name Service)) { $_ | Add-Member -MemberType NoteProperty -Name 'Service' -Value $O365FQDN.Service -PassThru } else { $_ }
        }
    }

    $DNSStreams = @()
    $DNSQueriesO365 | ForEach-Object {
        # Keep only DNS streams with an actual query captured
        if ($_.DNSFlagResponse -eq $false) {
            if ($_.UDPStream -match '\d+') {
                $Stream = "UDP $($_.UDPStream) $($_.DNSQueryName) $($_.Service) $($_.DNSTransactionID)"
            } elseif ($_.TCPStream -match '\d+') {
                $Stream = "TCP $($_.TCPStream) $($_.DNSQueryName) $($_.Service) $($_.DNSTransactionID)" 
            }
            if ($Stream -notin $DNSStreams) { $DNSStreams += $Stream }
        }
    }
    $DNSQueriesO365 = $DNSQueriesO365 | Sort-Object -Property UDPStream,TCPStream,TimeRelative

    $NumberOfDnsStreams = ($DNSStreams | Measure-Object).count
    if ( $NumberOfDnsStreams -eq 0 ) {
        Write-Log -Message "[$Site/$($Item.Name)] No DNS request to O365 found" -Source "DNS" -MessageType Error -DisplayInGui
        if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
            $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
            if ($OriginalTraceFile.FullName) {
                Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "DNS" -MessageType Info -DisplayInGui
                Invoke-DNSAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile -PrimaryDNS $PrimaryDNS
                return
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "DNS" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No DNS request to O365 found"
                return
            }
        } else {
            Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "DNS" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No DNS request to O365 found (filtered and unfiltered file)"
            return
        }
    } else {
        Write-Log -Message "[$Site/$($Item.Name)] Found $NumberOfDnsStreams DNS requests to O365" -Source "DNS" -MessageType Info
    }

    foreach ($DNSStream in $DNSStreams) {
        
        $StreamType,$StreamId,$DNSFQDN,$Service,$DNSTransactionID = ($DNSStream -split '\s')

        if ($StreamType -eq "UDP") {
            $DNSRequest = $DNSQueriesO365 | Where-Object {$_.UDPStream -eq $StreamId -and $_.DNSTransactionID -eq $DNSTransactionID -and $_.DNSQueryName -eq $DNSFQDN -and ($_.DNSFlagResponse -eq 0 -or $_.DNSFlagResponse -eq $false)}
            $DNSResponse = $DNSQueriesO365 | Where-Object {$_.UDPStream -eq $StreamId -and $_.DNSTransactionID -eq $DNSTransactionID -and $_.DNSQueryName -eq $DNSFQDN -and ($_.DNSFlagResponse -eq 1 -or $_.DNSFlagResponse -eq $true)}
            Write-Log -Message "[$Site/$($Item.Name)] Analysing $Service DNS request to O365 (UDP stream $StreamID - Transaction ID $DNSTransactionID - $DNSFqdn)" -Source "DNS" -MessageType Info
        } elseif ($StreamType -eq "TCP") {
            $DNSRequest = $DNSQueriesO365 | Where-Object {$_.TCPStream -eq $StreamId -and $_.DNSTransactionID -eq $DNSTransactionID -and $_.DNSQueryName -eq $DNSFQDN -and ($_.DNSFlagResponse -eq 0 -or $_.DNSFlagResponse -eq $false)}
            $DNSResponse = $DNSQueriesO365 | Where-Object {$_.TCPStream -eq $StreamId -and $_.DNSTransactionID -eq $DNSTransactionID -and $_.DNSQueryName -eq $DNSFQDN -and ($_.DNSFlagResponse -eq 1 -or $_.DNSFlagResponse -eq $true)}
            Write-Log -Message "[$Site/$($Item.Name)] Analysing $Service DNS request to O365 (TCP stream $StreamID - Transaction ID $DNSTransactionID - $DNSFqdn)" -Source "DNS" -MessageType Info
        }

        if (($DNSRequest | Measure-Object).count -gt 1) {
            Write-Log -Message "[$Site/$($Item.Name)] Found more than 1 DNS query, using only the last one" -Source "DNS" -MessageType Warning
            $DNSRequest = $DNSRequest | Select-Object -Last 1
        }

        $DNSServer = $DNSRequest.DestinationIP
        if($DNSServer -eq $PrimaryDNS){
            $IsPrimaryDNS = 1
        } else {
            $IsPrimaryDNS = 0
        }

        if ($DNSServer -notlike $ExpectedDNSServer) {
            Write-Log -Message "[$Site/$($Item.Name)] Unexpected DNS server found (expected: $ExpectedDNSServer / contacted: $DNSServer)" -Source "DNS" -MessageType Warning
        }

        if ($DNSResponse) {

            if (($DNSResponse | Measure-Object).count -gt 1) {
                Write-Log -Message "[$Site/$($Item.Name)] Found more than 1 DNS response, using only the last one" -Source "DNS" -MessageType Warning
                $DNSResponse = $DNSResponse | Select-Object -Last 1
            } else {
                Write-Log -Message "[$Site/$($Item.Name)] Found corresponding DNS response" -Source "DNS" -MessageType Info
            }

            if ($DNSResponse.DNSResponseCode -eq 3) {
                Write-Log -Message "[$Site/$($Item.Name)] DNS response = 'No such name'" -Source "DNS" -MessageType Warning
                $DNSResponseFqdn = "NotFound"
                $Datacenter = $null
            } elseif ($DNSResponse.DNSResponseName -like "") {
                Write-Log -Message "[$Site/$($Item.Name)] DNS response = 'Empty response'" -Source "DNS" -MessageType Warning
                $DNSResponseFqdn = "NotFound"
                $Datacenter = $null
            } else {
                $DNSResponseFqdn = $DNSResponse.DNSResponseName -split "," | Select-Object -Last 1
                Write-Log -Message "[$Site/$($Item.Name)] DNS response = '$DNSResponseFqdn'" -Source "DNS" -MessageType Info
                $Datacenter = Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType "DNS" -Code $DNSResponseFqdn
                if ($Datacenter.Usage -notlike "") { $Datacenter.Usage = "$($Datacenter.Usage)-$Service"}
            }

            $DNSTTL = [int]$DNSResponse.DNSTTL

            $Hops = 0
            if ($DNSTTL -le 64) {
                $Hops = 64 - $DNSTTL + 1
            } elseif ($DNSTTL -le 128) {
                $Hops = 128 - $DNSTTL + 1
            } elseif ($DNSTTL -le 255) {
                $Hops = 255 - $DNSTTL + 1
            }

            $DNSLatency = (([math]::Round(([double]$DNSResponse.TimeRelative - [double]$DNSRequest.TimeRelative),4)*1000) -replace ",",".")

        } else {

            Write-Log -Message "[$Site/$($Item.Name)] Unable to find a corresponding DNS response" -Source "DNS" -MessageType Warning
            $DNSResponseFqdn = "NoResponse"
            $DNSTTL = ""
            $Hops = ""
            $DNSLatency = $null
            $Datacenter = $null

        }

        Write-Log -Message "[$Site/$($Item.Name)] DNS analysis results:" -Source "DNS" -MessageType Info
        Write-Log -Message "[$Site/$($Item.Name)] FQDN=$DNSFQDN - DNS=$DNSServer - DNSLatency=$DNSLatency - Response=$DNSResponseFqdn" -Source "DNS" -MessageType Info
        Write-Log -Message "[$Site/$($Item.Name)] DatacenterCode=$($Datacenter.Code) - DatacenterCountry=$($Datacenter.Country) - DatacenterLocation=$($Datacenter.Location)" -Source "DNS" -MessageType Info
        Write-Log -Message "[$Site/$($Item.Name)] DatacenterLatitude=$($Datacenter.Latitude) - DatacenterLongitude=$($Datacenter.Longitude) - DatacenterUsage=$($Datacenter.Usage)" -Source "DNS" -MessageType Info
        Add-Content -Encoding UTF8 -Path $ResultsFile -Value (( $item.Name, $DateTime, $Date, $Time, $DayIndex, $Hour, $Site.Name, $DNSLatency, $DNSServer, $DNSFQDN, $DNSResponseFqdn, `
            $DNSTTL, $Hops, $IsPrimaryDNS, $Service, `
            $Datacenter.Code, $Datacenter.Country, $Datacenter.Location, `
            $Datacenter.Latitude, $Datacenter.Longitude, $Datacenter.Usage) -join $SyncHash.ListSeparator)
    }
    Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "DNS" -AnalysisStartTime $AnalysisStartTime -Result "Ok" -Reason ""                    
}

function Invoke-WebConnectivityAnalysis {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$ResultsFile
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Site
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Item
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$PrimaryDNS
        ,
        [Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Workload
	)
    Write-Log -Message "[$Site/$($Item.Name)] Trying to analyze requests for trace '$($item.FullName)'" -Source "$Workload" -MessageType Info
    $AnalysisStartTime = Get-Date
    $DateTime, $Date, $Time, $DayIndex, $Hour = Get-TimestampInfo $item

    # Match a TCP SYN / TLS Client/Server Hello / TLS Certificate
    $Filter = '(tcp.flags.syn==1) or (tls.handshake.type==1) or (tls.handshake.type==2) or (tls.handshake.type==11) or (tls.handshake.type == 14) or (x509af.serialNumber)'
    # Match a TLS Client/Server Hello/New Session Ticket
    $Filter += ' or (tcp.payload matches \"\x16\x03(\x01|\x02|\x03)[\x00-\xFF]{2}(\x01|\x02|\x04)\")'
    # Match a certificate name
    $Filter += ' or (tcp.payload matches \"\x55\x04\x03(\x0c|\x13)\")'
    # Match on multiple certificates extensions
    $Filter += ' or (tcp.payload matches \"(\x55\x1d.*){2,}\")'
    # Match an HTTP connect or HTTP response
    $Filter += ' or (tcp.payload matches \"\x48\x54\x54\x50\x2f\")'

    switch ($Workload) {
        "EXO" {            
            $FQDNList = @(
                #"customdomain.com",
                "outlook.com",
                "outlook.office365.com",
                "outlook-dod.office365.us",
                "outlook.office365.us",
                "webmail.apps.mil",
                "pod51501.office365.us",
                "frontdoor"
            )
        }
        "Teams" {
            $FQDNList = @(
                #"customdomain.com",
                "teams.microsoft.com",
                "gov.teams.microsoft.us",
                "dod.teams.microsoft.us",
                "frontdoor"
            )
        }
        "SPO" {
            $FQDNList = @(
                #"customdomain.com",
                "sharepoint.com",
                "sharepoint-mil.us",
                "dps.mil",
                "sharepoint.us",
                "spo-ring.msedge.net",
                "frontdoor"
            )

            if ($SyncHash.OneDriveFQDN -notlike "") {
                foreach ($OneDriveFQDN in $SyncHash.OneDriveFQDN) {
                    $FQDNList += $OneDriveFQDN
                }
            }
        }
        "Viva" {
            $FQDNList = @(
                #"customdomain.com",
                "web.yammer.com",
                "frontdoor"
            )
        }
        "Copilot" {
            $FQDNList = @(
                #"customdomain.com",
                "copilot.cloud.microsoft",
                "m365.cloud.microsoft",
                "substrate.svc.cloud.microsoft",
                "augloop.svc.cloud.microsoft",
                "frontdoor"
            )
        }
        "MicrosoftDomain" {
            $FQDNList = @(
                #"customdomain.com",
                "connectivity-test.cloud.microsoft",
                "connectivity-test.static.microsoft",
                "connectivity-test.usercontent.microsoft",
                "frontdoor"
            )
        }
    }

    foreach ($FQDN in $FQDNList) {
        $Filter +=  ' or (dns.qry.name contains \"' + $FQDN + '\")'
    }

    try {
        if ((Test-Path "$(Split-Path $SyncHash.TsharkPath)\capinfos.exe") -and $item.Length -lt 6kb) {
            # Get number of packets in the file (-c = packet count / -T = table format / -m = separate with commas / -r = skip headers line)
            $NumberOfPackets = (& "$(Split-Path $SyncHash.TsharkPath)\capinfos.exe" $item.FullName -c -T -m -r) -split "," | Select-Object -Last 1
            if ($NumberOfPackets -eq 0) {
                throw "No packets found in file"
            } elseif ($NumberOfPackets -notmatch '\d+') {
                throw "Unable to get a valid number of packets"
            }
        }
        Write-Log -Message "[$Site/$($Item.Name)] Fetching raw packets" -Source "$Workload" -MessageType Info
        $PreviousEncoding = [Console]::OutputEncoding
        # Temporarily switch to UTF8 to avoid issues with special characters in the output
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        # Create a temporary file to store tshark error output
        $TemporaryErrorFile = [System.IO.Path]::GetTempFileName()
        $RawOutput = .$SyncHash.TsharkPath -r ('"'+ $item.FullName + '"') -Y $Filter -x -T json -2 -o tls.keylog_file:null `
                        --disable-protocol http,http2,http3 --disable-heuristic hipercontracer_icmp,hipercontracer_icmpv6,hipercontracer_udp,hipercontracer_tcp `
                        2> $TemporaryErrorFile
                        # Disable protocols that can mess with analysis, and redirect tshark error output to a temp file
        [Console]::OutputEncoding = $PreviousEncoding
        if ($RawOutput -notlike "") {
            Remove-Item -Path $TemporaryErrorFile -ErrorAction SilentlyContinue
            Write-Log -Message "[$Site/$($Item.Name)] Converting raw output to objects" -Source "$Workload" -MessageType Info
            $RawPackets = $RawOutput | ConvertFrom-Json
            if ($RawPackets.count -eq 0) {
                throw "No packets matching filter"
            }
        } else {
            throw "No output from Tshark"
        }
    } catch {
        Write-Log -Message "[$Site/$($Item.Name)] Error opening file with Tshark ($($_.Exception.Message))" -Source "$Workload" -MessageType Error -DisplayInGui
        $TemporaryErrorFileContent = Get-Content -Path $TemporaryErrorFile -ErrorAction SilentlyContinue
        if ($TemporaryErrorFileContent -notlike "") {
            Write-Log -Message "[$Site/$($Item.Name)] Tshark error output:" -Source "$Workload" -MessageType Error
            $TemporaryErrorFileContent | ForEach-Object {
                Write-Log -Message "[$Site/$($Item.Name)] >> $($_)" -Source "$Workload" -MessageType Error
            }
        }
        Remove-Item -Path $TemporaryErrorFile -ErrorAction SilentlyContinue
        if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
            $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
            if ($OriginalTraceFile.FullName) {
                Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "$Workload" -MessageType Info -DisplayInGui
                Invoke-WebConnectivityAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile -PrimaryDNS $PrimaryDNS -Workload $Workload
                return
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file with Tshark"
                return
            }
        } else {
            Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file (and unfiltered file) with Tshark"
            return
        }
    }

    Write-Log -Message "[$Site/$($Item.Name)] Processing packets" -Source "$Workload" -MessageType Info
    $Packets = @()
    foreach ($Packet in $RawPackets) {
        $FrameDetails = $Packet.'_source'.layers.frame
        $IPDetails = $Packet.'_source'.layers.ip
        $TCPDetails = $Packet.'_source'.layers.tcp
        $UDPDetails = $Packet.'_source'.layers.udp
        $DNSDetails = $Packet.'_source'.layers.dns
        $TLSDetails = $Packet.'_source'.layers.tls
        $PacketComment = $Packet.'_source'.layers.'pkt_comment'.'frame.comment'
        
        $CurrentPacketInfo = New-Object PSObject -Property ([ordered]@{
            TimeRelative                = $FrameDetails.'frame.time_relative'
            Protocols                   = $FrameDetails.'frame.protocols'
            TCPStream                   = $TCPDetails.'tcp.stream'
            SourceIP                    = $IPDetails.'ip.src'
            SourcePort                  = $TCPDetails.'tcp.srcport'
            DestinationIP               = $IPDetails.'ip.dst'
            DestinationPort             = $TCPDetails.'tcp.dstport'
            FlagSYN                     = $TCPDetails.'tcp.flags_tree'.'tcp.flags.syn'
            FlagACK                     = $TCPDetails.'tcp.flags_tree'.'tcp.flags.ack'
            TTL                         = $IPDetails.'ip.ttl'
            FlagDF                      = $IPDetails.'ip.flags_tree'.'ip.flags.df'
            MSS                         = $TCPDetails.'tcp.options_tree'.'tcp.options.mss_tree'.'tcp.options.mss_val'
            WindowScaling               = $TCPDetails.'tcp.options_tree'.'tcp.options.wscale_tree'.'tcp.options.wscale.shift'
            FlagSACK                    = $TCPDetails.'tcp.options_tree'.'tcp.options.sack_perm' -replace ':'
            FlagTimestamp               = $null
            TLSPacket                   = $null
            TLSHandhshakeType           = $null
            TLSServerNameIndication     = $null
            TLSCertificateSerialNumbers = $null
            TLSCertificatesString       = $null
            TLSCertificates             = @()
            HTTPPacket                  = $null
            HTTPPacketContent           = $null
            HTTPConnectHost             = $null
            HTTPConnectUserAgent        = $null
            HTTPProxyAuthentication     = $null
            HTTPProxyAgent              = $null
            UDPStream                   = $UDPDetails.'udp.stream'
            DNSFlagResponse             = $DNSDetails.'dns.flags_tree'.'dns.flags.response'
            DNSQueryName                = $null
            DNSResponseName             = $null
            PacketComment               = $PacketComment
        })
        
        # Match a TLS handshake
        if ($TCPDetails.'tcp.payload' -match '16:03:(01|02|03):..:..:0(1|2|4)' -or `
        # Match a certificate cname
        ($TCPDetails.'tcp.payload' -match '55:04:03:(0c|13)') -or `
        # Match on multiple certificates extensions
        $TCPDetails.'tcp.payload' -match '(55:1d:(0|1|2).*){2,}') {
            $CurrentPacketInfo.TLSPacket = $true
        } else {
            # Match on TLS details found by Tshark
            if ($TLSDetails.'tls.record_raw') {
                $CurrentPacketInfo.TLSPacket = $true
                # split every two characters with a semicolon (hex format) and set that as the TCP payload of that packet
                $TCPDetails.'tcp.payload' = (($TLSDetails.'tls.record_raw' | Where-Object {$_ -match '^160303'}) -split '(..)' -ne '') -join ':'
            } else {
                $CurrentPacketInfo.TLSPacket = $false
            }
        }
        
        # Match on HTTP/ messages
        if ($TCPDetails.'tcp.payload' -match '48:54:54:50:2f') {
            $CurrentPacketInfo.HTTPPacket = $true
            $CurrentPacketInfo.HTTPPacketContent = ($TCPDetails.'tcp.payload' -split ':' | ForEach-Object { [char][byte]"0x$_" }) -join ''
            $SplitPacketContent = $CurrentPacketInfo.HTTPPacketContent -split "`r`n" | Where-Object {$_ -notlike ""}

            if ($SplitPacketContent | Where-Object {$_ -match "Host: .*"}) {
                # Get the HTTP Host from current HTTP message
                $CurrentPacketInfo.HTTPConnectHost = ($SplitPacketContent | Where-Object {$_ -match "Host: .*"}) -replace '.*Host: (.*?)(:\d+)?$','$1'
            } else {
                # Get the HTTP Host from previous HTTP messages
                $PreviousHTTPPacketsForCurrentStream = $Packets | Where-Object {$_.TCPStream -eq $CurrentPacketInfo.TCPStream -and $_.HTTPPacket -eq $true}
                $PreviousHTTPConnectHost = ($PreviousHTTPPacketsForCurrentStream | Where-Object {$_.HTTPConnectHost -notlike ""} | Select-Object -First 1).HTTPConnectHost
                if ($PreviousHTTPConnectHost) { $CurrentPacketInfo.HTTPConnectHost = $PreviousHTTPConnectHost }
            }

            if ($SplitPacketContent | Where-Object {$_ -match "User-Agent: .*"}) {
                $CurrentPacketInfo.HTTPConnectUserAgent = ($SplitPacketContent | Where-Object {$_ -match "User-Agent: .*"}) -replace '.*User-Agent: (.*)$','$1'
            }

            if ($SplitPacketContent | Where-Object {$_ -match "Proxy-Agent: .*"}) {
                $CurrentPacketInfo.HTTPProxyAgent = ($SplitPacketContent | Where-Object {$_ -match "Proxy-Agent: .*"}) -replace '.*Proxy-Agent: (.*)$','$1'
            }

            if ($SplitPacketContent | Where-Object {$_ -match "407 Proxy Auth Required|Proxy-Authorization:"}) {
                $CurrentPacketInfo.HTTPProxyAuthentication = $true
            }
        } else {
            $CurrentPacketInfo.HTTPPacket = $false
        }
        
        if ($DNSDetails) {
            $CurrentPacketInfo.DNSQueryName = ($DNSDetails.Queries -join '') -replace '@{(.*?):.*','$1'
            $CurrentPacketInfo.DNSResponseName = ((($DNSDetails.Answers -join '') -split ', cname ' | Select-Object -Skip 1) -replace '(.*?)=;.*','$1') -join ','
        }
                
        if ($CurrentPacketInfo.TLSPacket -eq $true) {
            # Match a TLS Client Hello
            if ($TCPDetails.'tcp.payload' -match '16:03:(01|02|03):..:..:01') {
                $CurrentPacketInfo.TLSHandhshakeType = 1
                # Match an SNI extension
                if ($TCPDetails.'tcp.payload' -match '00:00:00:..:00:..:00:00:(..):(.*)') {
                    $TextLength, $ServerNameHex = ($TCPDetails.'tcp.payload' -replace '.*?00:00:00:..:00:..:00:00:(..):(.*)','$1-$2') -split "-"
                    $TextLength = [System.Convert]::ToInt64($TextLength, 16)
                    $ServerName = (($ServerNameHex -split ':')[0..($TextLength-1)]| foreach-object {[char][byte]"0x$_" }) -join ''
                    $CurrentPacketInfo.TLSServerNameIndication = $ServerName
                }
            # Match a TLS Server Hello
            } elseif ($TCPDetails.'tcp.payload' -match '16:03:(01|02|03):..:..:02') {
                $CurrentPacketInfo.TLSHandhshakeType = 2
            # Match a TLS New Session Ticket
            } elseif ($TCPDetails.'tcp.payload' -match '16:03:(01|02|03):..:..:04') {
                $CurrentPacketInfo.TLSHandhshakeType = 4
            }

            # Match a certificate cname or multiple certificates extensions
            if ($TCPDetails.'tcp.payload' -match '55:04:03:(0c|13)' -or $TCPDetails.'tcp.payload' -match '(55:1d:(0|1|2).*){2,}' ) {
                if ($CurrentPacketInfo.TLSHandhshakeType -notlike "") {
                    $CurrentPacketInfo.TLSHandhshakeType = ($CurrentPacketInfo.TLSHandhshakeType, '11') -join ','
                } else {
                    $CurrentPacketInfo.TLSHandhshakeType = 11
                }
            }
            
            # Match a certificate cname
            if ($TCPDetails.'tcp.payload' -match '55:04:03:(0c|13)' ) {

                # Match the start of a certificate
                if ($TCPDetails.'tcp.payload' -match ':30:82:..:..:a0:03:02:01:..:02:(?:10|13):') {
                    $RawCertificatesList = $TCPDetails.'tcp.payload' -split ':30:82:..:..:a0:03:02:01:..:02:(?:10|13):' | Select-Object -Skip 1
                } else {
                    $RawCertificatesList = $TCPDetails.'tcp.payload'
                }

                foreach ($RawCertificate in $RawCertificatesList) {
                    $CurrentCertificate = New-Object PSObject -Property ([ordered]@{
                        SerialNumber	= $null
                        Name			= $null
                        Issuer			= $null
                    })

                    # Match certificate serial number followed by signature and issuer
                    if ($RawCertificate -match '30:..:06:..:(.*:30:..:31:..:30)') {
                        $CertificateSerialNumber = ($RawCertificate -replace '(.*?):30:..:06:..:((.*:30:..:31:..:30).*)','$1')
                        $RestOfCertificate = ($RawCertificate -replace '(.*?):30:..:06:..:((.*:30:..:31:..:30).*)','$2')
                        # $CurrentCertificate.SerialNumber = $CertificateSerialNumber -replace ':',''
                    } else {
                        $RestOfCertificate = $RawCertificate
                    }							
                    
                    if ($RestOfCertificate -match ':30:..:06:03:55:04:03:(0c|13):(.*)') {
                        # First part is information on the issuer certificate
                        $TextLength, $RestOfCertificate = (($RestOfCertificate -replace '.*?:30:..:06:03:55:04:03:(0c|13):(.*)','$2') -replace '(..):(.*)','$1-$2') -split "-"
                        $TextLength = [System.Convert]::ToInt64($TextLength, 16)
                        $IssuerCommonName = (($RestOfCertificate -split ':')[0..($TextLength-1)]| foreach-object {[char][byte]"0x$_" }) -join ''
                        $RestOfCertificate = (($RestOfCertificate -split ':') | Select-Object -Skip $TextLength) -join ':'
                        $CurrentCertificate.Issuer = "$IssuerCommonName"
                    }
                    
                    if ($RestOfCertificate -match ':30:..:06:03:55:04:03:(0c|13):(.*)') {
                        # Second part is information on the certificate itself
                        $TextLength, $RestOfCertificate = (($RestOfCertificate -replace '.*?:30:..:06:03:55:04:03:(0c|13):(.*)','$2') -replace '(..):(.*)','$1-$2') -split "-"
                        $TextLength = [System.Convert]::ToInt64($TextLength, 16)
                        $CertCommonName = (($RestOfCertificate -split ':')[0..($TextLength-1)]| foreach-object {[char][byte]"0x$_" }) -join ''
                        $CurrentCertificate.Name = "$CertCommonName"
                    }
                    
                    $CurrentPacketInfo.TLSCertificates += $CurrentCertificate
                }
                $CurrentPacketInfo.TLSCertificateSerialNumbers = if ($CurrentPacketInfo.TLSCertificates.SerialNumber -notlike "") { $CurrentPacketInfo.TLSCertificates.SerialNumber -join ',' }
                $CurrentPacketInfo.TLSCertificatesString = ($CurrentPacketInfo.TLSCertificates | ForEach-Object { "Name=$($_.Name)" , "Issuer=$($_.Issuer)" }) -join ','
            }       
        }
        
        if ($CurrentPacketInfo.FlagSYN -eq 1 -or $CurrentPacketInfo.TLSPacket -eq $true -or $CurrentPacketInfo.HTTPPacket -eq $true -or $DNSDetails) {
            $Packets += $CurrentPacketInfo
        }
    }

    $TCPPackets = $Packets | Where-Object {$_.TCPStream -notlike ""}
    $DNSQueries = $Packets | Where-Object {($_.DNSFlagResponse -eq 0 -or $_.DNSFlagResponse -eq $false) -and $_.DNSQueryName -match ($FQDNList -join '|') -and $_.DNSQueryName -notmatch "config.teams"}

    Write-Log -Message "[$Site/$($Item.Name)] Checking TLS handshake information" -Source "$Workload" -MessageType Info
    $TLSClientHelloList = $TCPPackets | Where-Object {$_.TLSHandhshakeType -eq 1 -and $_.TLSServerNameIndication -match ($FQDNList -join '|') -and $_.TLSServerNameIndication -notmatch "config.teams"}
    $TLSResponsePackets = $null
    foreach ($TLSClientHello in $TLSClientHelloList) {
        Write-Log -Message "[$Site/$($Item.Name)] Found a TLS Client Hello with stream ID: $($TLSClientHello.TCPStream)" -Source "$Workload" -MessageType Info
        $TLSResponsePackets = $TCPPackets | Where-Object {$_.TCPStream -eq $TLSClientHello.TCPStream -and $_.TLSPacket -eq $true -and $_.SourceIP -eq $TLSClientHello.DestinationIP}
        if ($TLSResponsePackets | Where-Object {$_.TLSCertificatesString -notlike ""}) {
            Write-Log -Message "[$Site/$($Item.Name)] Found a corresponding TLS Server Hello" -Source "$Workload" -MessageType Info
            break
        } else {
            Write-Log -Message "[$Site/$($Item.Name)] No corresponding TLS Server Hello found" -Source "$Workload" -MessageType Info
            $TLSResponsePackets = $null
        }
    }
    
    if ($TLSResponsePackets) {
        Write-Log -Message "[$Site/$($Item.Name)] Found a valid TLS handshake" -Source "$Workload" -MessageType Info
        $FQDN = ($TLSClientHelloList | Where-Object {$_.TCPStream -eq $TLSClientHello.TCPStream -and $_.TLSServerNameIndication -notlike ""} | Select-Object -Last 1).TLSServerNameIndication
        $TLSLatency = (([math]::Round(([double]($TLSResponsePackets | Select-Object -First 1).TimeRelative - [double]($TLSClientHelloList | Where-Object {$_.TCPStream -eq $TLSClientHello.TCPStream} | Select-Object -Last 1).TimeRelative), 4) * 1000).ToString() -replace ",", ".")
        $LastMicrosoftCA = $TLSResponsePackets.TLSCertificates | Where-Object {$_.Issuer -match 'Entrust .* Certification Authority|Baltimore CyberTrust Root|Digicert Global Root|Microsoft Azure RSA'} | Select-Object -Last 1
        if ($LastMicrosoftCA) {
            $TLSCertificateIssuerEntity = "Microsoft"
            $TLSCertificateIssuer = $LastMicrosoftCA.Issuer
            $TLSCertificateSerialNumber = $LastMicrosoftCA.SerialNumber
            $TLSInspection = $false
        } else {
            $LastCA = $TLSResponsePackets.TLSCertificates | Select-Object -Last 1
            $TLSCertificateIssuerEntity = "Other"
            $TLSCertificateIssuer = $LastCA.Issuer
            $TLSCertificateSerialNumber = $LastCA.SerialNumber
            $TLSInspection = $true
        }

        Write-Log -Message "[$Site/$($Item.Name)] Checking TCP handshake information" -Source "$Workload" -MessageType Info
        $TCPSYN = $TCPPackets | Where-Object {$_.TCPStream -eq $TLSClientHello.TCPStream -and $_.FlagSYN -eq 1 -and $_.FlagACK -eq 0}
        $TCPSYNACK = $TCPPackets | Where-Object {$_.TCPStream -eq $TLSClientHello.TCPStream -and $_.FlagSYN -eq 1 -and $_.FlagACK -eq 1}

        $NumberOfTCPSYN = ($TCPSYN | Measure-Object).count
        $NumberOfTCPSYNACK = ($TCPSYNACK | Measure-Object).count

        if ($NumberOfTCPSYN -eq 0 -or $NumberOfTCPSYNACK -eq 0) {
            Write-Log -Message "[$Site/$($Item.Name)] No valid TCP handshake found" -Source "$Workload" -MessageType Error -DisplayInGui
            if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
                $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
                if ($OriginalTraceFile.FullName) {
                    Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "$Workload" -MessageType Info -DisplayInGui
                    Invoke-WebConnectivityAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile -PrimaryDNS $PrimaryDNS -Workload $Workload
                    return
                } else {
                    Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No valid TCP handshake found"
                    return
                }
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No valid TCP handshake found (filtered and unfiltered file)"
                return
            }
        }

        if ($NumberOfTCPSYN -eq $NumberOfTCPSYNACK) {
            if ($NumberOfTCPSYN -gt 1) {
                Write-Log -Message "[$Site/$($Item.Name)] Found duplicate TCP handshake (multiple SYN/SYNACK), using the first occurences" -Source "$Workload" -MessageType Warning
                $TCPSYN = $TCPSYN | Select-Object -First 1
                $TCPSYNACK = $TCPSYNACK | Select-Object -First 1
            } else {
                Write-Log -Message "[$Site/$($Item.Name)] Found a valid TCP handshake" -Source "$Workload" -MessageType Info
            }
        } else {
            if ($NumberOfTCPSYN -gt $NumberOfTCPSYNACK) {
                Write-Log -Message "[$Site/$($Item.Name)] Found duplicate TCP handshake (duplicate SYN), using the last occurences" -Source "$Workload" -MessageType Warning
                $TCPSYN = $TCPSYN | Select-Object -Last 1
                $TCPSYNACK = $TCPSYNACK | Select-Object -Last 1
            } else {
                Write-Log -Message "[$Site/$($Item.Name)] Found duplicate TCP handshake (duplicate SYNACK), using the first occurences" -Source "$Workload" -MessageType Warning
                $TCPSYN = $TCPSYN | Select-Object -First 1
                $TCPSYNACK = $TCPSYNACK | Select-Object -First 1
            }
        }

        $TCPLatency = (([math]::Round(([double]$TCPSYNACK.TimeRelative - [double]$TCPSYN.TimeRelative), 4) * 1000).ToString() -replace ",", ".")
        $TotalConnectionTime = (([math]::Round(([double]($TLSResponsePackets | Select-Object -Last 1).TimeRelative - [double]$TCPSYN.TimeRelative), 4) * 1000).ToString() -replace ",", ".")

        # DF flag
        if ($TCPSYN.FlagDF -eq "1" -and $TCPSYNACK.FlagDF -eq "1") {
            $FlagDF = "1"
            $FlagDFLimitingSide = "Both"
        } elseif ($TCPSYN.FlagDF -eq "0" -and $TCPSYNACK.FlagDF -eq "1") {
            $FlagDF = "0"
            $FlagDFLimitingSide = "Client"
        } elseif ($TCPSYN.FlagDF -eq "1" -and $TCPSYNACK.FlagDF -eq "0") {
            $FlagDF = "0"
            $FlagDFLimitingSide = "Remote"
        } elseif ($TCPSYN.FlagDF -eq "0" -and $TCPSYNACK.FlagDF -eq "0") {
            $FlagDF = "0"
            $FlagDFLimitingSide = "Both"
        } else {
            $FlagDF = "0"
            $FlagDFLimitingSide = "Both"
        }
        # MSS
        if ($TCPSYN.MSS -eq $TCPSYNACK.MSS) {
            $MSS = $TCPSYN.MSS
            $MSSLimitingSide = "Both"
        } elseif ($TCPSYN.MSS -lt $TCPSYNACK.MSS) {
            $MSS = $TCPSYN.MSS
            $MSSLimitingSide = "Client"
        } elseif ($TCPSYN.MSS -gt $TCPSYNACK.MSS) {
            $MSS = $TCPSYNACK.MSS
            $MSSLimitingSide = "Remote"
        }
        # WindowScaling
        # Fix empty WindowScaling values
        if ($TCPSYN.WindowScaling -like "") { $TCPSYN.WindowScaling = "0" }
        if ($TCPSYNACK.WindowScaling -like "") { $TCPSYNACK.WindowScaling = "0" }
        if ($TCPSYN.WindowScaling -eq $TCPSYNACK.WindowScaling) {
            if ($TCPSYN.WindowScaling -ne "0") {
                $WindowScaling = $TCPSYN.WindowScaling
                $WindowScalingLimitingSide = "Both"
            } else {
                $WindowScaling = $TCPSYN.WindowScaling
                $WindowScalingLimitingSide = "Client"
            }
        } elseif ($TCPSYN.WindowScaling -lt $TCPSYNACK.WindowScaling) {
            $WindowScaling = $TCPSYN.WindowScaling
            $WindowScalingLimitingSide = "Client"
        } elseif ($TCPSYN.WindowScaling -gt $TCPSYNACK.WindowScaling) {
            $WindowScaling = $TCPSYNACK.WindowScaling
            $WindowScalingLimitingSide = "Remote"
        }
        # SACK
        if ($TCPSYN.FlagSACK -notlike "" -and $TCPSYNACK.FlagSACK -notlike "") {
            $FlagSACK = "1"
            $FlagSACKLimitingSide = "Both"
        } elseif ($TCPSYN.FlagSACK -like "" -and $TCPSYNACK.FlagSACK -notlike "") {
            $FlagSACK = "0"
            $FlagSACKLimitingSide = "Client"
        } elseif ($TCPSYN.FlagSACK -notlike "" -and $TCPSYNACK.FlagSACK -like "") {
            $FlagSACK = "0"
            $FlagSACKLimitingSide = "Remote"
        } elseif ($TCPSYN.FlagSACK -like "" -and $TCPSYNACK.FlagSACK -like "") {
            $FlagSACK = "0"
            $FlagSACKLimitingSide = "Both"
        } else {
            $FlagSACK = "0"
            $FlagSACKLimitingSide = "Both"
        }
        $FlagTimestamp = if ($TCPSYN.FlagTimestamp -notlike "" -and $TCPSYNACK.FlagTimestamp -notlike "") {"1"} else {"0"}

    } else {
        Write-Log -Message "[$Site/$($Item.Name)] No valid TLS handshake found" -Source "$Workload" -MessageType Error -DisplayInGui
        if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
            $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
            if ($OriginalTraceFile.FullName) {
                Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "$Workload" -MessageType Info -DisplayInGui
                Invoke-WebConnectivityAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile -PrimaryDNS $PrimaryDNS -Workload $Workload
                return
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No valid TLS handshake found"    
                return
            }
        } else {
            Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No valid TLS handshake found (filtered and unfiltered file)"
            return
        }
    }

    Write-Log -Message "[$Site/$($Item.Name)] Checking proxy information" -Source "$Workload" -MessageType Info
    $ProxyPackets = $TCPPackets | Where-Object {$_.HTTPConnectHost -in $FQDNList -or ($_.TCPStream -eq $TLSClientHello.TCPStream -and $_.HTTPConnectHost -notlike "")}
    if ($ProxyPackets -or $TLSClientHello.PacketComment -match "TUNNEL2|NetskopeTunnel" -or $TLSClientHello.Protocols -match "^raw:ip" -or $TLSClientHello.DestinationIP -eq "127.0.0.1") {
        $ProxyDetected = $true
        # Check proxy authentication
        if ($ProxyPackets | Where-Object {$_.HTTPProxyAuthentication -eq $true}) {
            $ProxyAuthentication = $true
        } else {
            $ProxyAuthentication = $false
        }
        # Check user agent for proxy connection
        if ($ProxyPackets.HTTPConnectUserAgent) {
            $HTTPConnectUserAgentList = $ProxyPackets.HTTPConnectUserAgent | Select-Object -Unique
            $ProxyUserAgent = @()
            foreach ($UserAgent in $HTTPConnectUserAgentList) {
                # https://stackoverflow.com/questions/75463528/how-to-parse-user-agent-string-with-powershell-match-to-get-browser-and-os
                if ($UserAgent -match '^(?<browser1>.+?) \((?<os>.+?)\)(?: (?<engine>\S+(?: \(.+?\))?)(?: Version/(?<version>\S+(?: Mobile/\S+)?))?(?: (?<browser2>\S+))?(?: \S+? (?<browser4>\S+/\S+$))?)?') {
                    # Determine the true browser name and version.
                    $MatchedBrowser = if ($Matches.browser4) { $Matches.browser4 } elseif ($Matches.browser2) { $Matches.browser2 } else { $Matches.browser1 }
                    if ($Matches.version) { $MatchedBrowser = ($MatchedBrowser -split '/')[0] + '/' + $Matches.version }
                    # Output the captured substrings via a custom object.
                    # [pscustomobject] @{
                    #     OS = $Matches.os
                    #     Engine = $Matches.engine
                    #     Browser = $MatchedBrowser
                    # }

                    $ProxyUserAgent += $MatchedBrowser
                    
                } else {
                    $ProxyUserAgent += $UserAgent
                }
            }
            $ProxyUserAgent = $ProxyUserAgent -join ' ; '
        }

        # Check proxy type
        if ($TLSClientHello.PacketComment -match "TUNNEL2") {
            $ProxyType = "Zscaler Tunnel"
        } elseif ($TLSClientHello.PacketComment -match "NetskopeTunnel") {
            $ProxyType = "Netskope Tunnel"
        } elseif ($ProxyPackets.HTTPPacketContent -match "X-USWG") {
            $ProxyType = "Cisco Umbrella"
        } elseif ($TLSClientHello.Protocols -match "^raw:ip") {
            $ProxyType = "Unknown Tunnel"
        } elseif ($TLSClientHello.DestinationIP -eq "127.0.0.1") {
            $ProxyType = "Localhost Proxy"
        } elseif ($ProxyPackets.HTTPProxyAgent) {
            $ProxyType = ($ProxyPackets.HTTPProxyAgent | Select-Object -Unique) -join ' ; '
            # Add more logic to detect proxy types (Netskope, Cisco Umbrella...)
        } else {
            $ProxyType = "Unknown"
        }

    } else {
        $ProxyDetected = $false
        $ProxyAuthentication = $false
        $ProxyUserAgent = $null
        $ProxyType = $null
    }

    $Datacenter = $null
    $DetectionMethod = $null
    if ($DNSQueries | Where-Object {$_.DNSQueryName -match '\.frontdoor\.'}) {
        Write-Log -Message "[$Site/$($Item.Name)] Found a front door dummy DNS query" -Source "$Workload" -MessageType Info
        $DNSResponseFqdn = ($DNSQueries | Where-Object {$_.DNSQueryName -match '\.frontdoor\.'} | Select-Object -First 1).DNSQueryName -split '\.' | Select-Object -First 1
        $Datacenter = Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code $DNSResponseFqdn
        if ($null -ne $Datacenter) { $DetectionMethod = "Server" }
    } else {
        Write-Log -Message "[$Site/$($Item.Name)] No front door dummy DNS query found" -Source "$Workload" -MessageType Info
    }
    
    if ($null -eq $Datacenter) {
        if ($ProxyDetected -eq $true) {
            Write-Log -Message "[$Site/$($Item.Name)] Proxy detected, skipping DNS analysis" -Source "$Workload" -MessageType Info
        } else {
            Write-Log -Message "[$Site/$($Item.Name)] Attempting to find contacted datacenter using DNS queries" -Source "$Workload" -MessageType Info
            $DNSResponse = $null
            foreach ($DNSQuery in $DNSQueries) {
                if (-not $DNSResponse) {
                    if ($DNSQuery.UDPStream -match '\d+') {
                        $DNSResponse = $Packets | Where-Object {$_.UDPStream -eq $DNSQuery.UDPStream -and ($_.DNSFlagResponse -eq 1 -or $_.DNSFlagResponse -eq $true) -and $_.DNSResponseName -notlike ""} | Select-Object -First 1
                    } elseif ($DNSQuery.TCPStream -match '\d+') {
                        $DNSResponse = $Packets | Where-Object {$_.TCPStream -eq $DNSQuery.TCPStream -and ($_.DNSFlagResponse -eq 1 -or $_.DNSFlagResponse -eq $true) -and $_.DNSResponseName -notlike ""} | Select-Object -First 1
                    }
                }
            }
    
            if ($DNSResponse) {
                Write-Log -Message "[$Site/$($Item.Name)] Found a valid DNS response" -Source "$Workload" -MessageType Info
                $DNSResponseFqdn = $DNSResponse.DNSResponseName -split "," | Select-Object -Last 1
                $Datacenter = Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code $DNSResponseFqdn
                if ($null -ne $Datacenter) {
                    $DetectionMethod = "DNS"
                    $Datacenter.Usage = "DNS-$($Datacenter.Usage)"
                }
            } else {
                Write-Log -Message "[$Site/$($Item.Name)] Unable to find a valid DNS response" -Source "$Workload" -MessageType Warning
                $Datacenter = $null
            }
        }
    }

    Write-Log -Message "[$Site/$($Item.Name)] TLS stream analysis result:" -Source "$Workload" -MessageType Info
    Write-Log -Message "[$Site/$($Item.Name)] FQDN=$FQDN - Destination=$($TCPSYN.DestinationIP):$($TCPSYN.DestinationPort) - TLSLatency=$TLSLatency - TCPLatency=$TCPLatency - TotalConnectionTime=$TotalConnectionTime - TTL=$($TCPSYNACK.TTL)" -Source "$Workload" -MessageType Info
    Write-Log -Message "[$Site/$($Item.Name)] DFFlag=$FlagDF ($FlagDFLimitingSide) - MSS=$MSS ($MSSLimitingSide) - WindowScaling=$WindowScaling ($WindowScalingLimitingSide) - SACK=$FlagSACK ($FlagSACKLimitingSide) - Timestamp=$FlagTimestamp - TLSInspection=$TLSInspection - CA=$TLSCertificateIssuerEntity ($TLSCertificateIssuer)" -Source "$Workload" -MessageType Info
    Write-Log -Message "[$Site/$($Item.Name)] ProxyDetected=$ProxyDetected - ProxyAuthentication=$ProxyAuthentication - ProxyType=$ProxyType - ProxyUserAgent=$ProxyUserAgent" -Source "$Workload" -MessageType Info
    Write-Log -Message "[$Site/$($Item.Name)] DetectionMethod=$DetectionMethod - DatacenterCode=$($Datacenter.Code) - DatacenterCountry=$($Datacenter.Country) - DatacenterLocation=$($Datacenter.Location)" -Source "$Workload" -MessageType Info
    Write-Log -Message "[$Site/$($Item.Name)] DatacenterLatitude=$($Datacenter.Latitude) - DatacenterLongitude=$($Datacenter.Longitude) - DatacenterUsage=$($Datacenter.Usage)" -Source "$Workload" -MessageType Info
    Add-Content -Encoding UTF8 -Path $ResultsFile -Value (( $item.Name, $DateTime, $Date, $Time, $DayIndex, $Hour, $Site.Name, `
        $FQDN, $($TCPSYN.DestinationIP), $($TCPSYN.DestinationPort), $TLSLatency, $TCPLatency, $TotalConnectionTime, $TCPSYNACK.TTL, `
        $FlagDF, $FlagDFLimitingSide, $MSS, $MSSLimitingSide, $WindowScaling, $WindowScalingLimitingSide, `
        $FlagSACK, $FlagSACKLimitingSide, $FlagTimestamp, $TLSInspection, "$TLSCertificateIssuerEntity ($TLSCertificateIssuer)", $TLSCertificateSerialNumber, `
        $ProxyDetected, $ProxyAuthentication, $ProxyType, $ProxyUserAgent, `
        $DetectionMethod, $Datacenter.Code, $Datacenter.Country, $Datacenter.Location, `
        $Datacenter.Latitude, $Datacenter.Longitude, $Datacenter.Usage ) -join $SyncHash.ListSeparator)

    Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Ok" -Reason ""
}

function Invoke-FileTransferAnalysis {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$ResultsFile
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Site
		,
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		$Item
	)

    Write-Log -Message "[$Site/$($Item.Name)] Trying to analyze file transfer to O365 for trace '$($item.FullName)'" -Source "FileTransfer" -MessageType Info

    $AnalysisStartTime = Get-Date
    $DateTime, $Date, $Time, $DayIndex, $Hour = Get-TimestampInfo $item
    $TransferedFileSizeMB = [int]($item.Name -replace '.*?(\d+)MB(UP|DOWN).*','$1')
    $TransferDirection = ($item.Name -replace '.*?(\d+)MB(UP|DOWN).*','$2')
    Write-Log -Message "[$Site/$($Item.Name)] Transfered file size: $($TransferedFileSizeMB)MB $TransferDirection" -Source "FileTransfer" -MessageType Info

    $FQDNList = @(
        #"customdomain.com",
        "sharepoint.com",
        "sharepoint-mil.us",
        "dps.mil",
        "sharepoint.us",
        "spo-ring.msedge.net"
    )
    if ($SyncHash.OneDriveFQDN -notlike "") {
        foreach ($OneDriveFQDN in $SyncHash.OneDriveFQDN) {
            $FQDNList += $OneDriveFQDN
        }
    }

    $FrameFilter = ""
    foreach ($FQDN in $FQDNList) {
        if ($FrameFilter -like "") {
            $FrameFilter +=  '(frame contains \"' + $FQDN + '\")'
        } else {
            $FrameFilter +=  ' or (frame contains \"' + $FQDN + '\")'
        }
    }

    # Match SYN/FIN/RST packets to get start/end time and client/server info
    $Filter = 'tcp.flags.syn == 1 || tcp.flags.fin == 1 || tcp.flags.reset == 1'
    # Match a TLS Client/Server Hello for the previous FQDN
    $Filter += ' || ( (tcp.payload matches \"\x16\x03(\x01|\x02|\x03)[\x00-\xFF]{2}(\x01|\x02)\") && ( ' + $FrameFilter + ' ) )'
    # Match packets with a sequence number matching the expected file size
    $Filter += ' || ( tcp.seq >= ' + ($TransferedFileSizeMB * 1MB) + ' && tcp.seq <= ' + ($TransferedFileSizeMB * 1MB + 100KB) + ' && tcp.len > 0 ) '
    # Match the last 500 packets of the trace
    $Last500FramesNumber = ((& (Join-Path -Path (Split-Path $synchash.TsharkPath) -ChildPath "capinfos.exe") $item.FullName -c -T | Select-Object -Last 1) -replace '.*\s+(\d+)','$1') - 500
    $Filter += ' || ( frame.number >= ' + $Last500FramesNumber + ' && tcp.len > 0 ) '

    Write-Log -Message "[$Site/$($Item.Name)] Getting TCP conversations statistics" -Source "FileTransfer" -MessageType Info
    try {
        $TCPConversations = & $SyncHash.TsharkPath -r ('"'+ $item.FullName + '"') -Y $Filter -T fields -e frame.time_relative -e frame.interface_id -e tcp.stream `
                            -e ip.src -e tcp.srcport -e ip.dst -e tcp.dstport -e tcp.seq -e tcp.flags.syn -e tcp.flags.fin  -e tcp.flags.reset -e tls.handshake.extensions_server_name -e tcp.payload `
                            -E separator=';' -o tls.keylog_file:null --disable-protocol http,http2,http3 | ConvertFrom-Csv -Delimiter ';' -Header "TimeRelative","InterfaceID","TCPStream" `
                            ,"SourceIP","SourcePort","DestinationIP","DestinationPort","TCPSequenceNumber","FlagSYN","FlagFIN","FlagRST","TLSServerNameIndication","TCPPayload"
    } catch {
        Write-Log -Message "[$Site/$($Item.Name)] Error opening file with Tshark ($($_.Exception.Message))" -Source "FileTransfer" -MessageType Error -DisplayInGui
        if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
            $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
            if ($OriginalTraceFile.FullName) {
                Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "FileTransfer" -MessageType Info -DisplayInGui
                Invoke-FileTransferAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile
                return
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file with Tshark"    
                return
            }
        } else {
            Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file (and unfiltered file) with Tshark"
            return
        }
    }

    # Identify and correct TLS Client Hello to SPO that haven't been detected properly
    foreach ($TLSClientHello in ($TCPConversations | Where-Object {$_.TCPPayload -match "^1603(01|02|03)....01" -and $_.TLSServerNameIndication -like ""})) {
        $TCPPayloadASCII = ($TLSClientHello.TCPPayload -split '(..)' -ne '' | ForEach-Object {[char][byte]"0x$_"}) -join ''
        $matches = $null
        foreach ($FQDN in $FQDNList) {
            $TCPPayloadASCII -match $FQDN | Out-Null
        }
        if ($matches) {$TLSClientHello.TLSServerNameIndication = $matches[0]}
    }

    $TLSClientHelloList = $TCPConversations | Where-Object { $_.TLSServerNameIndication -notlike "" }

    $SPOConversationList = @()

    if ($TLSClientHelloList) {
        foreach ($TLSClientHello in $TLSClientHelloList) {
            $CurrentSPOConversation = [pscustomobject]@{
                Client                  = $TLSClientHello.SourceIP
                ClientPort              = $TLSClientHello.SourcePort
                Server                  = $TLSClientHello.DestinationIP
                ServerPort              = $TLSClientHello.DestinationPort
                ConversationSizeInBytes = $null
                ConversationSize        = $null
                Direction               = $null
                Duration                = $null
                AverageThroughput       = $null
                SizeMatch               = $null
                DirectionMatch          = $null
            }

            $matches = $null
            foreach ($FQDN in $FQDNList) {
                $TLSClientHello.TLSServerNameIndication -match $FQDN | Out-Null
            }
            if (-not $matches) {
                Write-Log -Message "[$Site/$($Item.Name)] Skipping conversation not to SPO ($($TLSClientHello.TLSServerNameIndication))" -Source "FileTransfer" -MessageType Warning
                continue
            }

            $PacketsForConversation = $TCPConversations | Where-Object { $_.TCPStream -eq $TLSClientHello.TCPStream }
            # Convert sequence numbers from string to int
            $PacketsForConversation | ForEach-Object { $_.TCPSequenceNumber = [int]$_.TCPSequenceNumber }
            $LastPacketSequenceForConversation = $PacketsForConversation | Sort-Object -Property TCPSequenceNumber | Select-Object -Last 1
            $CurrentSPOConversation.ConversationSizeInBytes = $LastPacketSequenceForConversation.TCPSequenceNumber
            $CurrentSPOConversation.ConversationSize = [Math]::Round( $LastPacketSequenceForConversation.TCPSequenceNumber / 1MB ,2 ) -replace ',','.'

            if ($CurrentSPOConversation.ConversationSizeInBytes -lt 1MB) {
                Write-Log -Message "[$Site/$($Item.Name)] Skipping conversation with SPO of less than 1MB ($($CurrentSPOConversation.ConversationSize)MB): Client=$($CurrentSPOConversation.Client):$($CurrentSPOConversation.ClientPort) - Server=$($CurrentSPOConversation.Server):$($CurrentSPOConversation.ServerPort) - Size=$($CurrentSPOConversation.ConversationSize)MB" -Source "FileTransfer" -MessageType Warning
                continue
            }

            if ($LastPacketSequenceForConversation.SourcePort -eq $CurrentSPOConversation.ClientPort) {
                $CurrentSPOConversation.Direction = "UP"
            } else {
                $CurrentSPOConversation.Direction = "DOWN"
            }
            $CurrentSPOConversation.Duration = [double](($PacketsForConversation | Select-Object -Last 1).TimeRelative - ($PacketsForConversation | Select-Object -First 1).TimeRelative) -replace ',','.'
            $CurrentSPOConversation.AverageThroughput = [Math]::Round($LastPacketSequenceForConversation.TCPSequenceNumber / (($PacketsForConversation | Select-Object -Last 1).TimeRelative - ($PacketsForConversation | Select-Object -First 1).TimeRelative))

            if ([Math]::Round($CurrentSPOConversation.ConversationSizeInBytes / 1MB) -eq $TransferedFileSizeMB) {
                $CurrentSPOConversation.SizeMatch = $true
            } else {
                $CurrentSPOConversation.SizeMatch = $false
            }
            if ($CurrentSPOConversation.Direction -eq $TransferDirection) {
                $CurrentSPOConversation.DirectionMatch = $true
            } else {
                $CurrentSPOConversation.DirectionMatch = $false
            }

            $SPOConversationList += $CurrentSPOConversation
            Write-Log -Message "[$Site/$($Item.Name)] Found conversation with SPO: Client=$($CurrentSPOConversation.Client):$($CurrentSPOConversation.ClientPort) - Server=$($CurrentSPOConversation.Server):$($CurrentSPOConversation.ServerPort) - Direction=$($CurrentSPOConversation.Direction) - Size=$($CurrentSPOConversation.ConversationSize)MB - Duration=$($CurrentSPOConversation.Duration) - Average throughput=$([math]::Round($CurrentSPOConversation.AverageThroughput/1MB,2))MB/s" -Source "FileTransfer" -MessageType Info
        }
    }

    if (-not $SPOConversationList) {
        Write-Log -Message "[$Site/$($Item.Name)] No TLS handshake with SPO found, attempting to find matching conversations" -Source "FileTransfer" -MessageType Warning
        foreach ($TCPConversation in ($TCPConversations | Group-Object -Property TCPStream)) {
            $PacketsForConversation = $TCPConversation.Group
            # Discard conversations where SYN isn't captured
            if (-not ($PacketsForConversation | Where-Object {$_.FlagSYN -eq $true})) { continue }
            
            $CurrentSPOConversation = [pscustomobject]@{
                Client                  = ($PacketsForConversation | Where-Object {$_.FlagSyn -eq $true} | Select-Object -First 1).SourceIP
                ClientPort              = ($PacketsForConversation | Where-Object {$_.FlagSyn -eq $true} | Select-Object -First 1).SourcePort
                Server                  = ($PacketsForConversation | Where-Object {$_.FlagSyn -eq $true} | Select-Object -First 1).DestinationIP
                ServerPort              = ($PacketsForConversation | Where-Object {$_.FlagSyn -eq $true} | Select-Object -First 1).DestinationPort
                ConversationSizeInBytes = $null
                ConversationSize        = $null
                Direction               = $null
                Duration                = $null
                AverageThroughput       = $null
                SizeMatch               = $null
                DirectionMatch          = $null
            }

            # Convert sequence numbers from string to int
            $PacketsForConversation | ForEach-Object { $_.TCPSequenceNumber = [int]$_.TCPSequenceNumber }
            $LastPacketSequenceForConversation = $PacketsForConversation | Sort-Object -Property TCPSequenceNumber | Select-Object -Last 1
            $CurrentSPOConversation.ConversationSizeInBytes = $LastPacketSequenceForConversation.TCPSequenceNumber
            $CurrentSPOConversation.ConversationSize = [Math]::Round( $LastPacketSequenceForConversation.TCPSequenceNumber / 1MB ,2 ) -replace ',','.'
            
            if ($CurrentSPOConversation.ConversationSizeInBytes -lt 1MB) {
                Write-Log -Message "[$Site/$($Item.Name)] Skipping conversation of less than 1MB ($($CurrentSPOConversation.ConversationSize)MB): Client=$($CurrentSPOConversation.Client):$($CurrentSPOConversation.ClientPort) - Server=$($CurrentSPOConversation.Server):$($CurrentSPOConversation.ServerPort) - Size=$($CurrentSPOConversation.ConversationSize)MB" -Source "FileTransfer" -MessageType Warning
                continue
            }

            if ($LastPacketSequenceForConversation.SourcePort -eq $CurrentSPOConversation.ClientPort) {
                $CurrentSPOConversation.Direction = "UP"
            } else {
                $CurrentSPOConversation.Direction = "DOWN"
            }
            $CurrentSPOConversation.Duration = [double](($PacketsForConversation | Select-Object -Last 1).TimeRelative - ($PacketsForConversation | Select-Object -First 1).TimeRelative) -replace ',','.'
            $CurrentSPOConversation.AverageThroughput = [Math]::Round($LastPacketSequenceForConversation.TCPSequenceNumber / (($PacketsForConversation | Select-Object -Last 1).TimeRelative - ($PacketsForConversation | Select-Object -First 1).TimeRelative))

            if ([Math]::Round($CurrentSPOConversation.ConversationSizeInBytes / 1MB) -eq $TransferedFileSizeMB) {
                $CurrentSPOConversation.SizeMatch = $true
            } else {
                $CurrentSPOConversation.SizeMatch = $false
            }
            if ($CurrentSPOConversation.Direction -eq $TransferDirection) {
                $CurrentSPOConversation.DirectionMatch = $true
            } else {
                $CurrentSPOConversation.DirectionMatch = $false
            }

            $SPOConversationList += $CurrentSPOConversation
            Write-Log -Message "[$Site/$($Item.Name)] Found possible conversation with SPO: Client=$($CurrentSPOConversation.Client):$($CurrentSPOConversation.ClientPort) - Server=$($CurrentSPOConversation.Server):$($CurrentSPOConversation.ServerPort) - Direction=$($CurrentSPOConversation.Direction) - Size=$($CurrentSPOConversation.ConversationSize)MB - Duration=$($CurrentSPOConversation.Duration) - Average throughput=$([math]::Round($CurrentSPOConversation.AverageThroughput/1MB,2))MB/s" -Source "FileTransfer" -MessageType Info
        }
    }

    $MatchingTCPConversation = $SPOConversationList | Where-Object {$_.SizeMatch -eq $true -and $_.DirectionMatch -eq $true} | Sort-Object -Property ConversationSize -Descending | Select-Object -First 1

    if ($MatchingTCPConversation) {
        Write-Log -Message "[$Site/$($Item.Name)] Found one conversation matching direction and size: Client=$($MatchingTCPConversation.Client):$($MatchingTCPConversation.ClientPort) - Server=$($MatchingTCPConversation.Server):$($MatchingTCPConversation.ServerPort) - Size=$($MatchingTCPConversation.ConversationSize)MB" -Source "FileTransfer" -MessageType Info
    } else {
        $MatchingTCPConversation = $SPOConversationList | Where-Object {$_.DirectionMatch -eq $true} | Sort-Object -Property ConversationSize -Descending | Select-Object -First 1
        if ($MatchingTCPConversation) {
            Write-Log -Message "[$Site/$($Item.Name)] Found one conversation matching direction but not size: Client=$($MatchingTCPConversation.Client):$($MatchingTCPConversation.ClientPort) - Server=$($MatchingTCPConversation.Server):$($MatchingTCPConversation.ServerPort) - Size=$($MatchingTCPConversation.ConversationSize)MB" -Source "FileTransfer" -MessageType Warning
        } else {
            Write-Log -Message "[$Site/$($Item.Name)] Skipping trace due to no valid conversation found" -Source "FileTransfer" -MessageType Error -DisplayInGui
            if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
                $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
                if ($OriginalTraceFile.FullName) {
                    Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "FileTransfer" -MessageType Info -DisplayInGui
                    Invoke-FileTransferAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile
                    return
                } else {
                    Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No valid conversation found in trace"    
                    return
                }
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "No valid conversation found in trace (filtered and unfiltered file)"
                return
            }
        }
    }

    Write-Log -Message "[$Site/$($Item.Name)] Estimated throughput threshold (stream size / stream duration): $([math]::Round($MatchingTCPConversation.AverageThroughput/1MB,2))MB/s" -Source "FileTransfer" -MessageType Info

    $Filter = "tcp.port==$($MatchingTCPConversation.ClientPort) && tcp.port==$($MatchingTCPConversation.ServerPort)"
    Write-Log -Message "[$Site/$($Item.Name)] Fetching TCP stream packets and statistics using filter: $Filter" -Source "FileTransfer" -MessageType Info
    $StatFilter = 'io,stat,0,"MAX(tcp.len)tcp.len","COUNT(tcp.analysis.duplicate_ack)tcp.analysis.duplicate_ack","COUNT(tcp.analysis.retransmission)tcp.analysis.retransmission","COUNT(tcp.analysis.fast_retransmission)tcp.analysis.fast_retransmission","COUNT(tcp.analysis.zero_window)tcp.analysis.zero_window","COUNT(tcp.analysis.window_full)tcp.analysis.window_full","COUNT(frame.number)frame.number","MAX(tcp.window_size_scalefactor)tcp.window_size_scalefactor"'
    try {
        # Create a temporary file to store tshark error output
        $TemporaryErrorFile = [System.IO.Path]::GetTempFileName()
        $RawOutput = .$SyncHash.TsharkPath -r ('"' + $item.FullName + '"') -T fields -e frame.time_relative -e ip.len -e ip.hdr_len -e tcp.hdr_len -e tcp.len `
                     -e tcp.srcport -e tcp.dstport -e _ws.col.Protocol -e tcp.analysis.bytes_in_flight -e tcp.window_size `
                     -o tls.keylog_file:null --disable-protocol http,http2,http3 -E separator=';' -2 -R $Filter -z $StatFilter `
                     2> $TemporaryErrorFile
                     # Disable protocols that can mess with analysis, and redirect tshark error output to a temp file
        if ($RawOutput -notlike "") {
            Remove-Item -Path $TemporaryErrorFile -ErrorAction SilentlyContinue
        } else {
            throw "No output from Tshark"
        }
    } catch {
        Write-Log -Message "[$Site/$($Item.Name)] Error opening file with Tshark ($($_.Exception.Message))" -Source "FileTransfer" -MessageType Error -DisplayInGui
        $TemporaryErrorFileContent = Get-Content -Path $TemporaryErrorFile -ErrorAction SilentlyContinue
        if ($TemporaryErrorFileContent -notlike "") {
            Write-Log -Message "[$Site/$($Item.Name)] Tshark error output:" -Source "$Workload" -MessageType Error
            $TemporaryErrorFileContent | ForEach-Object {
                Write-Log -Message "[$Site/$($Item.Name)] >> $($_)" -Source "$Workload" -MessageType Error
            }
        }
        Remove-Item -Path $TemporaryErrorFile -ErrorAction SilentlyContinue
        if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
            $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
            if ($OriginalTraceFile.FullName) {
                Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "FileTransfer" -MessageType Info -DisplayInGui
                Invoke-FileTransferAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile
                return
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file with Tshark"    
                return
            }
        } else {
            Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error opening file (and unfiltered file) with Tshark"
            return
        }
    }

    Write-Log -Message "[$Site/$($Item.Name)] Processing TCP packets" -Source "FileTransfer" -MessageType Info

    # Get lines matching a packet and convert to a Powershell object
    $TCPPackets = $RawOutput | Where-Object {$_ -match "^\d+"} | ConvertFrom-Csv -Delimiter ";" -Header "TimeRelative","IPLength","IPHeaderLength","TCPHeaderLength","TCPLength","SourcePort","DestinationPort","Protocol","BytesInFlight","WindowSize"
    # Filter TCP packets on non-zero TCP length and packets originating from the sender (can be client/server depending on upload/download)
    if ($MatchingTCPConversation.Direction -eq "DOWN") {
        $PacketPortFilter = $MatchingTCPConversation.ServerPort
    } else {
        $PacketPortFilter = $MatchingTCPConversation.ClientPort
    }
    $TCPPacketsForAnalysis = $TCPPackets | Where-Object {$_.TCPLength -ne 0 -and $_.SourcePort -eq $PacketPortFilter}
    # Fix packets where TCPLength is missing
    $TCPPacketsForAnalysis | Where-Object { $_.TCPLength -like ""} | ForEach-Object { $_.TCPLength = $_.IPLength - $_.IPHeaderLength - $_.TCPHeaderLength }

    Write-Log -Message "[$Site/$($Item.Name)] Trying to find transfer start time" -Source "FileTransfer" -MessageType Info

    $PacketNumberStart = 0
    $PacketNumberEnd = 0
    $CurrentThroughput = 0
    $TransferStartTime = ""
    $NumberOfPackets = $TCPPacketsForAnalysis.count

    while ($CurrentThroughput -lt $MatchingTCPConversation.AverageThroughput -and $PacketNumberEnd -le $NumberOfPackets-1) {
        $PacketNumberStart = $PacketNumberEnd
        $PacketNumberEnd = $PacketNumberStart+1
        $CurrentTimeDelta = 0

        # Group packets over a 10ms window (this is how precise the finding of start time will be)
        while ($CurrentTimeDelta -lt 0.01 -and $PacketNumberEnd -le $NumberOfPackets-1) {
            $PacketNumberEnd++
            $CurrentTimeDelta = $TCPPacketsForAnalysis[$PacketNumberEnd].TimeRelative - $TCPPacketsForAnalysis[$PacketNumberStart].TimeRelative
        }
        
        # if the last packet is farther than 20ms away, use the previous packet as end of the group
        if ($CurrentTimeDelta -ge 0.02) {$PacketNumberEnd--}

        # Calculate the payload of the group of packets
        $CurrentPayload = (($TCPPacketsForAnalysis[$PacketNumberStart..$PacketNumberEnd]).TCPLength | Measure-Object -Sum).Sum
        # Calculate the throughput of the group of packet
        $CurrentThroughput = $CurrentPayload / $CurrentTimeDelta

        if ($CurrentTimeDelta -ge 0.02) {$PacketNumberEnd++}
    }
    $TransferStartTime = $TCPPacketsForAnalysis[$PacketNumberStart].TimeRelative
    Write-Log -Message "[$Site/$($Item.Name)] Transfer start time found: $TransferStartTime" -Source "FileTransfer" -MessageType Info
    
    Write-Log -Message "[$Site/$($Item.Name)] Trying to find transfer end time" -Source "FileTransfer" -MessageType Info

    $PacketNumberStart = $TCPPacketsForAnalysis.count-1
    $PacketNumberEnd = $TCPPacketsForAnalysis.count-1
    $CurrentThroughput = 0
    $TransferEndTime = ""

    while ($CurrentThroughput -lt $MatchingTCPConversation.AverageThroughput -and $PacketNumberEnd -ge 1) {
        $PacketNumberStart = $PacketNumberEnd
        $PacketNumberEnd = $PacketNumberStart-1
        $CurrentTimeDelta = 0

        # Group packets over a 10ms window (this is how precise the finding of end time will be)
        while ($CurrentTimeDelta -lt 0.01 -and $PacketNumberEnd -ge 1) {
            $PacketNumberEnd--
            $CurrentTimeDelta = $TCPPacketsForAnalysis[$PacketNumberStart].TimeRelative - $TCPPacketsForAnalysis[$PacketNumberEnd].TimeRelative
        }
        
        # if the last packet is farther than 20ms away, use the previous packet as end of the group
        if ($CurrentTimeDelta -ge 0.02) {$PacketNumberEnd++}

        # Calculate the payload of the group of packets
        $CurrentPayload = (($TCPPacketsForAnalysis[$PacketNumberStart..$PacketNumberEnd]).TCPLength | Measure-Object -Sum).Sum
        # Calculate the throughput of the group of packet
        $CurrentThroughput = $CurrentPayload / $CurrentTimeDelta

        if ($CurrentTimeDelta -ge 0.02) {$PacketNumberEnd--}
    }
    $TransferEndTime = $TCPPacketsForAnalysis[$PacketNumberStart].TimeRelative
    Write-Log -Message "[$Site/$($Item.Name)] Transfer end time found: $TransferEndTime" -Source "FileTransfer" -MessageType Info

    $TransferDuration = [math]::round($TransferEndTime - $TransferStartTime,3)

    if ($TransferDuration -le 0) {
        Write-Log -Message "[$Site/$($Item.Name)] Unable to find a correct file transfer start and end time. Details: Start=$TransferStartTime - End=$TransferEndTime" -Source "FileTransfer" -MessageType Error
        if ($Item.Directory -notmatch "\\(OriginalTraces|UnfilteredTraces)") {
            $OriginalTraceFile = Get-ChildItem (Join-Path -Path $SyncHash.FolderPath -ChildPath $Site) -Recurse | Where-Object { ($_.name -eq $Item.Name -or $_.Name -eq ($Item.Name -replace '\.pcapng','-Unfiltered.pcapng')) -and $_.Directory -match '\\(OriginalTraces|UnfilteredTraces)' } | Select-Object -First 1
            if ($OriginalTraceFile.FullName) {
                Write-Log -Message "[$Site/$($Item.Name)] Retrying with unfiltered trace file '$($OriginalTraceFile.FullName)'" -Source "FileTransfer" -MessageType Info -DisplayInGui
                Invoke-FileTransferAnalysis -ResultsFile $ResultsFile -Site $Site -Item $OriginalTraceFile
                return
            } else {
                Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error finding file transfer start and end time"    
                return
            }
        } else {
            Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Error" -Reason "Error finding file transfer start and end time (and unfiltered file)"
            return
        }
    }

    Write-Log -Message "[$Site/$($Item.Name)] Fetching stream statistics" -Source "FileTransfer" -MessageType Info

    # Get the statistics from the tshark raw output
    $ConversationStatistics = ($RawOutput | Select-Object -Last 20 | Where-Object {$_ -match '(\|\s+\d+\s+\|)+'}) -split "\|\s*" | Where-Object {$_ -notmatch "^$|<>"}
    $MaxTCPLength = $ConversationStatistics[0]
    $DupAckPackets = $ConversationStatistics[1]
    $RetransmitPackets = $ConversationStatistics[2]
    $FRetransmitPackets = $ConversationStatistics[3]
    $TCPZeroWindow = [int]$ConversationStatistics[4]
    $TCPWindowFull = [int]$ConversationStatistics[5]
    $FramesCount = $ConversationStatistics[6]
    $MaxTCPWindowScaling = if ([int]$ConversationStatistics[7] -gt 0) { [math]::log([int]$ConversationStatistics[7],2) } else { 0 }
    $SizeInBytes = $MatchingTCPConversation.ConversationSizeInBytes

    Write-Log -Message "[$Site/$($Item.Name)] TCP stream analysis result:" -Source "FileTransfer" -MessageType Info
    Write-Log -Message "[$Site/$($Item.Name)] SizeInBytes=$SizeInBytes - Duration=$($TransferDuration -replace ",", ".") - Frames=$FramesCount - DupAckPackets=$DupAckPackets - RetransmitPackets=$RetransmitPackets" -Source "FileTransfer" -MessageType Info
    Write-Log -Message "[$Site/$($Item.Name)] FastRetransmitPackets=$FRetransmitPackets - TCPZeroWindow=$TCPZeroWindow - TCPWindowFull=$TCPWindowFull - MaxTCPLength=$MaxTCPLength - MaxTCPWindowScaling=$MaxTCPWindowScaling - TransferSizeMatch=$($MatchingTCPConversation.SizeMatch) - Destination=$($MatchingTCPConversation.Server)" -Source "FileTransfer" -MessageType Info
    Add-Content -Encoding UTF8 -Path $ResultsFile -Value (( $item.Name, $DateTime, $Date, $Time, $DayIndex, $Hour, $Site.Name, $MatchingTCPConversation.Direction, $TransferedFileSizeMB, $SizeInBytes, `
        ($TransferDuration.ToString() -replace ",", "." ), $FramesCount, $DupAckPackets, $RetransmitPackets, `
        $FRetransmitPackets, $TCPZeroWindow, $TCPWindowFull, $MaxTCPLength, $MaxTCPWindowScaling, $MatchingTCPConversation.SizeMatch, $MatchingTCPConversation.Server ) -join $SyncHash.ListSeparator)

    Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $DateTime -Type "FileTransfer" -AnalysisStartTime $AnalysisStartTime -Result "Ok" -Reason ""                    
}

function Invoke-NetworkTracesAnalysis {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Workload
	)
    
    Write-Log -Message "Starting $($MyInvocation.MyCommand) function for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui
    $FilesProcessed = 0

    switch ($Workload) {
        "DNS" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "Dns.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", "DelayMs", "DnsIP", "FQDN", `
                            "CNAME", "DNSTTL", "Hops", "PrimaryDNS", "Service", `
                            "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "EXO" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "ExchangeConnectivity.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", `
                            "FQDN", "DstIP", "DstPort", "DelayTLSMs", "DelayTCPMs", "TotalConnectionTime", "TTL", "DF", "DFLimitingSide", "MSS", "MSSLimitingSide", `
                            "Shift", "ShiftLimitingSide", "SACK", "SACKLimitingSide", "TimeStamp", "TLSInspection", "CA", "SN", `
                            "ProxyDetected", "ProxyAuthentication", "ProxyType", "ProxyUserAgent", `
                            "DetectionMethod", "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "Teams" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "TeamsConnectivity.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", `
                            "FQDN", "DstIP", "DstPort", "DelayTLSMs", "DelayTCPMs", "TotalConnectionTime", "TTL", "DF", "DFLimitingSide", "MSS", "MSSLimitingSide", `
                            "Shift", "ShiftLimitingSide", "SACK", "SACKLimitingSide", "TimeStamp", "TLSInspection", "CA", "SN", `
                            "ProxyDetected", "ProxyAuthentication", "ProxyType", "ProxyUserAgent", `
                            "DetectionMethod", "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "SPO" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "SharepointConnectivity.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", `
                            "FQDN", "DstIP", "DstPort", "DelayTLSMs", "DelayTCPMs", "TotalConnectionTime", "TTL", "DF", "DFLimitingSide", "MSS", "MSSLimitingSide", `
                            "Shift", "ShiftLimitingSide", "SACK", "SACKLimitingSide", "TimeStamp", "TLSInspection", "CA", "SN", `
                            "ProxyDetected", "ProxyAuthentication", "ProxyType", "ProxyUserAgent", `
                            "DetectionMethod", "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "Viva" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "VivaConnectivity.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", `
                            "FQDN", "DstIP", "DstPort", "DelayTLSMs", "DelayTCPMs", "TotalConnectionTime", "TTL", "DF", "DFLimitingSide", "MSS", "MSSLimitingSide", `
                            "Shift", "ShiftLimitingSide", "SACK", "SACKLimitingSide", "TimeStamp", "TLSInspection", "CA", "SN", `
                            "ProxyDetected", "ProxyAuthentication", "ProxyType", "ProxyUserAgent", `
                            "DetectionMethod", "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "Copilot" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "CopilotConnectivity.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", `
                            "FQDN", "DstIP", "DstPort", "DelayTLSMs", "DelayTCPMs", "TotalConnectionTime", "TTL", "DF", "DFLimitingSide", "MSS", "MSSLimitingSide", `
                            "Shift", "ShiftLimitingSide", "SACK", "SACKLimitingSide", "TimeStamp", "TLSInspection", "CA", "SN", `
                            "ProxyDetected", "ProxyAuthentication", "ProxyType", "ProxyUserAgent", `
                            "DetectionMethod", "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "MicrosoftDomain" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "MicrosoftDomainConnectivity.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", `
                            "FQDN", "DstIP", "DstPort", "DelayTLSMs", "DelayTCPMs", "TotalConnectionTime", "TTL", "DF", "DFLimitingSide", "MSS", "MSSLimitingSide", `
                            "Shift", "ShiftLimitingSide", "SACK", "SACKLimitingSide", "TimeStamp", "TLSInspection", "CA", "SN", `
                            "ProxyDetected", "ProxyAuthentication", "ProxyType", "ProxyUserAgent", `
                            "DetectionMethod", "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "FileTransfer" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "FileTransfer.csv"
            $CsvHeaders = (("FileName", "DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", "Direction", "FileSize", "SizeInBytes", "Duration", "NumberOfPackets", `
                            "DuplicateAcks", "Retransmits", "FastRetransmits", "TCPZeroWindow", "TCPWindowFull", "MaxTCPLength", "MaxTCPWindowScaling", "TransferSizeMatch", "Destination") -join $SyncHash.ListSeparator)
        }
    }

    $ResultsFileReset = $false
    if (Test-Path $ResultsFile) {
        $FirstLines = Get-Content -Path $ResultsFile | Select-Object -First 2
        if (($FirstLines | Select-Object -First 1) -eq $CsvHeaders) { $UsingValidHeaders = $true } else { $UsingValidHeaders = $false }

        if ($SyncHash.Action -eq "Continue" -and $UsingValidHeaders) {
            Write-Log -Message "A previous $Workload result file already exists and action is set to 'Continue'" -Source "$Workload" -MessageType Info
        } elseif ($SyncHash.Action -eq "Overwrite" -and $FirstLines.count -eq 1) {
            Write-Log -Message "A previous $Workload result file already exists but only contains headers, recreating it" -Source "$Workload" -MessageType Warning
            Remove-Item -Path $ResultsFile -Force -ErrorAction SilentlyContinue
            Write-Log -Message "Generating $Workload result file headers row" -Source "$Workload" -MessageType Info
            Add-Content -Encoding UTF8 -Path $ResultsFile -Value $CsvHeaders
            $ResultsFileReset = $true
        } elseif ($SyncHash.Action -eq "Overwrite" -or $UsingValidHeaders -eq $false) {
            if ($SyncHash.Action -eq "Continue") {
                Write-Log -Message "A previous $Workload result file already exists and action is set to 'Continue' but the previous file is using invalid headers" -Source "$Workload" -MessageType Warning
            } else {
                Write-Log -Message "A previous $Workload result file already exists and is using invalid headers" -Source "$Workload" -MessageType Info
            }
            $RenamedResultsFile = $ResultsFile -replace '(\.csv)',('-'+$(Get-DateInFileName)+'$1.old')
            Move-Item -Path $ResultsFile -Destination $RenamedResultsFile -Force -Confirm:$false
            Write-Log -Message "The old $Workload result file '$ResultsFile' has been renamed to '$RenamedResultsFile'" -Source "$Workload" -MessageType Info
            Write-Log -Message "Generating $Workload result file headers row" -Source "$Workload" -MessageType Info
            Add-Content -Encoding UTF8 -Path $ResultsFile -Value $CsvHeaders
            $ResultsFileReset = $true
        }
    } else {
        Write-Log -Message "No previous $Workload result file exists" -Source "$Workload" -MessageType Info
        Write-Log -Message "Generating $Workload result file headers row" -Source "$Workload" -MessageType Info
        Add-Content -Encoding UTF8 -Path $ResultsFile -Value $CsvHeaders
        $ResultsFileReset = $true
    }

    foreach ($SiteFolder in $SyncHash.SiteFolders) {
        $Site = $SiteFolder.Name
        Write-Log -Message "[$Site] Processing site '$Site' for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui
        switch ($Workload) {
            "DNS" {
                $PrimaryDNS = Get-PrimaryDns -Site $SiteFolder -LogType "DNS"
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "dns" } | Sort-Object -Property Name
            }
            "EXO" {
                $PrimaryDNS = Get-PrimaryDns -Site $SiteFolder -LogType "EXO"
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "outlook|exo" } | Sort-Object -Property Name
            }
            "Teams" {
                $PrimaryDNS = Get-PrimaryDns -Site $SiteFolder -LogType "Teams"
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "Teams" } | Sort-Object -Property Name
            }
            "SPO" {
                $PrimaryDNS = Get-PrimaryDns -Site $SiteFolder -LogType "SPO"
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "spo" } | Sort-Object -Property Name
            }
            "Viva" {
                $PrimaryDNS = Get-PrimaryDns -Site $SiteFolder -LogType "Viva"
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "viva" } | Sort-Object -Property Name
            }
            "Copilot" {
                $PrimaryDNS = Get-PrimaryDns -Site $SiteFolder -LogType "Copilot"
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "Copilot" } | Sort-Object -Property Name
            }
            "MicrosoftDomain" {
                $PrimaryDNS = Get-PrimaryDns -Site $SiteFolder -LogType "MicrosoftDomain"
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "Microsoft" } | Sort-Object -Property Name
            }
            "FileTransfer" {
                $CapFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(cap|pcap|pcapng)" -and $_.Directory -notmatch '\\(OriginalTraces|UnfilteredTraces)' -and $_.Name -match "mbup|mbdown" } | Sort-Object -Property @{Expression={$_.Name -replace '3MB','0' -replace '15MB','1' -replace '45MB','2' -replace 'UP','0' -replace 'DOWN','1'}}
            }
        }

        $FilesToProcess = $CapFiles.count

        if ($FilesToProcess -lt 1) {
            Write-Log -Message "[$Site] No $Workload capture file found. Move to the next task" -Source "$Workload" -MessageType Warning -DisplayInGui
            continue
        } else {
            Write-Log -Message "[$Site] Found $FilesToProcess $Workload capture files" -Source "$Workload" -MessageType Info -DisplayInGui

            switch ($Workload) {
                "DNS" { $FileMatchPattern = "dns" }
                "EXO" { $FileMatchPattern = "outlook|exo" }
                "Teams" { $FileMatchPattern = "teams" }
                "SPO" { $FileMatchPattern = "spo" }
                "Viva" { $FileMatchPattern = "viva" }
                "Copilot" { $FileMatchPattern = "copilot" }
                "MicrosoftDomain" { $FileMatchPattern = "microsoft" }
                "FileTransfer" { $FileMatchPattern = "mbup|mbdown" }
            }

            if ($ResultsFileReset -eq $false) {
                Write-Log -Message "[$Site] Checking files that have already been processed" -Source "$Workload" -MessageType Info
                $FilesAlreadyProcessedForCurrentTypeAndSite = $SyncHash.FilesAlreadyProcessed | Where-Object {$_.SiteName -eq $Site -and $_.FileName -match $FileMatchPattern}
                Write-Log -Message "[$Site] Found $($FilesAlreadyProcessedForCurrentTypeAndSite.count) $Workload files already processed" -Source "$Workload" -MessageType Info -DisplayInGui
            } else {
                Write-Log -Message "Ignoring previously processed files for site '$Site' due to results file reset" -Source "$Workload" -MessageType Info
                $FilesAlreadyProcessedForCurrentTypeAndSite = @()
            }

            foreach ($item in $CapFiles) {
                # Pause analysis if needed
                while ($SyncHash.StartButton.Text -eq "Resume") {
                    Start-Sleep -Milliseconds 500
                }
                if ($Item.Name -in $FilesAlreadyProcessedForCurrentTypeAndSite.FileName) {
                    Write-Log -Message "[$Site/$($Item.Name)] Skipping file '$($Item.FullName)' - already processed ($Workload)" -Source "$Workload" -MessageType Info -DisplayInGui
                    switch ($Workload) {
                        "DNS" {$SyncHash.DNSFilesSkipped++}
                        "EXO" {$SyncHash.EXOFilesSkipped++}
                        "Teams" {$SyncHash.TeamsFilesSkipped++}
                        "SPO" {$SyncHash.SPOFilesSkipped++}
                        "Viva" {$SyncHash.VivaFilesSkipped++}
                        "Copilot" {$SyncHash.CopilotFilesSkipped++}
                        "MicrosoftDomain" {$SyncHash.MicrosoftDomainFilesSkipped++}
                        "FileTransfer" {$SyncHash.FileTransferFilesSkipped++}
                    }
                    $FilesSkipped++
                } else {
                    Write-Log -Message "[$Site/$($Item.Name)] Processing file '$($Item.FullName)' ($Workload)" -Source "$Workload" -MessageType Info -DisplayInGui
                    switch ($Workload) {
                        "DNS" { Invoke-DNSAnalysis -ResultsFile $ResultsFile -Site $SiteFolder -Item $item -PrimaryDNS $PrimaryDNS }
                        {$_ -match "EXO|Teams|SPO|Viva|Copilot|MicrosoftDomain"} { Invoke-WebConnectivityAnalysis -ResultsFile $ResultsFile -Site $SiteFolder -Item $item -PrimaryDNS $PrimaryDNS -Workload $Workload }
                        "FileTransfer" { Invoke-FileTransferAnalysis -ResultsFile $ResultsFile -Site $SiteFolder -Item $item }
                    }
                }
                switch ($Workload) {
                    "DNS" {
                        $SyncHash.DNSFilesProcessed++
                        $SyncHash.DNSAnalysisCompletion = $SyncHash.DNSFilesProcessed * 100 / $SyncHash.DNSFilesToProcess
                        $SyncHash.DNSAnalysisStatus.Text = "$([math]::Round($SyncHash.DNSAnalysisCompletion,1))%"
                    }
                    "EXO" {
                        $SyncHash.EXOFilesProcessed++
                        $SyncHash.EXOAnalysisCompletion = $SyncHash.EXOFilesProcessed * 100 / $SyncHash.EXOFilesToProcess
                        $SyncHash.EXOAnalysisStatus.Text = "$([math]::Round($SyncHash.EXOAnalysisCompletion,1))%"
                    }
                    "Teams" {
                        $SyncHash.TeamsFilesProcessed++
                        $SyncHash.TeamsAnalysisCompletion = $SyncHash.TeamsFilesProcessed * 100 / $SyncHash.TeamsFilesToProcess
                        $SyncHash.TeamsAnalysisStatus.Text = "$([math]::Round($SyncHash.TeamsAnalysisCompletion,1))%"
                    }
                    "SPO" {
                        $SyncHash.SPOFilesProcessed++
                        $SyncHash.SPOAnalysisCompletion = $SyncHash.SPOFilesProcessed * 100 / $SyncHash.SPOFilesToProcess
                        $SyncHash.SPOAnalysisStatus.Text = "$([math]::Round($SyncHash.SPOAnalysisCompletion,1))%"
                    }
                    "Viva" {
                        $SyncHash.VivaFilesProcessed++
                        $SyncHash.VivaAnalysisCompletion = $SyncHash.VivaFilesProcessed * 100 / $SyncHash.VivaFilesToProcess
                        $SyncHash.VivaAnalysisStatus.Text = "$([math]::Round($SyncHash.VivaAnalysisCompletion,1))%"
                    }
                    "Copilot" {
                        $SyncHash.CopilotFilesProcessed++
                        $SyncHash.CopilotAnalysisCompletion = $SyncHash.CopilotFilesProcessed * 100 / $SyncHash.CopilotFilesToProcess
                        $SyncHash.CopilotAnalysisStatus.Text = "$([math]::Round($SyncHash.CopilotAnalysisCompletion,1))%"
                    }
                    "MicrosoftDomain" {
                        $SyncHash.MicrosoftDomainFilesProcessed++
                        $SyncHash.MicrosoftDomainAnalysisCompletion = $SyncHash.MicrosoftDomainFilesProcessed * 100 / $SyncHash.MicrosoftDomainFilesToProcess
                        $SyncHash.MicrosoftDomainAnalysisStatus.Text = "$([math]::Round($SyncHash.MicrosoftDomainAnalysisCompletion,1))%"
                    }
                    "FileTransfer" {
                        $SyncHash.FileTransferFilesProcessed++
                        $SyncHash.FileTransferAnalysisCompletion = $SyncHash.FileTransferFilesProcessed * 100 / $SyncHash.FileTransferFilesToProcess
                        $SyncHash.FileTransferAnalysisStatus.Text = "$([math]::Round($SyncHash.FileTransferAnalysisCompletion,1))%"
                    }
                }
                $FilesProcessed++
            }
        }
        Write-Log -Message "[$Site] Done processing site '$Site' for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui
    }
    Write-Log -Message "Done processing all sites for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui
    $TimeTaken = New-TimeSpan $SyncHash.StartTimeStamp (Get-Date)
    Write-Log -Message "Time taken: '$($TimeTaken.ToString("hh\:mm\:ss\.ff") -replace '^(0+:|0+)*','')'" -Source "$Workload" -MessageType Info
    if (($FilesProcessed - $FilesSkipped) -gt 0) {
        $TimeTakenPerFile = [timespan]::FromSeconds($TimeTaken.TotalSeconds / ($FilesProcessed - $FilesSkipped))
        Write-Log -Message "Average time per file: '$([math]::Round($TimeTakenPerFile.TotalSeconds,2) -replace ',','.')'" -Source "$Workload" -MessageType Info
    }
}

function Invoke-CsvAnalysis {
    Param (
		[Parameter(ValueFromPipelineByPropertyName = $false, Mandatory = $true)]
		[string]$Workload
	)

    Write-Log -Message "Starting $($MyInvocation.MyCommand) function for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui
    $FilesProcessed = 0

    switch ($Workload) {
        "Tracert" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "Traceroute.csv"
            $CsvHeaders = (("DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", "Service", "Target", "TargetFQDN", "TargetIP", "TargetLatency", "Hops", `
                            "MSEntryFQDN", "MSEntryIP", "MSEntryLatency", "MSEntryHop", "Protocol", `
                            "EntryDatacenterCode", "EntryDatacenterCountry", "EntryDatacenterLocation", `
                            "EntryDatacenterLatitude", "EntryDatacenterLongitude", "EntryDatacenterUsage", `
                            "LastDatacenterCode", "LastDatacenterCountry", "LastDatacenterLocation", `
                            "LastDatacenterLatitude", "LastDatacenterLongitude", "LastDatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "TeamsMediaQuality" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "TeamsMediaQuality.csv"
            $CsvHeaders = (("DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", "PacketLossRate", "RoundTripLatencyInMs", `
                            "JitterInMs", "ProtocolUsed", "LocalIP", "ReflexiveIP", "RemoteIP", "ProxyUsed", "RelayLocation", `
                            "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "ServiceConnectivity" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "ServiceConnectivity.csv"
            $CsvHeaders = (("DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", "IP", "Port", "Protocol", "Success") -join $SyncHash.ListSeparator)
        }
        "WebSocket" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "WebsocketConnectivity.csv"
            $CsvHeaders = (("DateTime", "Date", "Time", "DayIndex", "Hour", "SiteName", "Service", "Target", "WSSConnectSuccess", "WSSQuerySuccess","WSSResponseSuccess", "WSSExpectedResponse", "FrontDoor", `
                            "DatacenterCode", "DatacenterCountry", "DatacenterLocation", `
                            "DatacenterLatitude", "DatacenterLongitude", "DatacenterUsage") -join $SyncHash.ListSeparator)
        }
        "Sites" {
            $ResultsFile = Join-Path -Path $SyncHash.FolderPath -Child "sites.csv"
            $CsvHeaders = (("SiteName", "Location", "Country", "Latitude", "Longitude") -join $SyncHash.ListSeparator)
        }
    }

    if (Test-Path $ResultsFile) {
        $FirstLines = Get-Content -Path $ResultsFile | Select-Object -First 2
        if (($FirstLines | Select-Object -First 1) -eq $CsvHeaders) { $UsingValidHeaders = $true } else { $UsingValidHeaders = $false }

        if ($SyncHash.Action -eq "Continue" -and $UsingValidHeaders) {
            Write-Log -Message "A previous $Workload result file already exists and action is set to 'Continue'" -Source "$Workload" -MessageType Info
            Write-Log -Message "Getting details on content of previous $Workload result file" -Source "$Workload" -MessageType Info
            $CurrentResultsFileCsvContent = Get-Content $ResultsFile | ConvertFrom-Csv -Delimiter "`t"
        } elseif ($SyncHash.Action -eq "Overwrite" -and $FirstLines.count -eq 1) {
            Write-Log -Message "A previous $Workload result file already exists but only contains headers, recreating it" -Source "$Workload" -MessageType Warning
            Remove-Item -Path $ResultsFile -Force -ErrorAction SilentlyContinue
            Write-Log -Message "Generating $Workload result file headers row" -Source "$Workload" -MessageType Info
            Add-Content -Encoding UTF8 -Path $ResultsFile -Value $CsvHeaders
        } elseif ($SyncHash.Action -eq "Overwrite" -or $UsingValidHeaders -eq $false) {
            if ($SyncHash.Action -eq "Continue") {
                Write-Log -Message "A previous $Workload result file already exists and action is set to 'Continue' but the previous file is using invalid headers" -Source "$Workload" -MessageType Warning
            } else {
                Write-Log -Message "A previous $Workload result file already exists and is using invalid headers" -Source "$Workload" -MessageType Info
            }
            $RenamedResultsFile = $ResultsFile -replace '(\.csv)',('-'+$(Get-DateInFileName)+'$1.old')
            Move-Item -Path $ResultsFile -Destination $RenamedResultsFile -Force -Confirm:$false
            Write-Log -Message "The old $Workload result file '$ResultsFile' has been renamed to '$RenamedResultsFile'" -Source "$Workload" -MessageType Info
            Write-Log -Message "Generating $Workload result file headers row" -Source "$Workload" -MessageType Info
            Add-Content -Encoding UTF8 -Path $ResultsFile -Value $CsvHeaders
        }
    } else {
        Write-Log -Message "No previous $Workload result file exists" -Source "$Workload" -MessageType Info
        Write-Log -Message "Generating $Workload result file headers row" -Source "$Workload" -MessageType Info
        Add-Content -Encoding UTF8 -Path $ResultsFile -Value $CsvHeaders
    }

    if ($Workload -eq "Sites") {
        foreach ($SiteFolder in $SyncHash.SiteFolders) {
            $Site = $SiteFolder.Name
            if ($Site -notin $CurrentResultsFileCsvContent.SiteName) {
                Write-Log -Message "[$Site] Processing site '$Site'" -Source "$Workload" -MessageType Info -DisplayInGui
                $JsonSettingsFiles = Get-ChildItem -Path $SiteFolder.FullName -Filter Settings.json -Recurse
                $XMLSettingsFiles = Get-ChildItem -Path $SiteFolder.FullName -Filter Settings.xml -Recurse
                if ($JsonSettingsFiles.count -gt 0) {
                    $SettingsFile = $JsonSettingsFiles | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1 | Get-Content | ConvertFrom-Json
                } elseif ($XMLSettingsFiles.count -gt 0) {
                    $SettingsFile = $XMLSettingsFiles | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1 | Import-CliXml
                } else {
                    Write-Log -Message "[$Site] No settings file found" -Source "$Workload" -MessageType Warning
                    $SettingsFile = $null
                }
                $Location = $SettingsFile.Location
                if ($Location -notlike "") {
                    Write-Log -Message "[$Site] Location provided in the settings '$Location'" -Source "$Workload" -MessageType Info
                    $GeoLookup = ([xml](Invoke-WebRequest -Uri "https://nominatim.openstreetmap.org/search?zoom=10&format=xml&accept-language=en-us&q=$Location").Content).searchresults.place | Sort-Object -Property place_rank | Select-Object -First 1
                    $Country = $GeoLookup.display_name -replace '.*,\s*(.*)','$1'
                    $Latitude = $GeoLookup.lat
                    $Longitude = $GeoLookup.lon
                } else {
                    Write-Log -Message "[$Site] Location was NOT provided in the settings" -Source "$Workload" -MessageType Warning
                    $Location = $null
                    $Country = $null
                    $Latitude = $null
                    $Longitude = $null
                    <#
                    $IPConfigFile = Get-ChildItem -Path $SiteFolder.FullName -Recurse "ipconfig.log" | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1 
                    if ($IPConfigFile) {
                        Write-Log -Message "[$Site] Trying to find location using BSSID info in IPConfig file" -Source "$Workload" -MessageType Info
                        $Location,$Country,$Latitude,$Longitude = Get-LocationFromIpconfig -Site $Site -LogType $Workload -IPConfigFile $IPConfigFile
                    } else {
                        Write-Log -Message "[$Site] No IPConfig file found, unable to get a location" -Source "$Workload" -MessageType Warning
                        $Location = $null
                        $Country = $null
                        $Latitude = $null
                        $Longitude = $null
                    }
                    #>
                }
                if ($Country -notlike "") {
                    # Open popup to confirm site location with: no timeout, yes/no button, icon question, and no default button
                    $UserChoice = (New-Object -ComObject Wscript.Shell).Popup("Is the following site location correct?`r`n`r`nSite: $Site`r`nCountry: $Country", 0, "Site location validation", 4 + 32 + 0)
                    if ($UserChoice -eq 6) {
                        Write-Log -Message "[$Site] User confirmed detected site location in '$Country'" -Source "$Workload" -MessageType Info
                        $LocationRejected = $false
                    } else {
                        Write-Log -Message "[$Site] User rejected detected site location in '$Country'" -Source "$Workload" -MessageType Warning
                        $LocationRejected = $true
                    }
                } else {
                    $LocationRejected = $false
                }
                $InvalidCount = 0
                $ProvidedLocation = $Location
                while (($Country -like "" -or $LocationRejected -eq $true) -and $InvalidCount -lt 3) {
                    $InvalidCount++
                    if ($LocationRejected -eq $true) {
                        Write-Log -Message "[$Site] Prompting for location" -Source "$Workload" -MessageType Info
                        $Title = "Detected location rejected"
                        $Message = "Detected location rejected:`r`n"
                        $Message += "Site = $Site`r`n"
                        $Message += "Location = $Location`r`n"
                        $Message += "Country = $Country`r`n`r`n"
                    } elseif ($ProvidedLocation -notlike "") {
                        Write-Log -Message "[$Site] No valid location found for '$ProvidedLocation'" -Source "$Workload" -MessageType Warning
                        $Title = "Invalid location detected"
                        $Message = "Couldn't resolve location below:`r`n"
                        $Message += "Site = $Site`r`n"
                        $Message += "Location = $ProvidedLocation`r`n`r`n"
                    } else {
                        Write-Log -Message "[$Site] Prompting for location" -Source "$Workload" -MessageType Info
                        $Title = "Invalid location detected"
                        $Message = "No location provided:`r`n"
                        $Message += "Site = $Site`r`n`r`n"
                    }
                    $Message += "Please enter a location in the following format:`r`n"
                    $Message += "City, State, Country (for USA)`r`n"
                    $Message += "City, Country (everywhere else)"
                    Add-Type -AssemblyName Microsoft.VisualBasic
                    $ProvidedLocation = [Microsoft.VisualBasic.Interaction]::InputBox($Message, $Title, "")
                    Write-Log -Message "[$Site] Location manually provided '$ProvidedLocation'" -Source "$Workload" -MessageType Info
                    $GeoLookup = ([xml](Invoke-WebRequest -Uri "https://nominatim.openstreetmap.org/search?zoom=10&format=xml&accept-language=en-us&q=$ProvidedLocation").Content).searchresults.place | Sort-Object -Property place_rank | Select-Object -First 1
                    $Country = $GeoLookup.display_name -replace '.*,\s*(.*)','$1'
                    $Latitude = $GeoLookup.lat
                    $Longitude = $GeoLookup.lon
                    if ($Country -notlike "") {
                        # Open popup to confirm site location with: no timeout, yes/no button, icon question, and no default button
                        $UserChoice = (New-Object -ComObject Wscript.Shell).Popup("Is the following site location correct?`r`n`r`nSite: $Site`r`nCountry: $Country", 0, "Site location validation", 4 + 32 + 0)
                        if ($UserChoice -eq 6) {
                            Write-Log -Message "[$Site] User confirmed detected site location in '$Country'" -Source "$Workload" -MessageType Info
                            $LocationRejected = $false
                        } else {
                            Write-Log -Message "[$Site] User rejected detected site location in '$Country'" -Source "$Workload" -MessageType Warning
                            $LocationRejected = $true
                            $Country = $null
                            $Latitude = $null
                            $Longitude = $null
                        }
                    } else {
                        $LocationRejected = $false
                    }
                }
                if ($Country -like "") {
                    if ($Location -notlike "") {
                        Write-Log -Message "[$Site] No valid location found after 3 manual attempts" -Source "$Workload" -MessageType Warning
                        Write-Log -Message "[$Site] Keeping location found in settings file" -Source "$Workload" -MessageType Warning
                    } else {
                        Write-Log -Message "[$Site] No location provided" -Source "$Workload" -MessageType Warning
                    }
                } else {
                    $Location = $ProvidedLocation
                }
                Write-Log -Message "[$Site] Location=$Location - Country=$Country - Latitude=$Latitude - Longitude=$Longitude" -Source "$Workload" -MessageType Info
                $ResultsArray = ($Site, $Location, $Country, $Latitude, $Longitude) -join $SyncHash.ListSeparator
                $ResultsArray | Add-Content -Encoding UTF8 -Path $ResultsFile
            } else {
                Write-Log -Message "[$Site] Skipping site '$Site' as it's already in the sites.csv file" -Source "$Workload" -MessageType Info -DisplayInGui
                $SyncHash.SitesSkipped++
            }
            $SyncHash.SitesProcessed++
            $SyncHash.SitesAnalysisCompletion = $SyncHash.SitesProcessed * 100 / $SyncHash.SitesToProcess
        }
    } else {
        $TestsPerSite = $CurrentResultsFileCsvContent | Group-Object -Property SiteName

        foreach ($SiteFolder in $SyncHash.SiteFolders) {
            $Site = $SiteFolder.Name
            Write-Log -Message "[$Site] Processing site '$Site' for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui

            $SkipSiteForAnalysis = $false
            if ($Site -in $TestsPerSite.Name) {
                $TestsForCurrentSite = $TestsPerSite | Where-Object {$_.Name -eq $Site}
                if ($Workload -eq "TeamsMediaQuality") {
                    if ($TestsForCurrentSite.Count -gt 100) {
                        Write-Log -Message "[$Site] The previous result file '$ResultsFile' already contains results from this site. Move to the next task" -Source "$Workload" -MessageType Info -DisplayInGui
                        $SkipSiteForAnalysis = $true
                    } else {
                        Write-Log -Message "[$Site] The previous result file '$ResultsFile' contains less than 100 tests for this site, the site will be reprocessed" -Source "$Workload" -MessageType Info -DisplayInGui
                    }
                } else {
                    if ($TestsForCurrentSite.Count -gt 10) {
                        Write-Log -Message "[$Site] The previous result file '$ResultsFile' already contains results from this site. Move to the next task" -Source "$Workload" -MessageType Info -DisplayInGui
                        $SkipSiteForAnalysis = $true
                    } else {
                        Write-Log -Message "[$Site] The previous result file '$ResultsFile' contains less than 10 tests for this site, the site will be reprocessed" -Source "$Workload" -MessageType Info -DisplayInGui
                    }
                }
            }

            switch ($Workload) {
                "Tracert" { $CsvFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -eq ".csv" -and $_.Name -match "TracerouteResults|tracert" } | Sort-Object -Property Name }
                "TeamsMediaQuality" { $CsvFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -match "\.(csv|tsv)" -and $_.Name -match "full-results|TeamsMediaQuality" } | Sort-Object -Property Name }
                "ServiceConnectivity" { $CsvFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -eq ".csv" -and $_.Name -match "ServiceConnectivity" } | Sort-Object -Property Name }
                "WebSocket" { $CsvFiles = Get-ChildItem $SiteFolder.FullName -Recurse | Where-Object { $_.extension -eq ".csv" -and $_.Name -match "websocket" } | Sort-Object -Property Name }
            }

            $FilesToProcess = $CsvFiles.count

            if ($FilesToProcess -lt 1) {
                Write-Log -Message "[$Site] No $Workload result file found. Move to the next task" -Source "$Workload" -MessageType Warning -DisplayInGui
                continue
            } else {
                Write-Log -Message "[$Site] Found $($CsvFiles.Count) $Workload result files" -Source "$Workload" -MessageType Info -DisplayInGui
                foreach ($item in $CsvFiles) {
                    # Pause analysis if needed
                    while ($SyncHash.StartButton.Text -eq "Resume") {
                        Start-Sleep -Milliseconds 500
                    }
                    if ($SkipSiteForAnalysis -eq $false) {
                        $ResultsArray = @()
                        Write-Log -Message "[$Site/$($Item.Name)] Processing file '$($Item.FullName)'" -Source "$Workload" -MessageType Info -DisplayInGui
                        $AnalysisStartTime = Get-Date
                        switch ($Workload) {
                            "Tracert" {
                                $CsvContent = Get-Content -Path $item.FullName
                                if ($CsvContent -match '"') {
                                    Write-Log -Message "[$Site/$($Item.Name)] Removing double quotes from CSV file" -Source "$Workload" -MessageType Warning
                                    $CsvContent = $CsvContent -replace '"',''
                                }
                                if (($CsvContent | Select-Object -First 1) -match "`t") {
                                    $CsvData = $CsvContent | ConvertFrom-Csv -Delimiter "`t" | Where-Object { $_.Timestamp -notlike ""}
                                } else {
                                    $CsvData = $CsvContent | ConvertFrom-Csv | Where-Object { $_.Timestamp -notlike ""}
                                }

                                if ($item.Name -match "TracerouteResults") {
                                    $TracerouteList = ($CsvData | Group-Object -Property Timestamp,Service,Target)
    
                                    $TracerouteResults = foreach ($Traceroute in $TracerouteList) {
                                        Write-Log -Message "[$Site/$($Item.Name)] Processing traceroute entry '$($Traceroute.Name)'" -Source "$Workload" -MessageType Info
                                        $TracerouteOutput = $Traceroute.Group
                                        $Target = $TracerouteOutput | Select-Object -Last 1
                                        $EntryPoint = $TracerouteOutput | Where-Object {$_.FQDN -match '\.msn\.net$'} | Select-Object -First 1
                                        $LastPoint = $TracerouteOutput | Where-Object {$_.FQDN -match '\.msn\.net$'} | Select-Object -Last 1
                                        $EntryDatacenter = if ($EntryPoint) { Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code ($EntryPoint.FQDN -split '\.')[-4] } else { $null }
                                        $LastDatacenter = if ($Target.Service -notmatch "DNS|Egress" -and $Target.FQDN -notlike "") { Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code $Target.FQDN } else { $null }
                                        if ($null -eq $LastDatacenter) {
                                            $LastDatacenter = if ($LastPoint) { Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code ($LastPoint.FQDN -split '\.')[-4] } else { $null }
                                        }
                                        $CurrentTraceroute = New-Object PSObject -Property ([ordered]@{
                                            Timestamp                   = $Target.Timestamp
                                            SiteName                    = $Site
                                            Service                     = $Target.Service
                                            Target                      = $Target.Target
                                            TargetFQDN                  = $Target.FQDN
                                            TargetIP                    = $Target.IPAddress
                                            TargetLatency               = $Target.Latency
                                            Hops                        = $Target.Hop
                                            MSEntryFQDN                 = $EntryPoint.FQDN
                                            MSEntryIP                   = $EntryPoint.IPAddress
                                            MSEntryLatency              = $EntryPoint.Latency
                                            MSEntryHop                  = $EntryPoint.Hop
                                            Protocol                    = $Target.Protocol
                                            EntryDatacenterCode         = $EntryDatacenter.Code
                                            EntryDatacenterCountry      = $EntryDatacenter.Country
                                            EntryDatacenterLocation     = $EntryDatacenter.Location
                                            EntryDatacenterLatitude     = $EntryDatacenter.Latitude
                                            EntryDatacenterLongitude    = $EntryDatacenter.Longitude
                                            EntryDatacenterUsage        = if ($EntryDatacenter) { "PeeringPoint-$($Target.Service)" } else { "" }
                                            LastDatacenterCode          = $LastDatacenter.Code
                                            LastDatacenterCountry       = $LastDatacenter.Country
                                            LastDatacenterLocation      = $LastDatacenter.Location
                                            LastDatacenterLatitude      = $LastDatacenter.Latitude
                                            LastDatacenterLongitude     = $LastDatacenter.Longitude
                                            LastDatacenterUsage         = if ($LastDatacenter) { "Traceroute-$($Target.Service)" } else { "" }
                                        })
    
                                        $CurrentTraceroute
                                    }
                                } elseif ($item.Name -match "tracert") {
                                    $TracerouteResults = foreach ($Traceroute in $CsvData) {
                                        Write-Log -Message "[$Site/$($Item.Name)] Processing traceroute entry '$($Traceroute.Timestamp),$($Traceroute.Service),$($Traceroute.Target)'" -Source "$Workload" -MessageType Info

                                        if ($Traceroute.MSEntry) { $EntryDatacenter = Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code ($Traceroute.MSEntry -split '\.')[-4] } else { $EntryDatacenter = $null }
                                        $CurrentTraceroute = New-Object PSObject -Property ([ordered]@{
                                            Timestamp                   = $Traceroute.Timestamp
                                            SiteName                    = $Site
                                            Service                     = $Traceroute.Service
                                            Target                      = $Traceroute.Target
                                            TargetFQDN                  = $Traceroute.Target
                                            TargetIP                    = ""
                                            TargetLatency               = $Traceroute.TargetLatency
                                            Hops                        = $Traceroute.Hops
                                            MSEntryFQDN                 = $Traceroute.MSEntry
                                            MSEntryIP                   = ""
                                            MSEntryLatency              = $Traceroute.MSEntryLatency
                                            MSEntryHop                  = $Traceroute.MSEntryHop
                                            Protocol                    = $Traceroute.Protocol
                                            EntryDatacenterCode         = $EntryDatacenter.Code
                                            EntryDatacenterCountry      = $EntryDatacenter.Country
                                            EntryDatacenterLocation     = $EntryDatacenter.Location
                                            EntryDatacenterLatitude     = $EntryDatacenter.Latitude
                                            EntryDatacenterLongitude    = $EntryDatacenter.Longitude
                                            EntryDatacenterUsage        = if ($EntryDatacenter) { "PeeringPoint-$($Traceroute.Service)" } else { "" }
                                            LastDatacenterCode          = ""
                                            LastDatacenterCountry       = ""
                                            LastDatacenterLocation      = ""
                                            LastDatacenterLatitude      = ""
                                            LastDatacenterLongitude     = ""
                                            LastDatacenterUsage         = ""
                                        })
    
                                        $CurrentTraceroute
                                    }
                                }

                                Write-Log -Message "[$Site/$($Item.Name)] Building result array" -Source "$Workload" -MessageType Info                   
                                $ResultsArray = $TracerouteResults | ForEach-Object {
                                    $DateTime, $Date, $Time, $DayIndex, $Hour = Get-TimestampInfo $_.'Timestamp'
                                    ($DateTime, $Date, $Time, $DayIndex, $Hour, $_.SiteName, `
                                    $_.Service, $_.Target, $_.TargetFQDN, $_.TargetIP, $_.TargetLatency, $_.Hops, $_.MSEntryFQDN, $_.MSEntryIP,$_.MSEntryLatency,$_.MSEntryHop,$_.Protocol, `
                                    $_.EntryDatacenterCode, $_.EntryDatacenterCountry, $_.EntryDatacenterLocation, `
                                    $_.EntryDatacenterLatitude, $_.EntryDatacenterLongitude, $_.EntryDatacenterUsage, `
                                    $_.LastDatacenterCode, $_.LastDatacenterCountry, $_.LastDatacenterLocation, `
                                    $_.LastDatacenterLatitude, $_.LastDatacenterLongitude, $_.LastDatacenterUsage ) -join $SyncHash.ListSeparator
                                }
                            }
                            "TeamsMediaQuality" {
                                $CsvContent = Get-Content -Path $item.FullName
                                if ($CsvContent -match '"') {
                                    Write-Log -Message "[$Site/$($Item.Name)] Removing double quotes from CSV file" -Source "$Workload" -MessageType Warning
                                    $CsvContent = $CsvContent -replace '"',''
                                }
                                if (($CsvContent | Select-Object -First 1) -match "`t") {
                                    $CsvData = $CsvContent | ConvertFrom-Csv -Delimiter "`t" | Where-Object { $_.Timestamp -notlike ""}
                                } else {
                                    $CsvData = $CsvContent | ConvertFrom-Csv | Where-Object { $_.Timestamp -notlike ""}
                                }
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'RelayLocation' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterCode' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterCountry' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterLocation' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterLatitude' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterLongitude' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterUsage' -Value "TeamsMedia"
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'SiteName' -Value $Site

                                Write-Log -Message "[$Site/$($Item.Name)] Finding location for all transport relays" -Source "$Workload" -MessageType Info
                                $RelayIPs = $CsvData.RemoteIP -replace '\d+:\d+','0' | Group-Object | Select-Object -ExpandProperty Name | Sort-Object
                                
                                $RelaysLocationList = @()

                                if (Invoke-RestMethod -Uri "https://www.azurespeed.com/api/ipAddress?ipOrDomain=worldaz.tr.teams.microsoft.com" | Where-Object {$_.region -notlike ""}) {
                                    Write-Log -Message "[$Site/$($Item.Name)] Using azurespeed.com API" -Source "$Workload" -MessageType Info
                                    foreach ($Relay in $RelayIPs) {
                                        $RelayLocationResponse = Invoke-RestMethod -Uri "https://www.azurespeed.com/api/ipAddress?ipOrDomain=$Relay"
                                        $RelayLocationResponse = $RelayLocationResponse | Where-Object {$_.region -notlike ""} | Select-Object -Property ipAddress,ipAddressPrefix,serviceTagId,region
                                        Write-Log -Message "[$Site/$($Item.Name)] Transport relay IP and location: $Relay = $($RelayLocationResponse.region)" -Source "$Workload" -MessageType Info
                                        $Datacenter = Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code $RelayLocationResponse.region
                                        
                                        $RelayLocationDetails = New-Object PSObject -Property @{
                                            IPAddress = $Relay
                                            RelayLocation = $RelayLocationResponse.region
                                            DatacenterCode = $Datacenter.Code
                                            DatacenterCountry = $Datacenter.Country
                                            DatacenterLocation = $Datacenter.Location
                                            DatacenterLatitude = $Datacenter.Latitude
                                            DatacenterLongitude = $Datacenter.Longitude
                                            DatacenterUsage = $Datacenter.Usage
                                        }
                                        $RelaysLocationList += $RelayLocationDetails
                                    }
                                } else {
                                    Write-Log -Message "[$Site/$($Item.Name)] Using csstoolkit.azurewebsites.net API" -Source "$Workload" -MessageType Info
                                    $InitialResponse = Invoke-WebRequest -Uri "https://csstoolkit.azurewebsites.net/Home/MicrosoftIPs"
                                    $IPCheckURL = "https://csstoolkit.azurewebsites.net" + (($InitialResponse.Content -split "`r`n" | Where-Object {$_ -match "form action="}) -replace '.*form action="(.*?)".*','$1')

                                    $RelayLocationResponse = Invoke-WebRequest -Uri $IPCheckURL -Body "json=$($RelayIPs -join '%0D%0A')" -Method Post
                                    $RelayLocationResponse_Text = ( $RelayLocationResponse.ParsedHtml.all | ForEach-Object {$_.innerText} | Where-Object {$_ -match "found"} | Select-Object -Last 1 ) -split "`r`n" | Where-Object {$_ -match "cloud json"}
                                    foreach ($Line in $RelayLocationResponse_Text) {
                                        $Relay = $Line -replace '(\d+\.\d+\.\d+\.\d+).*','$1'
                                        $Region = $Line -replace '.*found at (.*?) in.*','$1'
                                        Write-Log -Message "[$Site/$($Item.Name)] Transport relay IP and location: $Relay = $Region" -Source "$Workload" -MessageType Info
                                        $Datacenter = Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code $RelayLocationResponse.region

                                        $RelayLocationDetails = New-Object PSObject -Property @{
                                            IPAddress = $Relay
                                            RelayLocation = $Region
                                            DatacenterCode = $Datacenter.Code
                                            DatacenterCountry = $Datacenter.Country
                                            DatacenterLocation = $Datacenter.Location
                                            DatacenterLatitude = $Datacenter.Latitude
                                            DatacenterLongitude = $Datacenter.Longitude
                                            DatacenterUsage = $Datacenter.Usage
                                        }
                                        $RelaysLocationList += $RelayLocationDetails
                                    }
                                }

                                Write-Log -Message "[$Site/$($Item.Name)] Matching transport relay IPs and locations" -Source "$Workload" -MessageType Info
                                $CsvData | ForEach-Object {
                                    $CurrentLine = $_
                                    $RelayLocationDetails = $RelaysLocationList | Where-Object {$_.IPAddress -eq ($CurrentLine.RemoteIP -replace '\d+:\d+','0')}
                                    if ($RelayLocationDetails) {
                                        $_.RelayLocation = $RelayLocationDetails.RelayLocation
                                        $_.DatacenterCode = $RelayLocationDetails.DatacenterCode
                                        $_.DatacenterCountry = $RelayLocationDetails.DatacenterCountry
                                        $_.DatacenterLocation = $RelayLocationDetails.DatacenterLocation
                                        $_.DatacenterLatitude = $RelayLocationDetails.DatacenterLatitude
                                        $_.DatacenterLongitude = $RelayLocationDetails.DatacenterLongitude
                                        $_.DatacenterUsage = $RelayLocationDetails.DatacenterUsage
                                    } else {
                                        $_.RelayLocation = ""
                                        $_.DatacenterCode = ""
                                        $_.DatacenterCountry = ""
                                        $_.DatacenterLocation = ""
                                        $_.DatacenterLatitude = ""
                                        $_.DatacenterLongitude = ""
                                        $_.DatacenterUsage = ""
                                    }
                                }

                                Write-Log -Message "[$Site/$($Item.Name)] Building result array" -Source "$Workload" -MessageType Info
                                $ResultsArray = $CsvData | ForEach-Object {
                                    $DateTime, $Date, $Time, $DayIndex, $Hour = Get-TimestampInfo $_.'Timestamp'
                                    ($DateTime, $Date, $Time, $DayIndex, $Hour, $_.SiteName, `
                                    ($_.'LossRate-%' -replace ",", "."), ($_.'AverageLatency-Ms' -replace ",", "."),`
                                    ($_.'AverageJitter-MS' -replace ",", "."), $_.Protocol, $_.LocalIP, $_.ReflexiveIP, $_.RemoteIP,`
                                    $_.ProxyUsed, $_.RelayLocation, $_.DatacenterCode, $_.DatacenterCountry, $_.DatacenterLocation, `
                                    $_.DatacenterLatitude, $_.DatacenterLongitude, $_.DatacenterUsage) -join $SyncHash.ListSeparator
                                }
                            }
                            "ServiceConnectivity" {
                                #Todo
                            }
                            "WebSocket" {
                                $CsvContent = Get-Content -Path $item.FullName
                                if ($CsvContent -match '"') {
                                    Write-Log -Message "[$Site/$($Item.Name)] Removing double quotes from CSV file" -Source "$Workload" -MessageType Warning
                                    $CsvContent = $CsvContent -replace '"',''
                                }
                                if (($CsvContent | Select-Object -First 1) -match "`t") {
                                    $CsvData = $CsvContent | ConvertFrom-Csv -Delimiter "`t" | Where-Object { $_.Timestamp -notlike ""}
                                } else {
                                    $CsvData = $CsvContent | ConvertFrom-Csv | Where-Object { $_.Timestamp -notlike ""}
                                }
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterCode' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterCountry' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterLocation' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterLatitude' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterLongitude' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'DatacenterUsage' -Value ""
                                $CsvData | Add-Member -MemberType NoteProperty -Name 'SiteName' -Value $Site

                                Write-Log -Message "[$Site/$($Item.Name)] Finding location for each entry point" -Source "$Workload" -MessageType Info
                                $FrontDoorList = $CsvData | Select-Object -ExpandProperty FrontDoor | Group-Object | Select-Object -ExpandProperty Name | Sort-Object | Where-Object {$_ -notlike ""}
                                foreach ($FrontDoor in $FrontDoorList) {
                                    $Datacenter = Get-AzureDatacenterLocation -Site $Site -Item $Item -LogType $Workload -Code $FrontDoor
                                    $CsvData | Where-Object {$_.FrontDoor -eq $FrontDoor} | ForEach-Object {
                                        $_.DatacenterCode = $Datacenter.Code
                                        $_.DatacenterCountry = $Datacenter.Country
                                        $_.DatacenterLocation = $Datacenter.Location
                                        $_.DatacenterLatitude = $Datacenter.Latitude
                                        $_.DatacenterLongitude = $Datacenter.Longitude
                                        $_.DatacenterUsage = if ($Datacenter.Usage -notlike "") { "$($Datacenter.Usage)-$($_.Service)" }
                                    }
                                }
                                
                                Write-Log -Message "[$Site/$($Item.Name)] Building result array" -Source "$Workload" -MessageType Info
                                $ResultsArray = $CsvData | ForEach-Object {
                                    $DateTime, $Date, $Time, $DayIndex, $Hour = Get-TimestampInfo $_.'Timestamp'
                                    ($DateTime, $Date, $Time, $DayIndex, $Hour, $_.SiteName, `
                                    $_.Service, $_.Target, $_.WSSConnectSuccess, $_.WSSQuerySuccess,$_.WSSResponseSuccess,$_.WSSExpectedResponse,$_.FrontDoor, `
                                    $_.DatacenterCode, $_.DatacenterCountry, $_.DatacenterLocation, `
                                    $_.DatacenterLatitude, $_.DatacenterLongitude, $_.DatacenterUsage ) -join $SyncHash.ListSeparator
                                }
                            }

                        }
                        if ($ResultsArray.Count -gt 0) {
                            Write-Log -Message "[$Site/$($Item.Name)] Adding $($ResultsArray.Count) lines to result file '$ResultsFile'" -Source "$Workload" -MessageType Info -DisplayInGui
                            $ResultsArray | Add-Content -Encoding UTF8 -Path $ResultsFile
                        } else {
                            Write-Log -Message "[$Site/$($Item.Name)] No $Workload results to save" -Source "$Workload" -MessageType Warning -DisplayInGui
                        }
                        $LastEntryDateTime = (($ResultsArray | Select-Object -Last 1) -split $SyncHash.ListSeparator) | Select-Object -First 1
                        Write-FileAnalysisResultsFile -FileName $item.Name -SiteName $Site -DateTime $LastEntryDateTime -Type $Workload -AnalysisStartTime $AnalysisStartTime -Result "Ok" -Reason ""                    
                    } else {
                        Write-Log -Message "[$Site/$($Item.Name)] Skipping analysis (site already processed) for file '$($Item.FullName)'" -Source "$Workload" -MessageType Info -DisplayInGui
                        switch ($Workload) {
                            "Tracert" { $SyncHash.TracertFilesSkipped++ }
                            "TeamsMediaQuality" { $SyncHash.TeamsMediaQualityFilesSkipped++ }
                            "ServiceConnectivity" { $SyncHash.ServiceConnectivityFilesSkipped++ }
                            "WebSocket" { $SyncHash.WebSocketFilesSkipped++ }
                        }
                        $FilesSkipped++
                    }
                    switch ($Workload) {
                        "Tracert" {
                            $SyncHash.TracertFilesProcessed++
                            $SyncHash.TracertAnalysisCompletion = $SyncHash.TracertFilesProcessed * 100 / $SyncHash.TracertFilesToProcess
                            $SyncHash.TracertAnalysisStatus.Text = "$([math]::Round($SyncHash.TracertAnalysisCompletion,1))%"
                        }
                        "TeamsMediaQuality" {
                            $SyncHash.TeamsMediaQualityFilesProcessed++
                            $SyncHash.TeamsMediaQualityAnalysisCompletion = $SyncHash.TeamsMediaQualityFilesProcessed * 100 / $SyncHash.TeamsMediaQualityFilesToProcess
                            $SyncHash.TeamsMediaQualityAnalysisStatus.Text = "$([math]::Round($SyncHash.TeamsMediaQualityAnalysisCompletion,1))%"
                        }
                        "ServiceConnectivity" {
                            $SyncHash.ServiceConnectivityFilesProcessed++
                            $SyncHash.ServiceConnectivityAnalysisCompletion = $SyncHash.ServiceConnectivityFilesProcessed * 100 / $SyncHash.ServiceConnectivityFilesToProcess
                            $SyncHash.ServiceConnectivityAnalysisStatus.Text = "$([math]::Round($SyncHash.ServiceConnectivityAnalysisCompletion,1))%"
                        }
                        "WebSocket" {
                            $SyncHash.WebSocketFilesProcessed++
                            $SyncHash.WebSocketAnalysisCompletion = $SyncHash.WebSocketFilesProcessed * 100 / $SyncHash.WebSocketFilesToProcess
                            $SyncHash.WebSocketAnalysisStatus.Text = "$([math]::Round($SyncHash.WebSocketAnalysisCompletion,1))%"
                        }
                    }
                    $FilesProcessed++
                }
            }
        }
        Write-Log -Message "[$Site] Done processing site '$Site' for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui
    }
    Write-Log -Message "Done processing all sites for $Workload analysis" -Source "$Workload" -MessageType Info -DisplayInGui
    $TimeTaken = New-TimeSpan $SyncHash.StartTimeStamp (Get-Date)
    Write-Log -Message "Time taken: '$($TimeTaken.ToString("hh\:mm\:ss\.ff") -replace '^(0+:|0+)*','')'" -Source "$Workload" -MessageType Info
    if (($FilesProcessed - $FilesSkipped) -gt 0) {
        $TimeTakenPerFile = [timespan]::FromSeconds($TimeTaken.TotalSeconds / ($FilesProcessed - $FilesSkipped))
        Write-Log -Message "Average time per file: '$([math]::Round($TimeTakenPerFile.TotalSeconds,2) -replace ',','.')'" -Source "$Workload" -MessageType Info
    }
}